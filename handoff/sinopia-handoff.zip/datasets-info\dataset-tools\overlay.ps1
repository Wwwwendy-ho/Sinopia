param([string]$Manifest,[string]$Base,[string]$Out,[string]$Field,[string]$ImgField,[int]$Index=0,[double]$Scale=1)
Add-Type -AssemblyName System.Drawing
$m=Get-Content $Manifest -Raw | ConvertFrom-Json
$it=$m.items[$Index]
$img=[Drawing.Image]::FromFile((Join-Path $Base $it.$ImgField))
$bmp=New-Object Drawing.Bitmap $img.Width,$img.Height
$g=[Drawing.Graphics]::FromImage($bmp); $g.DrawImage($img,0,0,$img.Width,$img.Height)
$pts=$it.$Field; $i=0
$font=New-Object Drawing.Font 'Arial',([Math]::Max(10,$img.Width/50))
foreach($p in $pts){ $r=[Math]::Max(3,$img.Width/150); $g.FillEllipse([Drawing.Brushes]::Red,$p[0]-$r,$p[1]-$r,2*$r,2*$r); $g.DrawString("$i",$font,[Drawing.Brushes]::Yellow,$p[0]+$r,$p[1]-$r); $i++ }
$w=[int]($img.Width*$Scale);$h=[int]($img.Height*$Scale)
$o=New-Object Drawing.Bitmap $w,$h; $g2=[Drawing.Graphics]::FromImage($o); $g2.DrawImage($bmp,0,0,$w,$h)
$o.Save($Out,[Drawing.Imaging.ImageFormat]::Png); "$($it.id) $($img.Width)x$($img.Height)"
$img.Dispose()
