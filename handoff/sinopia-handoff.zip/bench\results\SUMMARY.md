﻿# Sinopia auto-align benchmark: summary

Labels: **baseline** = current live app; **fixed** = modified app (auto-align moves/resizes only; low-confidence results are OFFERED, not applied; retakes allow <=10 deg); **fixed-rot** = fixed with "Allow rotation in auto-align" on (<=15 deg). Audio muted in every run. Raw per-case data: `bench\results\<label>-<suite>.json`; live side-by-side report: `bench\results\report.html` (open via the server).

## Headline (what the numbers say)
| | baseline | fixed | fixed-rot |
|---|---|---|---|
| CUFS rot-0 (143 cases): auto-applied | 100% (64% confident + 36% approximate-with-warning) | 64% confident; 36% offered (all 51 correct, NME<=0.15) | same as fixed |
| CUFS rot-0: NME35 median / p90 (IOD-normalised; GT-fit floor 0.034 / 0.045) | 0.047 / 0.065 | 0.044 / 0.061 (applied) | 0.048 / 0.062 |
| CUFS rot-0: unwanted tilt (>2 deg applied) | 3.5% | 0% | 0% |
| CUFS tilted 2-8 deg (47 cases; 60-case subset for fixed-rot): usable & NME<=0.15 | 97.9% | 85.1% (rotation off: residual 4-8 deg) | 93.3% (15-case tilt subset) |
| FS2K rot-0 pairs (92): consistent within 1% diagonal / 1 deg | 47.8% | 65.2% | n/a |
| FS2K untransformed pair: applied rotation >2 deg (pixel-aligned pairs!) | 21.0% | 0% | n/a |
| CUFSF detector: detection / NME3 median / p90 | 100% / 0.034 / 0.050 | identical | |
| Retake correct (<=1% diag, <=1 deg) | 99% | 99% | 99% |

Case counts: CUFS 190 (143 rot-0 + 47 tilt; fixed-rot 60), FS2K 121 baseline / 120 fixed pairs, CUFSF 300 sketches, retake 100 (+60 CUFS-det images), PoPArt stats only.

## Failure analysis (causes, counts, examples; thumbnails in bench\verify\, each viewed to confirm)

Overall: on these datasets the baseline almost never produces a wrong alignment on CUFS/CUFSF (landmark path), so the main "failures" are (a) results flagged approximate/offered although correct, (b) unwanted rotation, (c) the structural fallback and non-frontal faces on FS2K.

### CUFS (baseline 190 cases, fixed 190)
| cause | baseline | fixed | examples |
|---|---|---|---|
| Declined | 0 (0%) | 0 (0%) | - |
| Approximate (baseline: applied with a warning) / Offered (fixed) although accurate | 66 (34.7%), all 66 NME<=0.15 | 68 (35.8%) offered, 65 NME<=0.15 | sample of 25 rot-0 baseline approximate cases re-analysed: landmark fit error 0.004-0.016 of face box (gate 0.035) and 9/9 inliers, i.e. geometrically excellent. 15/25 (60%) fail the detector-score gate `min(score)>=0.7` (photo score 0.36-0.68, sketch 0.27-0.52 in 2 cases); 10/25 (40%) pass it and fail the 'first four anchors within 8.5% of face box' gate (sketch/photo proportion differences). Confident cases have photo score 0.72-0.98. |
| Residual tilt because rotation is off (fixed only) | - | 7 cases NME>0.15 (3.7% of all, 14.9% of the 47 tilt cases); all tilted 4-8 deg | `m1-035-01|tilt` offered, NME 0.187, rotErr +7.9 deg (verify\fixed-cufs-worst-1.jpg: eyes ok, head top offset); `m-019-01|tilt` NME 0.165 rotErr -7.7; with fixed-rot the tilt-case NME is back to 0.050 median |
| Face cut by the frame (benchmark generator limit, not an app fault) | 8 cases have >=1 landmark outside the frame; 2 of the 3 worst baseline cases (NME>0.10) | same | `m1-027-01|tilt` baseline NME 0.221 although rotation (+0.02 deg) and scale (-0.2%) are right: chin/mouth are outside the 1.6x frame (verify\cufs-worst-0.jpg); `m-013-01|r0` NME 0.121 with 6 landmarks outside |
| Unwanted tilt (>2 deg applied on rot-0 cases) | 5/143 = 3.5% (all face-landmark fits; cause assumed to be landmark roll noise, not verified separately) | 0% | - |
| Wrong confident result (NME>0.25) | 0 | 0 | - |
| Detector accuracy on sketches (cause check) | CUFS sketches: 100% detected, NME3 0.036/0.051 vs photos 0.029/0.041 (n=30 each) | same | - |

### FS2K (rot-0 pairs: baseline 93, fixed 92; failure = consistency error >2% diagonal or >2 deg, or one side declined)
| cause | baseline | fixed | examples |
|---|---|---|---|
| Total failing | 19 (20.4%) | 17 (18.5%) | |
| Landmark fit wrong/noisy on at least one side (both runs landmark-based) | 10 (10.8%) | 10 (10.9%) | `photo1/image0710` (3/4-view head): 14.8% diagonal, 7.5 deg (verify\fs2k-photo1_image0710.jpg ghost double face); `photo2/image0018`: 12.9% (glasses/hair-bob sketch; verify\fs2k-photo2_image0018.jpg) |
| Method switches between runs (face-landmarks on one image, structural/reference-face-region on the transformed one) | 5 (5.4%) | 3 | `photo1/image1432`: 8.7% diagonal, -11 deg; sketch shrunk onto the cheek (verify\fs2k-photo1_image1432.jpg) |
| Transformed sketch declined (face-landmarks on the photo/plain sketch, but the transformed sketch falls to the structural matcher, which gives up) | 3 (3.2%) | 3 | `photo1/image0458`, `image1611`, `image0329`; the tilted pair `photo1/image0399` (verify\fs2k-photo1_image0399.jpg) shows a clear frontal photo, so the miss is on the transformed sketch |
| Both declined (photo with text background, big smile close-up) | 1 | 1 | `photo1/image1688` (verify\fs2k-photo1_image1688.jpg) |
| Approximate result involved in a failing pair | 11 of 15 inconsistent (73%) | 9 of 13 | the approximate flag is a good predictor of FS2K failure; unlike CUFS it is not a false alarm here |
| Unwanted tilt on the untransformed, pixel-aligned pair (>2 deg applied) | 25/119 applied = 21.0% (all face-landmark fits; style 0: 28%, style 1: 15%, style 2: 20%) | 0% | `photo3/image0205` rotates the already-aligned sketch (verify via results; pair aligned in the dataset) |
| Tilted-by-design pairs (28; known tilt 2-8 deg) | consistent 57% | 0% consistent (rotation off, as designed; rot error 4.1 deg median) | |
Note on baseline vs fixed FS2K: for the first fixed FS2K run the harness accidentally used the baseline app (bug found: stale iframe). It was discarded and re-run with the fixed app (each case now records `appUrl`).

### CUFSF detector (300 sketches)
No failures: 100% detection, 100% on the true face, NME3 <= 0.10 for 100%; weakest part is the mouth centre (p90 0.075 vs eyes 0.048). No timeouts or declines. Causes that could not be tested here: sketches without a face, non-frontal artist sketches (CUFSF is frontal only).

### Retake (100 cases)
99 correct. One mild residual: `cufsf|00037` 2.1% diagonal / <1 deg (verify\retake-worst-0.jpg looks aligned; blur+shift). No declined cases: the simulated retakes (rot +-3, scale 0.9-1.1, blur, brightness) are easy for the structural matcher; they do not model perspective, glare, or a different paper/background.

## Caveats
- CUFS landmark indices are inferred (not documented): IOD uses points 16/18; NME35 uses all points and is unaffected by naming. Sketch and photo have different proportions, so the GT-fit floor NME is 0.034 median.
- CUFS case list is 188 rot-0 + 63 tilt cases; 190 run. FS2K sample is 40 pairs per style (style 1 has only 98 pairs), 30% tilted by design; FS2K "consistency" does not detect a consistently wrong pair (the pixel-aligned check partly covers this, assuming FS2K pairs are pixel-aligned: unverified).
- The sketch test-drawing generator can push landmarks outside the frame at scale ~1.6 (8/190 cases).
- Offered results (fixed) are measured from the match result that Apply would use (`app.getOffer().res`); applying via acceptOffer() was not separately executed.
- Timings are indicative only: they were measured on a CPU TensorFlow backend, partly with two browser tabs running concurrently and with background-tab timer throttling worked around by a harness-only MessageChannel shim for short timers. Compare timings only within the same label/condition.
- In `fixed-rot` the first re-run reused an already-open fixed iframe with rotation on; `fixed-rot` CUFS is a 60-case prefix (45 rot-0 + 15 tilt) and retake uses retake cap 15 vs 10.
- Case lists and seeds are identical across labels (seeded by case id).

# Full tables
### CUFS known-transform, end-to-end: baseline vs fixed, all 190 cases run (of 251 planned)

**rotation 0 (known scale + translation)**

| metric | baseline | fixed |
|---|---|---|
| cases (n) | 143 | 143 |
| confident (auto-applied) | 64.3% | 64.3% |
| approximate (applied with warning) | 35.7% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 35.7% |
| declined (nothing moved) | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% |
| success: applied and NME<=0.10 | 99.3% | 64.3% |
| success: applied and NME<=0.15 (headline) | 100.0% | 64.3% |
| success: applied and NME<=0.25 | 100.0% | 64.3% |
| offered and correct (NME<=0.15), share of all cases | 0.0% | 35.7% |
| offered but wrong (NME>0.25) | 0.0% | 0.0% |
| usable (applied or offered) and NME<=0.15 | 100.0% | 100.0% |
| confident but wrong (NME>0.25) | 0.0% | 0.0% |
| NME35 median / p90 (applied cases) | 0.047 / 0.065 | 0.044 / 0.061 |
| NME core-8 median / p90 (applied) | 0.038 / 0.057 | 0.037 / 0.055 |
| /rotation error/ deg vs GT similarity, median / p90 | 0.62 / 1.40 | 0.13 / 0.35 |
| /scale error/ % vs GT, median / p90 | 0.85 / 2.28 | 0.78 / 2.28 |
| unwanted tilt: /applied rotation/>2 deg (share of applied) | 3.5% | 0.0% |
| unwanted tilt: /rotation error vs GT/>2 deg (share of applied) | 2.8% | 0.0% |
| floor: GT similarity-fit NME35 median / p90 | 0.034 / 0.045 | 0.034 / 0.045 |
| floor: GT scale+translation-fit NME35 median / p90 | 0.035 / 0.046 | 0.035 / 0.046 |
| time per case ms, median / p90 | 9471 / 16063 | 9793 / 14994 |

**camera tilt +-2..8 deg**

| metric | baseline | fixed |
|---|---|---|
| cases (n) | 47 | 47 |
| confident (auto-applied) | 68.1% | 63.8% |
| approximate (applied with warning) | 31.9% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 36.2% |
| declined (nothing moved) | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% |
| success: applied and NME<=0.10 | 95.7% | 25.5% |
| success: applied and NME<=0.15 (headline) | 97.9% | 55.3% |
| success: applied and NME<=0.25 | 100.0% | 63.8% |
| offered and correct (NME<=0.15), share of all cases | 0.0% | 29.8% |
| offered but wrong (NME>0.25) | 0.0% | 0.0% |
| usable (applied or offered) and NME<=0.15 | 97.9% | 85.1% |
| confident but wrong (NME>0.25) | 0.0% | 0.0% |
| NME35 median / p90 (applied cases) | 0.046 / 0.074 | 0.106 / 0.155 |
| NME core-8 median / p90 (applied) | 0.041 / 0.069 | 0.089 / 0.129 |
| /rotation error/ deg vs GT similarity, median / p90 | 0.49 / 1.56 | 4.93 / 6.73 |
| /scale error/ % vs GT, median / p90 | 0.78 / 1.96 | 0.98 / 2.07 |
| floor: GT similarity-fit NME35 median / p90 | 0.032 / 0.044 | 0.032 / 0.044 |
| floor: GT scale+translation-fit NME35 median / p90 | 0.033 / 0.045 | 0.033 / 0.045 |
| time per case ms, median / p90 | 10567 / 15871 | 10105 / 14216 |

### CUFS known-transform: baseline vs fixed vs fixed-rot, the 60 common cases

**rotation 0 (known scale + translation)**

| metric | baseline | fixed | fixed-rot |
|---|---|---|---|
| cases (n) | 45 | 45 | 45 |
| confident (auto-applied) | 71.1% | 71.1% | 71.1% |
| approximate (applied with warning) | 28.9% | 0.0% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 28.9% | 28.9% |
| declined (nothing moved) | 0.0% | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% | 0.0% |
| success: applied and NME<=0.10 | 97.8% | 71.1% | 71.1% |
| success: applied and NME<=0.15 (headline) | 100.0% | 71.1% | 71.1% |
| success: applied and NME<=0.25 | 100.0% | 71.1% | 71.1% |
| offered and correct (NME<=0.15), share of all cases | 0.0% | 28.9% | 28.9% |
| offered but wrong (NME>0.25) | 0.0% | 0.0% | 0.0% |
| usable (applied or offered) and NME<=0.15 | 100.0% | 100.0% | 100.0% |
| confident but wrong (NME>0.25) | 0.0% | 0.0% | 0.0% |
| NME35 median / p90 (applied cases) | 0.048 / 0.066 | 0.045 / 0.061 | 0.048 / 0.062 |
| NME core-8 median / p90 (applied) | 0.041 / 0.059 | 0.039 / 0.058 | 0.043 / 0.059 |
| /rotation error/ deg vs GT similarity, median / p90 | 0.55 / 1.25 | 0.13 / 0.41 | 0.57 / 1.26 |
| /scale error/ % vs GT, median / p90 | 0.72 / 2.31 | 0.71 / 2.26 | 0.71 / 2.25 |
| unwanted tilt: /applied rotation/>2 deg (share of applied) | 0.0% | 0.0% | 0.0% |
| unwanted tilt: /rotation error vs GT/>2 deg (share of applied) | 0.0% | 0.0% | 0.0% |
| floor: GT similarity-fit NME35 median / p90 | 0.033 / 0.046 | 0.033 / 0.046 | 0.033 / 0.046 |
| floor: GT scale+translation-fit NME35 median / p90 | 0.033 / 0.047 | 0.033 / 0.047 | 0.033 / 0.047 |
| time per case ms, median / p90 | 5486 / 14395 | 8947 / 16102 | 15641 / 17627 |

**camera tilt +-2..8 deg**

| metric | baseline | fixed | fixed-rot |
|---|---|---|---|
| cases (n) | 15 | 15 | 15 |
| confident (auto-applied) | 73.3% | 60.0% | 73.3% |
| approximate (applied with warning) | 26.7% | 0.0% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 40.0% | 26.7% |
| declined (nothing moved) | 0.0% | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% | 0.0% |
| success: applied and NME<=0.10 | 93.3% | 20.0% | 66.7% |
| success: applied and NME<=0.15 (headline) | 93.3% | 46.7% | 66.7% |
| success: applied and NME<=0.25 | 100.0% | 60.0% | 73.3% |
| offered and correct (NME<=0.15), share of all cases | 0.0% | 26.7% | 26.7% |
| offered but wrong (NME>0.25) | 0.0% | 0.0% | 0.0% |
| usable (applied or offered) and NME<=0.15 | 93.3% | 73.3% | 93.3% |
| confident but wrong (NME>0.25) | 0.0% | 0.0% | 0.0% |
| NME35 median / p90 (applied cases) | 0.050 / 0.080 | 0.120 / 0.173 | 0.050 / 0.073 |
| NME core-8 median / p90 (applied) | 0.046 / 0.072 | 0.105 / 0.145 | 0.046 / 0.065 |
| /rotation error/ deg vs GT similarity, median / p90 | 0.58 / 1.44 | 5.24 / 6.29 | 0.57 / 1.57 |
| /scale error/ % vs GT, median / p90 | 1.27 / 2.30 | 1.05 / 1.98 | 1.25 / 1.75 |
| floor: GT similarity-fit NME35 median / p90 | 0.035 / 0.047 | 0.035 / 0.047 | 0.035 / 0.047 |
| floor: GT scale+translation-fit NME35 median / p90 | 0.035 / 0.048 | 0.035 / 0.048 | 0.035 / 0.048 |
| time per case ms, median / p90 | 6150 / 12229 | 10188 / 15426 | 15598 / 18283 |

### FS2K self-consistency, direct estimator, 120 common pairs (40 per style, 30% of pairs tilted)

**all styles**

| metric | baseline | fixed |
|---|---|---|
| pairs (n) | 120 | 120 |
| untransformed pair: confident / approximate / offered / declined % | 65.0% / 34.2% / 0.0% / 0.8% | 65.0% / 34.2% / 0.0% / 0.8% |
| transformed sketch: confident / approximate / offered / declined % | 45.0% / 50.8% / 0.0% / 4.2% | 44.2% / 50.8% / 0.0% / 5.0% |
| both applied (consistency measurable) | 95.8% | 95.0% |
| consistent within 1% diagonal and 1 deg (of all pairs) | 50.0% | 50.0% |
| consistency position error % of diagonal, median / p90 | 0.89 / 3.04 | 0.89 / 4.48 |
| consistency rotation error deg, median / p90 (abs) | 0.48 / 1.61 | 0.00 / 4.32 |
| consistency scale error %, median / p90 (abs) | 1.20 / 4.84 | 1.19 / 5.05 |
| untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=119) | 1.56 / 2.81 | 1.19 / 2.50 |
|   ...share within 2% diagonal and 2 deg | 67.2% | 83.2% |
| unwanted tilt on untransformed pair: /theta/>2 deg (share of applied) | 21.0% | 0.0% |
| time per pair ms (two matches), median / p90 | 18055 / 31970 | 2552 / 7816 |

**all styles, rotation-0 pairs only**

| metric | baseline | fixed |
|---|---|---|
| pairs (n) | 92 | 92 |
| untransformed pair: confident / approximate / offered / declined % | 63.0% / 35.9% / 0.0% / 1.1% | 63.0% / 35.9% / 0.0% / 1.1% |
| transformed sketch: confident / approximate / offered / declined % | 45.7% / 50.0% / 0.0% / 4.3% | 45.7% / 50.0% / 0.0% / 4.3% |
| both applied (consistency measurable) | 95.7% | 95.7% |
| consistent within 1% diagonal and 1 deg (of all pairs) | 47.8% | 65.2% |
| consistency position error % of diagonal, median / p90 | 0.94 / 3.31 | 0.70 / 2.60 |
| consistency rotation error deg, median / p90 (abs) | 0.49 / 1.69 | 0.00 / 0.00 |
| consistency scale error %, median / p90 (abs) | 1.17 / 4.68 | 1.15 / 4.59 |
| untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=91) | 1.56 / 2.74 | 1.09 / 2.40 |
|   ...share within 2% diagonal and 2 deg | 65.9% | 84.6% |
| unwanted tilt on untransformed pair: /theta/>2 deg (share of applied) | 22.0% | 0.0% |
| time per pair ms (two matches), median / p90 | 18094 / 31385 | 2557 / 6937 |

**all styles, tilted (+-2..8 deg) only**

| metric | baseline | fixed |
|---|---|---|
| pairs (n) | 28 | 28 |
| untransformed pair: confident / approximate / offered / declined % | 71.4% / 28.6% / 0.0% / 0.0% | 71.4% / 28.6% / 0.0% / 0.0% |
| transformed sketch: confident / approximate / offered / declined % | 42.9% / 53.6% / 0.0% / 3.6% | 39.3% / 53.6% / 0.0% / 7.1% |
| both applied (consistency measurable) | 96.4% | 92.9% |
| consistent within 1% diagonal and 1 deg (of all pairs) | 57.1% | 0.0% |
| consistency position error % of diagonal, median / p90 | 0.78 / 2.22 | 3.32 / 6.03 |
| consistency rotation error deg, median / p90 (abs) | 0.40 / 1.49 | 4.12 / 6.92 |
| consistency scale error %, median / p90 (abs) | 1.30 / 3.66 | 1.31 / 5.86 |
| untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=28) | 1.60 / 3.75 | 1.40 / 2.92 |
|   ...share within 2% diagonal and 2 deg | 71.4% | 78.6% |
| unwanted tilt on untransformed pair: /theta/>2 deg (share of applied) | 17.9% | 0.0% |
| time per pair ms (two matches), median / p90 | 17643 / 32752 | 2471 / 12208 |

**style 0 (pencil-like sketch1)**

| metric | baseline | fixed |
|---|---|---|
| pairs (n) | 40 | 40 |
| untransformed pair: confident / approximate / offered / declined % | 65.0% / 32.5% / 0.0% / 2.5% | 65.0% / 32.5% / 0.0% / 2.5% |
| transformed sketch: confident / approximate / offered / declined % | 45.0% / 45.0% / 0.0% / 10.0% | 42.5% / 47.5% / 0.0% / 10.0% |
| both applied (consistency measurable) | 90.0% | 90.0% |
| consistent within 1% diagonal and 1 deg (of all pairs) | 52.5% | 42.5% |
| consistency position error % of diagonal, median / p90 | 0.80 / 3.76 | 1.18 / 4.31 |
| consistency rotation error deg, median / p90 (abs) | 0.35 / 1.32 | 0.00 / 5.10 |
| consistency scale error %, median / p90 (abs) | 0.94 / 3.07 | 1.31 / 4.34 |
| untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=39) | 1.87 / 3.30 | 1.34 / 2.59 |
|   ...share within 2% diagonal and 2 deg | 61.5% | 76.9% |
| unwanted tilt on untransformed pair: /theta/>2 deg (share of applied) | 28.2% | 0.0% |
| time per pair ms (two matches), median / p90 | 18404 / 32041 | 2977 / 5964 |

**style 1 (sketch2 (png))**

| metric | baseline | fixed |
|---|---|---|
| pairs (n) | 40 | 40 |
| untransformed pair: confident / approximate / offered / declined % | 65.0% / 35.0% / 0.0% / 0.0% | 65.0% / 35.0% / 0.0% / 0.0% |
| transformed sketch: confident / approximate / offered / declined % | 40.0% / 57.5% / 0.0% / 2.5% | 40.0% / 55.0% / 0.0% / 5.0% |
| both applied (consistency measurable) | 97.5% | 95.0% |
| consistent within 1% diagonal and 1 deg (of all pairs) | 47.5% | 45.0% |
| consistency position error % of diagonal, median / p90 | 1.08 / 2.25 | 1.17 / 5.46 |
| consistency rotation error deg, median / p90 (abs) | 0.49 / 1.77 | 0.00 / 4.54 |
| consistency scale error %, median / p90 (abs) | 1.39 / 5.11 | 1.33 / 5.01 |
| untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=40) | 1.64 / 2.63 | 1.37 / 2.54 |
|   ...share within 2% diagonal and 2 deg | 67.5% | 82.5% |
| unwanted tilt on untransformed pair: /theta/>2 deg (share of applied) | 15.0% | 0.0% |
| time per pair ms (two matches), median / p90 | 18383 / 33295 | 2583 / 9031 |

**style 2 (sketch3)**

| metric | baseline | fixed |
|---|---|---|
| pairs (n) | 40 | 40 |
| untransformed pair: confident / approximate / offered / declined % | 65.0% / 35.0% / 0.0% / 0.0% | 65.0% / 35.0% / 0.0% / 0.0% |
| transformed sketch: confident / approximate / offered / declined % | 50.0% / 50.0% / 0.0% / 0.0% | 50.0% / 50.0% / 0.0% / 0.0% |
| both applied (consistency measurable) | 100.0% | 100.0% |
| consistent within 1% diagonal and 1 deg (of all pairs) | 50.0% | 62.5% |
| consistency position error % of diagonal, median / p90 | 0.89 / 2.72 | 0.72 / 3.33 |
| consistency rotation error deg, median / p90 (abs) | 0.57 / 1.55 | 0.00 / 3.54 |
| consistency scale error %, median / p90 (abs) | 1.15 / 4.56 | 0.94 / 4.50 |
| untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=40) | 1.25 / 2.81 | 0.64 / 1.80 |
|   ...share within 2% diagonal and 2 deg | 72.5% | 90.0% |
| unwanted tilt on untransformed pair: /theta/>2 deg (share of applied) | 20.0% | 0.0% |
| time per pair ms (two matches), median / p90 | 17118 / 27034 | 2467 / 6165 |

### CUFSF detector, 300 sketches (detector code identical in both apps)

**CUFSF original sketches**

| metric | baseline | fixed |
|---|---|---|
| sketches (n) | 300 | 300 |
| detection rate (>=1 face passes app sanity filter) | 100.0% | 100.0% |
| dominant face (what subject alignment uses) | 100.0% | 100.0% |
| largest face located on the true face (within 1 IOD of eye mid) | 100.0% | 100.0% |
| NME eyes+mouth (3 pts), on-face detections, median / p90 | 0.034 / 0.050 | 0.034 / 0.050 |
| NME eye centres only, median / p90 | 0.031 / 0.048 | 0.031 / 0.048 |
| NME mouth centre only, median / p90 | 0.038 / 0.075 | 0.038 / 0.075 |
| /roll error/ deg (eye line vs truth), median / p90 | 0.65 / 1.69 | 0.65 / 1.69 |
| detections with NME3 <= 0.10 (share of all sketches) | 100.0% | 100.0% |
| detections with NME3 <= 0.25 (share of all sketches) | 100.0% | 100.0% |
| multiple faces reported | 0.0% | 0.0% |
| time per sketch ms, median / p90 | 1702 / 1933 | 4358 / 5380 |

### Retake, 100 cases

**all**

| metric | baseline | fixed | fixed-rot |
|---|---|---|---|
| cases (n) | 100 | 100 | 100 |
| confident (auto-applied) | 100.0% | 100.0% | 100.0% |
| approximate (applied with warning) | 0.0% | 0.0% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 0.0% | 0.0% |
| declined (nothing moved) | 0.0% | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% | 0.0% |
| correct: confident and error <=1% diagonal, <=1 deg | 99.0% | 99.0% | 99.0% |
| confident but wrong (>3% diagonal) | 0.0% | 0.0% | 0.0% |
| position error % diagonal, median / p90 (confident) | 0.12 / 0.25 | 0.12 / 0.26 | 0.13 / 0.25 |
| /rotation error/ deg, median / p90 | 0.07 / 0.23 | 0.07 / 0.23 | 0.07 / 0.22 |
| /scale error/ %, median / p90 | 0.23 / 0.53 | 0.23 / 0.53 | 0.23 / 0.53 |
| time per case ms, median / p90 | 1179 / 1318 | 3054 / 3221 | 359 / 1900 |

**source: cufsf**

| metric | baseline | fixed | fixed-rot |
|---|---|---|---|
| cases (n) | 43 | 43 | 43 |
| confident (auto-applied) | 100.0% | 100.0% | 100.0% |
| approximate (applied with warning) | 0.0% | 0.0% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 0.0% | 0.0% |
| declined (nothing moved) | 0.0% | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% | 0.0% |
| correct: confident and error <=1% diagonal, <=1 deg | 97.7% | 97.7% | 97.7% |
| confident but wrong (>3% diagonal) | 0.0% | 0.0% | 0.0% |
| position error % diagonal, median / p90 (confident) | 0.12 / 0.28 | 0.13 / 0.28 | 0.13 / 0.28 |
| /rotation error/ deg, median / p90 | 0.05 / 0.13 | 0.05 / 0.12 | 0.05 / 0.10 |
| /scale error/ %, median / p90 | 0.25 / 0.60 | 0.25 / 0.60 | 0.25 / 0.60 |
| time per case ms, median / p90 | 1190 / 1333 | 3071 / 3263 | 368 / 1951 |

**source: cufs**

| metric | baseline | fixed | fixed-rot |
|---|---|---|---|
| cases (n) | 27 | 27 | 27 |
| confident (auto-applied) | 100.0% | 100.0% | 100.0% |
| approximate (applied with warning) | 0.0% | 0.0% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 0.0% | 0.0% |
| declined (nothing moved) | 0.0% | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% | 0.0% |
| correct: confident and error <=1% diagonal, <=1 deg | 100.0% | 100.0% | 100.0% |
| confident but wrong (>3% diagonal) | 0.0% | 0.0% | 0.0% |
| position error % diagonal, median / p90 (confident) | 0.16 / 0.24 | 0.16 / 0.26 | 0.13 / 0.24 |
| /rotation error/ deg, median / p90 | 0.10 / 0.27 | 0.11 / 0.28 | 0.09 / 0.28 |
| /scale error/ %, median / p90 | 0.15 / 0.47 | 0.15 / 0.47 | 0.20 / 0.47 |
| time per case ms, median / p90 | 1161 / 1289 | 3029 / 3153 | 361 / 1004 |

**source: fs2k**

| metric | baseline | fixed | fixed-rot |
|---|---|---|---|
| cases (n) | 30 | 30 | 30 |
| confident (auto-applied) | 100.0% | 100.0% | 100.0% |
| approximate (applied with warning) | 0.0% | 0.0% | 0.0% |
| offered only (fixed app: panel with Apply, nothing moved) | 0.0% | 0.0% | 0.0% |
| declined (nothing moved) | 0.0% | 0.0% | 0.0% |
| error / no result | 0.0% | 0.0% | 0.0% |
| correct: confident and error <=1% diagonal, <=1 deg | 100.0% | 100.0% | 100.0% |
| confident but wrong (>3% diagonal) | 0.0% | 0.0% | 0.0% |
| position error % diagonal, median / p90 (confident) | 0.11 / 0.20 | 0.11 / 0.21 | 0.12 / 0.20 |
| /rotation error/ deg, median / p90 | 0.10 / 0.17 | 0.07 / 0.20 | 0.08 / 0.19 |
| /scale error/ %, median / p90 | 0.18 / 0.40 | 0.16 / 0.40 | 0.16 / 0.40 |
| time per case ms, median / p90 | 1199 / 1313 | 3056 / 3221 | 353 / 393 |

### CUFS detector on photos vs sketches (baseline, 30 pairs)

**CUFS photos**

| metric | baseline |
|---|---|
| n | 30 |
| detection rate | 100.0% |
| on the true face | 100.0% |
| NME3 median / p90 | 0.029 / 0.041 |
| NME eyes median / p90 | 0.030 / 0.050 |
| NME mouth median / p90 | 0.020 / 0.039 |
| time ms median / p90 | 7416 / 8040 |

**CUFS sketchs**

| metric | baseline |
|---|---|
| n | 30 |
| detection rate | 100.0% |
| on the true face | 100.0% |
| NME3 median / p90 | 0.036 / 0.051 |
| NME eyes median / p90 | 0.037 / 0.060 |
| NME mouth median / p90 | 0.032 / 0.052 |
| time ms median / p90 | 7369 / 7774 |

### PoPArt (placeholder)

- images: 2453
- splits: train:1471 val:491 test:491
- labelled figures: 11204
- figures with >=13 keypoints: 3014
- images with >=1 figure: 2453
- visible keypoints (v=2) share of all slots: 0.86
- width median: 769
- height median: 900
- max side p90: 2272.8
- body alignment in the app: none yet (phase 3 placeholder): this suite only records dataset statistics
- skipped (long path): 1


