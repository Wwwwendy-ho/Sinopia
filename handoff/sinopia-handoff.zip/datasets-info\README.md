# Sinopia alignment benchmark datasets (local testing only, do NOT commit/redistribute)

Root: C:\Users\20750\AppData\Local\Temp\claude\df94f8acbc60bcdb\38d4e9ac-9cca-4ccd-a11f-6b2665c5a69c\scratchpad\datasets\
Scripts (separate dir): ...\scratchpad\dataset-tools\ (gen-manifests.ps1, gen-poparts.ps1, overlay.ps1)
Total on disk ~2.4 GB (zips kept next to extracted copies). Each dataset has manifest.json; paths are relative to that dataset's folder.

## Common manifest conventions
Top-level: {dataset, count, point_order (text), items[]}. Pixel coords are in the pixel frame of the image file named in the same item (x right, y down, origin top-left). Image width/height are read from the actual files.

## cufsf (CUFSF) - 1,194 sketches, 3 landmarks each, photos MISSING
- Source: https://mmlab.ie.cuhk.edu.hk/archive/cufsf/ (files/original_sketch.zip, sketch_points.zip, photo_points.zip, cropped_sketch.zip, feret_filenames.txt)
- Licence: the page states no licence text. Only: "CUFSF is for research on face sketch synthesis and face sketch recognition" and "If you use the CUFSF database, please cite" Wang&Tang TPAMI 2009 and Zhang et al. CVPR 2011. FERET photos are under NIST's separate terms. Treat as research use only.
- Obtained: original_sketch (1194 jpg, 85.8 MB zip; sizes vary 744x768 .. 795x817), cropped_sketch (1194, 64x80), sketch_points (1194 .3pts), photo_points (1194 .3pts), feret_filenames.txt.
- MISSING: the FERET photos (NIST request; not obtained by any other means). Manifest has photo=null and feret_photo_filename.
- Landmarks: only 3 points per file (NOT a full fiducial set), "x y" per line: [0] left eye centre (image left), [1] right eye centre, [2] mouth centre. No nose tip, mouth corners, or chin. Photo points are in the 768x712 frame (FERET resized to 768x512, padded 100 px left/right) and are only usable if you obtain the photos and reproduce that transform. Sketch points are in the original sketch file frame.
- Manifest item: id, sketch, sketch_width/height, sketch_cropped, sketch_points[3][2], sketch_named{left_eye_center,right_eye_center,mouth_center}, photo:null, feret_photo_filename, photo_frame_width/height (768x712), photo_points_in_768x712_frame, photo_named_in_768x712_frame.
- Verified visually: sketches 00001 and 00505: points 0/1 sit on the two eye centres; point 2 sits on the mouth (on the lip line for 00001, a few px below the lips for 00505). Sketch has a handwritten filename caption at top.
- Caveat: sketches deliberately exaggerate shape; no matching photo, so only sketch-side landmarks usable.

## cufs (CUFS, CUHK student subset only) - 188 photo/sketch pairs, 35 landmarks
- Source: https://mmlab.ie.cuhk.edu.hk/archive/facesketch.html (live page returned HTTP 500 from this machine; the file list was read from a Wayback snapshot, 2021-03-13, and the files themselves downloaded from the live host https://mmlab.ie.cuhk.edu.hk/archive/sketchdatabase/CUHK/...). AR and XM2VTS parts skipped (photos need separate licences).
- Licence: no licence text on the page. Only description: "CUFS is for research on face sketch synthesis and face sketch recognition." Treat as research use only; cite Wang & Tang, TPAMI 2009.
- Obtained (12 zips, ~37 MB; extracted under cufs\x\): training 88 + testing 100 pairs = 188: original photos (1024x768), original sketches (414x582), cropped photos & sketches (200x250), fiducial points for photo and sketch (.dat). Nothing missing for this subset.
- Landmarks: 35 points per .dat ("x y" per line), in the ORIGINAL (uncropped) photo/sketch pixel frames; no point files exist for cropped images. Semantic order undocumented; from overlays I inferred (0-based): 0 top of head, 6 chin, 16 left eye centre, 17 between eyes, 18 right eye centre, 20 nose base, 22/25 mouth corners (left/right), 26-29 eye corners, 12-15 brow ends, 3/9, 4/8, 5/7 face contour, 10/2 head sides. Recorded in manifest "named_indices". Treat as inferred, not official.
- Manifest item: id, split, photo, photo_width/height, sketch, sketch_width/height, photo_points[35][2], sketch_points[35][2], photo_cropped, sketch_cropped.
- Verified visually (item f-008-01): points sit on head top, brows, both eye centres, nose base, mouth corners, chin, jaw/ears in BOTH photo and sketch.
- CAVEAT: the original photo (1024x768, landscape) and sketch (414x582, portrait) are different sizes and different framing: the sketch was drawn from the photo but has its own crop/scale, so they are NOT pixel-aligned in the original files. Use the 35 points to estimate the transform, or use the 200x250 cropped pairs (normalised to the same geometry, near-aligned) for synthetic known-transform tests. Cropped pairs have no point files.
- Filename quirks: sketches are "<key>-sz1.jpg" with differing case/extra digit (F2-/f2-), training photos include .JPG; manifest pairing handles this (188/188 paired).

## fs2k (FS2K) - 2,104 photo/sketch pairs, NO landmarks
- Source: https://github.com/DengPingFan/FS2K ; data from the README's Google Drive link https://drive.google.com/file/d/1saIMhQ3dc5_ftkfGmBPbCluRn_zy7QQp/view (Baidu alternative https://pan.baidu.com/s/1eJVNPlGRbCc2zSp4iO8bVw pwd FS2K). Drive only showed the standard "too large to virus scan - Download anyway" page (no login); fetched with the confirm=t link.
- Licence: repo LICENSE is "MIT License, Copyright (c) 2021 Deng-Ping Fan" (code licence). The dataset images come from CASIA-WebFace, invited actors and stock sites (Unsplash/Pexels/Pngimg/Google), so image rights may differ from MIT: research/local use only.
- Obtained: FS2K.zip 109.7 MB; photo1 1529 + photo2 98 + photo3 477 photos, matching sketch1/2/3 (sketch2 is png), anno_train.json, anno_test.json (merged in manifest), README.pdf (not read).
- Landmarks: none. Annotation attributes (skin_color [two numbers, likely x,y of a skin sample point - unverified], lip_color, eye_color mean RGB, hair, hair_color, gender, earring, smile, frontal_face, style 0/1/2) are copied under items[].attributes.
- Manifest item: id, split, style, photo, photo_width/height, sketch, sketch_width/height, attributes. Photo/sketch sizes are checked per file and may differ per pair.

## poparts (PoPArt) - 2,453 artwork images, COCO keypoints
- Source: https://zenodo.org/records/7516230 (PoPArt.zip, 973,453,245 bytes, MD5 0b8b8f71... verified).
- Licence: Creative Commons Attribution 4.0 International (cc-by-4.0), access_right open (Zenodo record metadata). Attribution required; WikiArt metadata/URLs included per image.
- Obtained: full zip incl. images (train 1473 / val 492 / test 492 listed; 2,453 extracted) and COCO annotations person_keypoints_{train,val,test}.json. Images are included, no URL downloading needed. One image could not be extracted (Windows path too long): images/train/domenico-ghirlandaio_madonna-and-child-enthroned-with-four-angels-the-archangels-michael-and-raphael-and-st-gusto-1485.jpg; it is omitted from the manifest (skipped_missing_files).
- Keypoints: 17 COCO keypoints [x,y,v] (nose, eyes, ears, shoulders, elbows, wrists, hips, knees, ankles), pixels in the image file; v=0 unlabelled, 2 visible. Up to 4 labelled figures per image, with bbox. Some figures have no keypoints.
- Manifest item: id, split, image, width, height, style (WikiArt), wikiart_url, figures[{bbox,num_keypoints,keypoints[17][3]}].
- Verified visually (val, john-french-sloan_spring-planting-greenwich-village-1913): points lie on the heads, shoulders, elbows, hands, knees and feet of the two labelled women (third figure unlabelled, consistent with the sparse-labelling note).
- Caveat: paintings only; no photo/drawing pairs. Useful for figure keypoint (proportion) checks, not for pair alignment.

## SketchRef (optional) - not downloaded
Paper https://arxiv.org/abs/2408.08623 ; no direct dataset download link found by web search (arXiv page lists Hugging Face / Papers with Code pointers only). Not obtained.

## hands11k (11k Hands, Afifi 2017) - 11,076 hand photos, no keypoints
- Source: project page https://sites.google.com/view/11khands (Hands.zip 662,833,682 bytes, SHA256 F15B0D68C2093669AAD9D7C9F92F9C184F1020878CDBE2E2482E50348A0F4631; HandInfo.csv 776,742 bytes). Both from the page's Google Drive links (file ids 1KcMYcNJgtK1zZvfl_9sTqnyBUTri2aP2 and 1RC86-rVOR8c93XAfM9b9R45L7C2B0FdA), via drive.usercontent.google.com. Cite: Afifi, "11K Hands: gender recognition and biometric identification using a large dataset of hand images", Multimedia Tools and Applications 2019 (arXiv 1711.04322). The skin-mask images (1.65 GB) and the source-code zips were NOT downloaded.
- Terms (quote from the page): "The dataset is FREE for reasonable academic fair use." No formal licence text; the page footer says it "contains files that could be protected by copyright". Treat as academic/research use, local testing only, never commit or redistribute (the page also asks to cite the paper).
- Obtained: 11,076 jpg (all 1600x1200, 850.9 MB extracted, in Hands\) plus HandInfo.csv; Hands.zip kept in hands11k\_dl\. 190 subjects. Counts by aspect: dorsal right 2,892; dorsal left 2,788; palmar left 2,583; palmar right 2,813. accessories=1: 3,211; nailPolish=1: 1,067.
- Zip checked before extraction: 11,077 entries (1 folder + 11,076 jpg), no absolute or '..' paths. Nothing was executed.
- Metadata (HandInfo.csv columns): id (subject), age, gender, skinColor, accessories (0/1), nailPolish (0/1), aspectOfHand ("dorsal right" etc.), imageName, irregularities (0/1).
- Manifest (hands11k\manifest.json, made by dataset-tools\gen-hands11k-manifest.ps1): {dataset, count, source, terms, imageSizes, missing, items[]}; item = id, image (relative, Hands/Hand_xxxxxxx.jpg), width, height, subject, age, gender, skinColor, accessories, nailPolish, irregularities, aspect, view (dorsal|palmar), side (left|right).
- Caveats: white background, hands often cut at the wrist/fingers; MediaPipe Hand Landmarker needs colour (see bench\results\hands-*.json).
