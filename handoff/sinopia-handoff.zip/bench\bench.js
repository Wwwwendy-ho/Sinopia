/* Sinopia auto-align benchmark harness. Loaded by run.html. See README.md.
   Public API (window.Bench):
     Bench.start({app:'baseline'|'fixed', suite, n, mode, ...})  -> runs in background, resumable
     Bench.state                                                  -> progress for polling
     Bench.stop()
   Conventions: every transform T = {s, th, x, y} maps CENTRED pixel coordinates (origin = image centre) of the
   moving image onto CENTRED coordinates of the fixed image: p' = s*R(th)*p + (x,y). Same convention as the app's matcher. */
(() => {
  'use strict';
  const B = (window.Bench = {});
  B.version = 1;
  B.state = { status: 'idle', suite: null, app: null, done: 0, total: 0, msg: '', err: null, lastMs: 0 };
  B.suites = {};
  const sleep = async ms => { if (ms > 100) return new Promise(r => setTimeout(r, ms)); const end = performance.now() + ms; do { await tick(); } while (performance.now() < end); };
  const _mc = new MessageChannel(), _q = []; _mc.port1.onmessage = () => { const f = _q.shift(); if (f) f(); };
  const tick = () => new Promise(r => { _q.push(r); _mc.port2.postMessage(0); });
  const DATA = '/data/';
  const D2R = Math.PI / 180;

  // ------------------------------------------------------------------ small utils
  function hash(str) { let h = 1779033703 ^ str.length; for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); } return () => { h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); return (h ^= h >>> 16) >>> 0; }; }
  function rng(seed) { let a = hash(String(seed))(); return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const uni = (r, a, b) => a + (b - a) * r();
  const wrap = a => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
  function shuffled(arr, seed) { const r = rng(seed), a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  // similarity transforms
  const apply = (T, p) => { const c = Math.cos(T.th), s = Math.sin(T.th); return { x: T.s * (c * p.x - s * p.y) + T.x, y: T.s * (s * p.x + c * p.y) + T.y }; };
  const compose = (A, B2) => { const t = apply(A, { x: B2.x, y: B2.y }); return { s: A.s * B2.s, th: wrap(A.th + B2.th), x: t.x, y: t.y }; }; // A after B
  const invert = T => { const s = 1 / T.s, th = -T.th, c = Math.cos(th), sn = Math.sin(th); return { s, th, x: -s * (c * T.x - sn * T.y), y: -s * (sn * T.x + c * T.y) }; };
  function fitSim(P, Q, rot = true) { // P -> Q least squares, rot=false: scale+translation only
    const n = P.length; let mx = 0, my = 0, fx = 0, fy = 0;
    for (let i = 0; i < n; i++) { mx += P[i].x; my += P[i].y; fx += Q[i].x; fy += Q[i].y; }
    mx /= n; my /= n; fx /= n; fy /= n;
    let den = 0, re = 0, im = 0;
    for (let i = 0; i < n; i++) { const x = P[i].x - mx, y = P[i].y - my, u = Q[i].x - fx, v = Q[i].y - fy; den += x * x + y * y; re += x * u + y * v; im += x * v - y * u; }
    let s, th; if (rot) { s = Math.hypot(re, im) / den; th = Math.atan2(im, re); } else { s = re / den; th = 0; }
    const c = Math.cos(th), sn = Math.sin(th);
    return { s, th, x: fx - s * (c * mx - sn * my), y: fy - s * (sn * mx + c * my) };
  }
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const centred = (pts, w, h) => pts.map(p => ({ x: p[0] - w / 2, y: p[1] - h / 2 }));
  const mean = a => a.reduce((s, v) => s + v, 0) / a.length;
  const r4 = v => (Number.isFinite(v) ? Math.round(v * 1e4) / 1e4 : v);
  const Tround = T => T && { s: r4(T.s), th: r4(T.th), x: Math.round(T.x * 100) / 100, y: Math.round(T.y * 100) / 100 };

  // ------------------------------------------------------------------ images
  const imgCache = new Map();
  async function fetchBlob(url) { const r = await fetch(url, { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url); return r.blob(); }
  async function fetchJson(url) { const r = await fetch(url, { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url); return r.json(); }
  async function blobToCanvas(blob) {
    const bmp = await createImageBitmap(blob, { imageOrientation: 'from-image' });
    const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height; c.getContext('2d').drawImage(bmp, 0, 0); bmp.close(); return c;
  }
  async function loadCanvas(url) { // cached, small LRU
    if (imgCache.has(url)) return imgCache.get(url);
    const c = await blobToCanvas(await fetchBlob(url));
    imgCache.set(url, c); if (imgCache.size > 16) imgCache.delete(imgCache.keys().next().value);
    return c;
  }
  const toBlob = (canvas, type = 'image/jpeg', q = 0.92) => new Promise(res => canvas.toBlob(res, type, q));
  /** Render `src` under centred transform K onto a white canvas of the same size. Optional photo-like degradations. */
  function renderTransformed(src, K, opt = {}) {
    const w = src.width, h = src.height, c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d'); x.fillStyle = opt.paper || '#fff'; x.fillRect(0, 0, w, h);
    x.imageSmoothingQuality = 'high';
    if (opt.blur || opt.brightness || opt.contrast) x.filter = `blur(${opt.blur || 0}px) brightness(${opt.brightness || 1}) contrast(${opt.contrast || 1})`;
    x.translate(w / 2 + K.x, h / 2 + K.y); x.rotate(K.th); x.scale(K.s, K.s); x.translate(-w / 2, -h / 2);
    x.drawImage(src, 0, 0);
    return c;
  }

  // ------------------------------------------------------------------ app handling
  let frame = null, W = null, DC = null;
  const deleteDb = () => new Promise(res => { try { const r = indexedDB.deleteDatabase('drawing-compare'); r.onsuccess = r.onerror = () => res(); r.onblocked = () => setTimeout(res, 300); } catch { res(); } });
  const dummy = () => { const c = document.createElement('canvas'); c.width = c.height = 96; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 96, 96); x.strokeRect(20, 20, 50, 50); return c; };
  /** (Re)load the app in the iframe with empty storage, warm the face models. Returns warm-up ms. */
  B.openApp = async function (name) {
    B.appName = name; B.loadedName = name;
    frame = document.getElementById('app');
    frame.src = 'about:blank'; await sleep(30);
    await deleteDb();
    try { localStorage.setItem('sinopia:interaction-sounds', 'off'); } catch { /* ignore */ }
    const t0 = performance.now();
    await new Promise((res, rej) => { frame.onload = res; frame.onerror = rej; frame.src = `/app-${name}/index.html?bench=${Date.now()}`; });
    W = frame.contentWindow;
    for (let i = 0; i < 200 && !(W.DrawingCompare && W.DrawingCompare.app && W.DrawingCompare.Subjects && W.DrawingCompare.Aligner); i++) await sleep(50);
    DC = W.DrawingCompare; muteFrame(W); fastTimers(W);
    if (!(DC && DC.app)) throw new Error('app did not initialise');
    await DC.app.restored;
    if (B.alignRotation && DC.app.state) DC.app.state.alignRotation = true;
    if (DC.Subjects) DC.Subjects.calibrate = !!B.calibrate; // calibration runs keep every face fit as uncertain and record its evidence
    // The baseline app is subjects-aware; a variant may lack DC.Subjects. Warm only when present.
    if (DC.Subjects) {
      await DC.Subjects.analyze({ source: dummy(), rotation: 0, flipH: false, flipV: false });
      for (let i = 0; i < 40 && !(W.faceapi && W.faceapi.nets.tinyFaceDetector.isLoaded && W.faceapi.nets.faceLandmark68TinyNet.isLoaded); i++) await sleep(250);
      if (!(W.faceapi && W.faceapi.nets.faceLandmark68TinyNet.isLoaded)) throw new Error('face models not loaded');
    }
    return performance.now() - t0;
  };
  /** Belt and braces: no audio may play from the app iframe. */
  function muteFrame(w) {
    try { w.AudioContext = w.webkitAudioContext = undefined; w.HTMLMediaElement.prototype.play = () => Promise.resolve(); w.speechSynthesis && w.speechSynthesis.cancel(); } catch { /* ignore */ }
    try { if (w.DrawingCompare && w.DrawingCompare.sound) w.DrawingCompare.sound.play = () => {}; } catch { /* ignore */ }
  }
  B.muteFrame = muteFrame;
  /** Background tabs clamp setTimeout(0..) to ~1 s, which would inflate the app's own pause() calls; run short timers through a MessageChannel instead (harness-only, app source untouched). */
  function fastTimers(w) {
    try {
      const orig = w.setTimeout.bind(w), ch = new w.MessageChannel(), q = [];
      ch.port1.onmessage = () => { const f = q.shift(); if (f) f(); };
      w.setTimeout = function (fn, d, ...a) { if (typeof fn === 'function' && (!d || d <= 40)) { q.push(() => fn(...a)); ch.port2.postMessage(0); return 0; } return orig(fn, d, ...a); };
    } catch { /* ignore */ }
  }
  B.fastTimers = fastTimers;
  let opened = 0;
  async function ensureApp(name, freshEvery) {
    if (!DC || B.loadedName !== name || opened >= freshEvery) { opened = 0; B.warmMs = await B.openApp(name); }
    opened++;
  }

  const decMemo = new WeakMap();
  const ORI = { rotation: 0, flipH: false, flipV: false };
  /** Direct estimator call, the same sequence as app.matchPair / retakeDrawing. */
  async function directMatch(movBlob, fixBlob, options) {
    const A = DC.Aligner;
    const dec = async b => { let c = decMemo.get(b); if (!c || c.W !== W) { c = { W, canvas: await DC.decodeImage(b) }; decMemo.set(b, c); } return c.canvas; };
    const mov = await dec(movBlob), fix = await dec(fixBlob);
    const t0 = performance.now();
    const base = DC.app.alignOptions ? DC.app.alignOptions({ retake: !!(options && options.preferStructure) }) : {};
    const res = await A.estimate(A.rasterize({ source: mov, ...ORI }), A.rasterize({ source: fix, ...ORI }), null, { ...base, ...(options || {}) });
    B.lastOptions = { ...base, ...(options || {}) };
    return summariseRes(res, performance.now() - t0, mov, fix);
  }
  function outcomeOf(res) { return !res || res.cancelled ? 'error' : res.confident ? 'confident' : res.approximate ? 'approximate' : 'declined'; }
  function summariseRes(res, ms, mov, fix) {
    const o = outcomeOf(res);
    return { outcome: o, method: res && res.method || 'structural', ncc: res && r4(res.ncc), psr: res && r4(res.psr), ms: Math.round(ms), M: o === 'confident' || o === 'approximate' ? { s: res.s, th: res.theta, x: res.tx, y: res.ty } : null, ev: res && res.evidence || undefined, why: res && res.why && res.why.length ? res.why : undefined, mov, fix };
  }

  /** End-to-end: fresh easel, app.loadInto('reference'), app.loadInto('drawing'), wait for the auto-align and read the layers. */
  async function e2eMatch(movBlob, fixBlob, freshEvery = 1) {
    await ensureApp(B.appName, freshEvery);
    const app = DC.app, A = DC.Aligner;
    // Reset between cases when reusing the page
    if (opened > 1) { for (const slot of ['drawing', 'reference']) for (const r of app.shelf.list(slot).slice()) await app.removePhoto(slot, r.id).catch(() => {}); await sleep(30); }
    let captured = null, resolveCap, t0 = 0;
    const cap = new Promise(r => (resolveCap = r));
    const orig = A.estimate;
    A.estimate = async function (...a) { t0 = performance.now(); try { const r = await orig.apply(this, a); captured = { res: r, ms: performance.now() - t0 }; return r; } finally { resolveCap(); } };
    try {
      await app.loadInto('reference', fixBlob);
      await sleep(30);
      const tl = performance.now();
      await app.loadInto('drawing', movBlob);
      await Promise.race([cap, sleep(60000)]);
      if (!captured) return { outcome: 'error', method: 'no-estimate', ms: Math.round(performance.now() - tl), M: null, note: 'estimate was never called (layout?)' };
      // wait for the glide animation to settle (rAF may be throttled: also bounded by timeout)
      const d = app.layers.drawing, r = app.layers.reference;
      let last = '', stable = 0;
      const willMove = captured.res && captured.res.confident || (captured.res && captured.res.approximate && !app.getOffer);
      if (willMove) await sleep(850); else await sleep(120);
      for (let i = 0; i < 80 && stable < 4 && willMove; i++) { await sleep(60); const k = [d.x, d.y, d.scale, d.angle].map(v => v.toFixed(4)).join(); stable = k === last ? stable + 1 : 0; last = k; }
      const out = summariseRes(captured.res, captured.ms, null, null);
      if (out.outcome === 'approximate' && typeof app.getOffer === 'function') { out.outcome = app.getOffer() && !d.aligned ? 'offered' : 'approximate'; if (out.outcome === 'offered') { out.layerAligned = false; out.offered = true; } }
      out.wallMs = Math.round(performance.now() - tl);
      if (out.M && out.outcome !== 'offered') { // transform actually applied to the layers (what the user sees)
        const c = Math.cos(-r.angle), s = Math.sin(-r.angle), dx = d.x - r.x, dy = d.y - r.y;
        out.Mapp = { s: d.scale / r.scale, th: wrap(d.angle - r.angle), x: (c * dx - s * dy) / r.scale, y: (s * dx + c * dy) / r.scale };
        out.layerAligned = !!d.aligned;
        out.layerMismatch = r4(Math.hypot(out.Mapp.x - out.M.x, out.Mapp.y - out.M.y) + Math.abs(Math.log(out.Mapp.s / out.M.s)) * 100 + Math.abs(wrap(out.Mapp.th - out.M.th)) * 100);
        out.M = out.Mapp; // headline: read back from layers
      } else out.layerAligned = !!d.aligned;
      try { out.faces = [d, r].map(l => (DC.Subjects ? null : null)); } catch { /* ignore */ }
      if (DC.Subjects) { // detector results are cached per source canvas: cheap
        const nf = async l => (await DC.Subjects.analyze({ source: l.source, ...ORI })).faces.length;
        out.faces = [await nf(d), await nf(r)];
      }
      return out;
    } finally { A.estimate = orig; }
  }

  // ------------------------------------------------------------------ thumbnails
  function thumb(ref, drawing, M, marks = []) {
    const TW = 240, k = TW / ref.width, c = document.createElement('canvas'); c.width = TW; c.height = Math.round(ref.height * k);
    const x = c.getContext('2d'); x.drawImage(ref, 0, 0, c.width, c.height);
    if (M && drawing) {
      x.save(); x.globalCompositeOperation = 'multiply'; x.globalAlpha = 0.65;
      x.translate(c.width / 2 + M.x * k, c.height / 2 + M.y * k); x.rotate(M.th); x.scale(M.s * k, M.s * k); x.translate(-drawing.width / 2, -drawing.height / 2);
      x.drawImage(drawing, 0, 0); x.restore();
    }
    for (const m of marks) { x.strokeStyle = m.color; x.lineWidth = 1.5; x.beginPath(); x.arc(c.width / 2 + m.p.x * k, c.height / 2 + m.p.y * k, m.r || 3, 0, 7); x.stroke(); }
    if (!M) { x.fillStyle = 'rgba(200,0,0,.8)'; x.font = '12px sans-serif'; x.fillText('declined', 6, 14); }
    return c.toDataURL('image/jpeg', 0.6);
  }
  /** keep a bounded, useful sample of thumbnails: all-bad up to maxBad, first maxGood good ones */
  function keepThumb(state, bad) { const k = bad ? 'bad' : 'good'; state[k] = (state[k] || 0) + 1; return state[k] <= (bad ? 30 : 10); }

  // ------------------------------------------------------------------ result persistence
  async function loadResults(app, suite) {
    try { const r = await fetch(`/bench/results/${app}-${suite}.json`, { cache: 'no-store' }); if (r.ok) return await r.json(); } catch { /* none */ }
    return null;
  }
  async function saveResults(app, suite, obj) {
    const r = await fetch(`/bench/results/${app}-${suite}.json`, { method: 'POST', body: JSON.stringify(obj) });
    if (!r.ok) throw new Error('save failed ' + r.status);
  }

  // ------------------------------------------------------------------ generic runner
  let stopFlag = false;
  B.stop = () => { stopFlag = true; };
  /** opts: app, suite, n (max total cases in the file), mode, fresh (reload app every N cases), reset (ignore saved) */
  B.start = function (opts) { return run(opts).catch(e => { B.state.status = 'error'; B.state.err = String(e && e.stack || e); console.error(e); }); };
  async function run(opts) {
    stopFlag = false;
    const { app, suite } = opts, def = B.suites[suite];
    if (!def) throw new Error('unknown suite ' + suite);
    const S = B.state; Object.assign(S, { status: 'loading', suite, app, done: 0, total: 0, msg: 'listing cases', err: null });
    B.appName = app; B.alignRotation = !!opts.rot; B.calibrate = !!opts.calibrate; const label = opts.label || (opts.rot ? app + '-rot' : app);
    const prev = opts.reset ? null : await loadResults(label, suite);
    const results = prev && prev.cases ? prev : { meta: { app, label, rot: !!opts.rot, suite, version: B.version, mode: opts.mode || def.defaultMode || 'e2e', created: new Date().toISOString() }, cases: [] };
    results.meta.ua = navigator.userAgent; results.meta.updated = new Date().toISOString();
    const done = new Set(results.cases.map(c => c.id));
    const all = await def.list(opts);
    const n = Math.min(opts.n || all.length, all.length);
    const todo = all.slice(0, n);
    S.total = todo.length; S.done = todo.filter(c => done.has(c.id)).length;
    const thumbState = results.thumbState || (results.thumbState = {});
    let lastSave = performance.now(), sinceSave = 0;
    S.status = 'running';
    const ctx = { opts, thumbState, mode: results.meta.mode };
    if (def.setup) await def.setup(ctx, all);
    for (const item of todo) {
      if (stopFlag) { S.status = 'stopped'; break; }
      if (done.has(item.id)) continue;
      S.msg = item.id;
      const t0 = performance.now();
      let rec;
      try { rec = await def.runCase(item, ctx); }
      catch (e) { rec = { outcome: 'error', error: String(e && e.message || e), ms: Math.round(performance.now() - t0) }; DC = null; }
      try { rec.appUrl = frame.contentWindow.location.pathname + (B.alignRotation ? '#rot' : ''); } catch { /* ignore */ }
      rec.id = item.id; rec.params = rec.params || item.params; results.cases.push(rec); done.add(item.id);
      S.done++; S.lastMs = Math.round(performance.now() - t0); sinceSave++;
      if (sinceSave >= 10 || performance.now() - lastSave > 30000) { await saveResults(label, suite, results); sinceSave = 0; lastSave = performance.now(); }
    }
    if (def.finish) await def.finish(ctx, results);
    results.meta.updated = new Date().toISOString();
    results.meta.counts = { cases: results.cases.length, planned: all.length };
    await saveResults(label, suite, results);
    if (S.status !== 'stopped') S.status = 'finished';
    S.summary = window.Summ ? window.Summ.summarize(suite, results.cases) : null;
    return results;
  }

  // ------------------------------------------------------------------ suite 1: CUFS known transform
  const CORE = [16, 18, 17, 20, 22, 25, 6, 0];
  B.suites.cufs = {
    defaultMode: 'e2e',
    async list(opts) {
      B.cufs = B.cufs || await fetchJson(DATA + 'cufs/manifest.json');
      const items = shuffled(B.cufs.items, 'cufs-order');
      const cases = [];
      // interleave: every third pair also gets a tilt case; ordering keeps any prefix representative
      items.forEach((it, i) => { cases.push({ id: `${it.id}|r0`, it, tilt: false }); });
      const tilt = items.filter((_, i) => i % 3 === 0).map(it => ({ id: `${it.id}|tilt`, it, tilt: true }));
      const out = []; let ti = 0;
      cases.forEach((c, i) => { out.push(c); if (i % 3 === 2 && ti < tilt.length) out.push(tilt[ti++]); });
      return out.concat(tilt.slice(ti));
    },
    async runCase(c, ctx) {
      const it = c.it, rnd = rng('cufs|' + c.id);
      const sk = await loadCanvas(DATA + 'cufs/' + it.sketch), photo = await loadCanvas(DATA + 'cufs/' + it.photo);
      if (sk.width !== it.sketch_width || photo.width !== it.photo_width) throw new Error('size mismatch');
      const S = centred(it.sketch_points, sk.width, sk.height), P = centred(it.photo_points, photo.width, photo.height);
      const iod = dist(P[16], P[18]);
      const gSim = fitSim(S, P, true), gST = fitSim(S, P, false);
      const nme = (T, idx) => mean(idx.map(i => dist(apply(T, S[i]), P[i]))) / iod;
      const all = [...S.keys()];
      // random known transform keeping every landmark inside the frame
      const tiltDeg = c.tilt ? (rnd() < 0.5 ? -1 : 1) * uni(rnd, 2, 8) : 0;
      const K = { s: Math.exp(uni(rnd, Math.log(0.6), Math.log(1.6))), th: tiltDeg * D2R, x: 0, y: 0 };
      const rot = pts => pts.map(p => apply({ ...K, x: 0, y: 0 }, p));
      const R = rot(S), xs = R.map(p => p.x), ys = R.map(p => p.y), mx = sk.width * 0.02, my = sk.height * 0.02;
      const range = (lo, hi, half) => { const a = -half + mx - lo, b = half - mx - hi; return a <= b ? [Math.max(a, -0.4 * 2 * half), Math.min(b, 0.4 * 2 * half)] : [(a + b) / 2, (a + b) / 2]; };
      const rx = range(Math.min(...xs), Math.max(...xs), sk.width / 2), ry = range(Math.min(...ys), Math.max(...ys), sk.height / 2);
      K.x = uni(rnd, Math.min(rx[0], rx[1]), Math.max(rx[0], rx[1])); K.y = uni(rnd, Math.min(ry[0], ry[1]), Math.max(ry[0], ry[1]));
      const drawing = renderTransformed(sk, K);
      const [dBlob, pBlob] = [await toBlob(drawing), await fetchBlob(DATA + 'cufs/' + it.photo)];
      const rec = { params: { tiltDeg: r4(tiltDeg), K: Tround(K) }, gt: { sim: Tround(gSim), st: Tround(gST), nmeSim: r4(nme(gSim, all)), nmeST: r4(nme(gST, all)), iod: r4(iod) } };
      const out = ctx.mode === 'direct' ? await directMatch(dBlob, pBlob) : await e2eMatch(dBlob, pBlob, ctx.opts.fresh || 1);
      Object.assign(rec, { outcome: out.outcome, method: out.method, ncc: out.ncc, psr: out.psr, ms: out.ms, wallMs: out.wallMs, faces: out.faces, layerMismatch: out.layerMismatch, note: out.note, ev: out.ev, why: out.why });
      let marks = [];
      if (out.M) {
        const C = compose(out.M, K); // original sketch -> photo
        rec.M = Tround(out.M);
        rec.m = {
          nme35: r4(nme(C, all)), nmeCore: r4(nme(C, CORE)),
          rotErrDeg: r4(wrap(C.th - gSim.th) / D2R), scaleErrPct: r4((C.s / gSim.s - 1) * 100), appliedRotDeg: r4(out.M.th / D2R),
          posErrIod: r4(dist({ x: C.x, y: C.y }, { x: apply(C, { x: 0, y: 0 }).x, y: apply(C, { x: 0, y: 0 }).y }) * 0),
        };
        delete rec.m.posErrIod;
        marks = CORE.flatMap(i => [{ color: '#2c2', p: P[i], r: 3 }, { color: '#e22', p: apply(C, S[i]), r: 2 }]);
      }
      const bad = !out.M || rec.m.nme35 > 0.15;
      if (keepThumb(ctx.thumbState, bad)) rec.thumb = thumb(photo, drawing, out.M, marks);
      return rec;
    },
  };

  // ------------------------------------------------------------------ suite 2: FS2K self-consistency
  B.suites.fs2k = {
    defaultMode: 'direct',
    async list(opts) {
      B.fs2k = B.fs2k || await fetchJson(DATA + 'fs2k/manifest.json');
      const quota = { 0: 120, 1: 98, 2: 120 }, by = [[], [], []];
      for (const it of shuffled(B.fs2k.items, 'fs2k-order')) if (by[it.style].length < quota[it.style]) by[it.style].push(it);
      const out = [];
      for (let i = 0; i < 130; i++) for (const st of [0, 1, 2]) if (by[st][i]) out.push({ id: by[st][i].id, it: by[st][i] });
      return out;
    },
    async runCase(c, ctx) {
      const it = c.it, rnd = rng('fs2k|' + c.id), t0 = performance.now();
      const sk = await loadCanvas(DATA + 'fs2k/' + it.sketch), ph = await loadCanvas(DATA + 'fs2k/' + it.photo);
      const tiltDeg = rnd() < 0.3 ? (rnd() < 0.5 ? -1 : 1) * uni(rnd, 2, 8) : 0;
      const K = { s: Math.exp(uni(rnd, Math.log(0.6), Math.log(1.6))), th: tiltDeg * D2R, x: uni(rnd, -0.2, 0.2) * sk.width, y: uni(rnd, -0.2, 0.2) * sk.height };
      const drawing = renderTransformed(sk, K);
      const [dBlob, pBlob, sBlob] = [await toBlob(drawing), await fetchBlob(DATA + 'fs2k/' + it.photo), await fetchBlob(DATA + 'fs2k/' + it.sketch)];
      await ensureApp(B.appName, ctx.opts.fresh || 10);
      const run = ctx.mode === 'e2e' ? (m, f) => e2eMatch(m, f, ctx.opts.fresh || 1) : (m, f) => directMatch(m, f);
      const r0 = await run(sBlob, pBlob), r1 = await run(dBlob, pBlob);
      const rec = { style: it.style, params: { tiltDeg: r4(tiltDeg), K: Tround(K) }, o0: r0.outcome, o1: r1.outcome, method0: r0.method, method1: r1.method, ev0: r0.ev, ev1: r1.ev, why0: r0.why, why1: r1.why, m0: Tround(r0.M), m1: Tround(r1.M), ms: r0.ms + r1.ms, sizes: [sk.width, sk.height, ph.width, ph.height] };
      const diag = Math.hypot(ph.width, ph.height);
      const pts = [{ x: 0, y: 0 }, { x: -sk.width / 2, y: -sk.height / 2 }, { x: sk.width / 2, y: -sk.height / 2 }, { x: -sk.width / 2, y: sk.height / 2 }, { x: sk.width / 2, y: sk.height / 2 }];
      if (r0.M && r1.M) {
        const C = compose(r1.M, K); // transformed->photo after undoing K: should equal r0.M
        rec.consistency = { posPct: r4(mean(pts.map(p => dist(apply(C, p), apply(r0.M, p)))) / diag * 100), rotDeg: r4(wrap(C.th - r0.M.th) / D2R), scalePct: r4((C.s / r0.M.s - 1) * 100) };
      }
      if (r0.M && Math.abs(sk.width / sk.height / (ph.width / ph.height) - 1) < 0.02) {
        const I = { s: ph.width / sk.width, th: 0, x: 0, y: 0 };
        rec.abs0 = { posPct: r4(mean(pts.map(p => dist(apply(r0.M, p), apply(I, p)))) / diag * 100), rotDeg: r4(wrap(r0.M.th) / D2R), scalePct: r4((r0.M.s / I.s - 1) * 100) };
      }
      const bad = !rec.consistency || rec.consistency.posPct > 2 || Math.abs(rec.consistency.rotDeg) > 2;
      if (keepThumb(ctx.thumbState, bad)) rec.thumb = thumb(ph, drawing, r1.M && compose(r1.M, { s: 1, th: 0, x: 0, y: 0 }), []);
      rec.wall = Math.round(performance.now() - t0);
      return rec;
    },
  };

  // ------------------------------------------------------------------ detector helpers
  const meanPt = pts => ({ x: mean(pts.map(p => p.x)), y: mean(pts.map(p => p.y)) });
  async function detect(canvas) {
    const t0 = performance.now();
    const entry = await DC.Subjects.analyze({ source: canvas, ...ORI });
    return { faces: entry.faces || [], ms: Math.round(performance.now() - t0) };
  }
  function scoreFaces(faces, E0, E1, M) { // truth: eye centres (image-left, image-right) and mouth centre
    const rec = { nFaces: faces.length, dominant: false };
    if (!faces.length) return rec;
    const sorted = faces.slice().sort((a, b) => b.box.w * b.box.h - a.box.w * a.box.h);
    rec.dominant = !(sorted[1] && sorted[0].box.w * sorted[0].box.h < sorted[1].box.w * sorted[1].box.h * 1.7);
    const mid = { x: (E0.x + E1.x) / 2, y: (E0.y + E1.y) / 2 }, iod = dist(E0, E1);
    // the face whose eye-mid is closest to the true eye-mid, and the largest face
    const pf = f => meanPt([meanPt(f.points.slice(36, 42)), meanPt(f.points.slice(42, 48))]);
    const near = faces.slice().sort((a, b) => dist(pf(a), mid) - dist(pf(b), mid))[0];
    rec.largestOnFace = dist(pf(sorted[0]), mid) < iod; rec.onFace = rec.largestOnFace; // app uses the largest face when dominant
    rec.anyOnFace = dist(pf(near), mid) < iod;
    const f = sorted[0], p = f.points, d0 = meanPt(p.slice(36, 42)), d1 = meanPt(p.slice(42, 48)), dm = meanPt(p.slice(48, 60));
    rec.score = r4(f.score);
    rec.nmeEyes = r4((dist(d0, E0) + dist(d1, E1)) / 2 / iod); rec.nmeMouth = r4(dist(dm, M) / iod);
    rec.nme3 = r4((dist(d0, E0) + dist(d1, E1) + dist(dm, M)) / 3 / iod);
    rec.rollErrDeg = r4(wrap(Math.atan2(d1.y - d0.y, d1.x - d0.x) - Math.atan2(E1.y - E0.y, E1.x - E0.x)) / D2R);
    return rec;
  }
  async function detectorWarm(ctx) { await ensureApp(B.appName, 1e9); }

  B.suites.cufsf = {
    defaultMode: 'direct',
    async list() {
      B.cufsf = B.cufsf || await fetchJson(DATA + 'cufsf/manifest.json');
      return shuffled(B.cufsf.items, 'cufsf-order').map(it => ({ id: it.id, it }));
    },
    setup: ctx => detectorWarm(ctx),
    async runCase(c, ctx) {
      const it = c.it; await ensureApp(B.appName, 40);
      const sk = await DC.decodeImage(await fetchBlob(DATA + 'cufsf/' + it.sketch));
      const [E0, E1, M] = it.sketch_points.map(p => ({ x: p[0], y: p[1] }));
      const { faces, ms } = await detect(sk);
      const rec = { ms, ...scoreFaces(faces, E0, E1, M) };
      const bad = !rec.nFaces || !rec.onFace || rec.nme3 > 0.12;
      if (keepThumb(ctx.thumbState, bad)) {
        const c2 = document.createElement('canvas'), k = 240 / sk.width; c2.width = 240; c2.height = Math.round(sk.height * k);
        const x = c2.getContext('2d'); x.drawImage(sk, 0, 0, c2.width, c2.height);
        x.lineWidth = 1.5; for (const [pt, col] of [[E0, '#2c2'], [E1, '#2c2'], [M, '#2c2']]) { x.strokeStyle = col; x.beginPath(); x.arc(pt.x * k, pt.y * k, 4, 0, 7); x.stroke(); }
        x.strokeStyle = '#e22'; for (const f of faces) { x.strokeRect(f.box.x * k, f.box.y * k, f.box.w * k, f.box.h * k); for (const p of [meanPt(f.points.slice(36, 42)), meanPt(f.points.slice(42, 48)), meanPt(f.points.slice(48, 60))]) { x.beginPath(); x.arc(p.x * k, p.y * k, 2, 0, 7); x.stroke(); } }
        rec.thumb = c2.toDataURL('image/jpeg', 0.6);
      }
      return rec;
    },
  };

  // CUFS photos and sketches through the detector, truth = inferred named points
  B.suites['cufs-det'] = {
    defaultMode: 'direct',
    async list() { B.cufs = B.cufs || await fetchJson(DATA + 'cufs/manifest.json'); return shuffled(B.cufs.items, 'cufsdet').flatMap(it => [{ id: it.id + '|photo', it, kind: 'photo' }, { id: it.id + '|sketch', it, kind: 'sketch' }]); },
    setup: ctx => detectorWarm(ctx),
    async runCase(c, ctx) {
      await ensureApp(B.appName, 40);
      const it = c.it, file = c.kind === 'photo' ? it.photo : it.sketch, pts = c.kind === 'photo' ? it.photo_points : it.sketch_points;
      const img = await DC.decodeImage(await fetchBlob(DATA + 'cufs/' + file));
      const pp = i => ({ x: pts[i][0], y: pts[i][1] });
      const { faces, ms } = await detect(img);
      const mouth = { x: (pts[22][0] + pts[25][0]) / 2, y: (pts[22][1] + pts[25][1]) / 2 };
      const rec = { kind: c.kind, ms, ...scoreFaces(faces, pp(16), pp(18), mouth) };
      return rec;
    },
  };

  // ------------------------------------------------------------------ suite 4: retake
  B.suites.retake = {
    defaultMode: 'direct',
    async list() {
      B.cufsf = B.cufsf || await fetchJson(DATA + 'cufsf/manifest.json'); B.cufs = B.cufs || await fetchJson(DATA + 'cufs/manifest.json'); B.fs2k = B.fs2k || await fetchJson(DATA + 'fs2k/manifest.json');
      const a = shuffled(B.cufsf.items, 'rt1').slice(0, 100).map(it => ({ id: 'cufsf|' + it.id, source: 'cufsf', file: 'cufsf/' + it.sketch }));
      const b = shuffled(B.cufs.items, 'rt2').slice(0, 60).map(it => ({ id: 'cufs|' + it.id, source: 'cufs', file: 'cufs/' + it.sketch }));
      const d = shuffled(B.fs2k.items, 'rt3').slice(0, 60).map(it => ({ id: 'fs2k|' + it.id, source: 'fs2k', file: 'fs2k/' + it.sketch }));
      return shuffled([...a, ...b, ...d], 'rt-all');
    },
    setup: ctx => detectorWarm(ctx),
    async runCase(c, ctx) {
      await ensureApp(B.appName, 60);
      const rnd = rng('retake|' + c.id), sk = await loadCanvas(DATA + c.file);
      const K = { s: uni(rnd, 0.9, 1.1), th: uni(rnd, -3, 3) * D2R, x: uni(rnd, -0.04, 0.04) * sk.width, y: uni(rnd, -0.04, 0.04) * sk.height };
      const deg = { blur: uni(rnd, 0.4, 1.4), brightness: uni(rnd, 0.85, 1.12), contrast: uni(rnd, 0.85, 1.1), paper: '#' + [0, 1, 2].map(() => (235 + Math.floor(rnd() * 20)).toString(16)).join('') };
      const retaken = renderTransformed(sk, K, deg);
      const old = await fetchBlob(DATA + c.file);
      const out = await directMatch(await toBlob(retaken), old, { preferStructure: true });
      const diag = Math.hypot(sk.width, sk.height), pts = [{ x: 0, y: 0 }, { x: -sk.width / 2, y: -sk.height / 2 }, { x: sk.width / 2, y: -sk.height / 2 }, { x: -sk.width / 2, y: sk.height / 2 }, { x: sk.width / 2, y: sk.height / 2 }];
      const rec = { source: c.source, params: { K: Tround(K), tiltDeg: r4(K.th / D2R), ...deg }, outcome: out.outcome, method: out.method, ms: out.ms, ncc: out.ncc, psr: out.psr, M: Tround(out.M), ev: out.ev, why: out.why };
      let M2 = out.M; // retaken -> old; truth = inverse(K)
      if (M2) { const E = compose(M2, K); rec.m = { posPct: r4(mean(pts.map(p => dist(apply(E, p), p))) / diag * 100), rotDeg: r4(wrap(E.th) / D2R), scalePct: r4((E.s - 1) * 100) }; }
      const bad = !M2 || rec.m.posPct > 1;
      if (keepThumb(ctx.thumbState, bad)) rec.thumb = thumb(sk, retaken, M2, []);
      return rec;
    },
  };

  // ------------------------------------------------------------------ suite 5: PoPArt placeholder
  B.suites.poparts = {
    defaultMode: 'stats',
    async list() { return [{ id: 'stats' }]; },
    async runCase(c, ctx) {
      const man = await fetchJson(DATA + 'poparts/manifest.json'), its = man.items;
      const w = its.map(i => i.width), h = its.map(i => i.height), Sm = window.Summ;
      const figs = its.flatMap(i => i.figures || []), kp = figs.flatMap(f => f.keypoints);
      const stats = {
        images: its.length, splits: Object.entries(its.reduce((o, i) => ((o[i.split] = (o[i.split] || 0) + 1), o), {})).map(e => e.join(':')).join(' '),
        'labelled figures': figs.length, 'figures with >=13 keypoints': figs.filter(f => f.num_keypoints >= 13).length,
        'images with >=1 figure': its.filter(i => (i.figures || []).length).length, 'visible keypoints (v=2) share of all slots': kp.filter(k => k[2] === 2).length / kp.length,
        'width median': Sm.med(w), 'height median': Sm.med(h), 'max side p90': Sm.p90(its.map(i => Math.max(i.width, i.height))),
        'body alignment in the app': 'none yet (phase 3 placeholder): this suite only records dataset statistics', 'skipped (long path)': (man.skipped_missing_files || []).length,
      };
      // a few sample thumbnails with keypoints drawn (rendered, not copied)
      const samples = [];
      for (const it of shuffled(its.filter(i => (i.figures || []).some(f => f.num_keypoints >= 13)), 'pop').slice(0, 4)) {
        const cv = await loadCanvas(DATA + 'poparts/' + it.image), k = 160 / Math.max(cv.width, cv.height), t = document.createElement('canvas'); t.width = Math.round(cv.width * k); t.height = Math.round(cv.height * k);
        const x = t.getContext('2d'); x.drawImage(cv, 0, 0, t.width, t.height); x.fillStyle = '#e22';
        for (const f of it.figures) for (const q of f.keypoints) if (q[2]) { x.beginPath(); x.arc(q[0] * k, q[1] * k, 2.2, 0, 7); x.fill(); }
        samples.push(t.toDataURL('image/jpeg', 0.6));
      }
      return { outcome: 'n/a', ms: 0, stats, thumbs: samples };
    },
  };

  B.e2eMatch = e2eMatch; B.directMatch = directMatch; B.getApp = () => ({ W, DC, frame }); B.fetchBlob = fetchBlob; B.loadCanvas = loadCanvas;
  B.stat = () => JSON.stringify(B.state);
})();









