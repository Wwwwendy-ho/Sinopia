// Analysis framework for the Proportions robustness work: loads the captured landmarks (cap-*.json), evaluates the APP's engine.
const DC_ = DrawingCompare, P = DC_.Proportions;
const AN = window.AN = { data: {}, cfg: {} };
const q = (a, p) => { if (!a.length) return NaN; const s = a.slice().sort((x, y) => x - y), i = (s.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); };
const mean = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : NaN;
const med = a => q(a, .5);
const r1 = v => Math.round(v * 10) / 10, r2 = v => Math.round(v * 100) / 100;
const pct = (n, d) => d ? Math.round(1000 * n / d) / 10 : null;
const unflat = a => { const o = new Array(a.length / 2); for (let i = 0; i < o.length; i++) o[i] = { x: a[2 * i], y: a[2 * i + 1] }; return o; };
function fnv(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
AN.half = id => (fnv('split-v1:' + id) >>> 3) & 1; // 0 = calibration, 1 = held-out
AN.q = q; AN.mean = mean; AN.r1 = r1; AN.r2 = r2; AN.pct = pct;
AN.fetchJson = async u => { const r = await fetch(u, { cache: 'no-store' }); if (!r.ok) throw new Error(u + ' ' + r.status); return r.json(); };
AN.loadSet = async name => { const idx = await AN.fetchJson(`/bench/results/cap-${name}-index.json`); let rows = []; for (let k = 0; k < idx.chunks; k++) rows = rows.concat((await AN.fetchJson(`/bench/results/cap-${name}-${k}.json`)).rows); return rows; };
AN.load = async (names) => { for (const n of names) { AN.data[n] = await AN.loadSet(n); } return Object.fromEntries(names.map(n => [n, AN.data[n].length])); };
// feature sets, cached per face record
const fsCache = new WeakMap();
AN.fs = face => { if (!face) return null; let f = fsCache.get(face); if (!f) { f = P.features(unflat(face.p), 'mediapipe'); fsCache.set(face, f); } return f; };
AN.clone = fs => ({ source: fs.source, flipped: fs.flipped, points: Object.fromEntries(Object.entries(fs.points).map(([k, v]) => [k, v && { x: v.x, y: v.y }])) });
AN.rawPt = (face, i) => ({ x: face.p[2 * i], y: face.p[2 * i + 1] });
/** evaluate a pair: returns {rep, al} using the app engine (opts: align + measure options). */
AN.run = (dFace, rFace, opts, mod) => {
  let D = AN.fs(dFace), R = AN.fs(rFace); if (!D || !R) return null;
  if (mod) { D = AN.clone(D); R = AN.clone(R); mod(D, R, dFace, rFace); }
  const al = P.align(D, R, opts || {}); if (!al.ok) return null;
  return { rep: P.measure(D, R, al, opts || {}), al, D, R };
};
