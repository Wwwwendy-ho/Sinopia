// Hand-drawn construction primitives. Deterministic (seeded) so the output is stable.
let _s = 7;
const seed = n => { _s = n; };
const rnd = () => { _s = (_s * 16807) % 2147483647; return _s / 2147483647; };
const j = a => (rnd() * 2 - 1) * a;
const f = n => String(Math.round(n * 10) / 10);
const TAU = Math.PI * 2;

function smooth(pts) {
  let d = 'M' + f(pts[0][0]) + ' ' + f(pts[0][1]);
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    d += 'C' + f(p1[0] + (p2[0] - p0[0]) / 6) + ' ' + f(p1[1] + (p2[1] - p0[1]) / 6) + ' ' +
      f(p2[0] - (p3[0] - p1[0]) / 6) + ' ' + f(p2[1] - (p3[1] - p1[1]) / 6) + ' ' + f(p2[0]) + ' ' + f(p2[1]);
  }
  return d;
}
// straight guideline with overshoot and a faint bow
function line(x1, y1, x2, y2, o = {}) {
  const L = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / L, uy = (y2 - y1) / L;
  const over = o.over ?? Math.min(14, 4 + L * .03), w = o.wob ?? Math.min(1.6, .35 + L * .0022);
  const a = [x1 - ux * over * (.5 + rnd()), y1 - uy * over * (.5 + rnd())], b = [x2 + ux * over * (.5 + rnd()), y2 + uy * over * (.5 + rnd())];
  const n = Math.max(2, Math.round(L / 260) + 1), pts = [];
  for (let i = 0; i <= n; i++) { const t = i / n, k = (i > 0 && i < n) ? j(w) : 0; pts.push([a[0] + (b[0] - a[0]) * t - uy * k, a[1] + (b[1] - a[1]) * t + ux * k]); }
  return smooth(pts);
}
// hand ellipse / circle / arc. sweep > TAU gives the overlap where the stroke closes.
function ell(cx, cy, rx, ry, o = {}) {
  const rot = (o.rot || 0) * Math.PI / 180, full = o.sweep === undefined;
  const a0 = o.a0 !== undefined ? o.a0 * Math.PI / 180 : rnd() * TAU, sweep = full ? TAU + .1 + rnd() * .12 : o.sweep * Math.PI / 180;
  const wob = o.wob ?? .009, e1 = j(wob), p1 = rnd() * TAU, e2 = j(wob * .7), p2 = rnd() * TAU, drift = full ? j(.007) : 0;
  const n = Math.max(3, Math.ceil(Math.abs(sweep) / (Math.PI / 8))), pts = [], c = Math.cos(rot), s = Math.sin(rot);
  for (let i = 0; i <= n; i++) {
    const t = a0 + sweep * i / n, k = 1 + e1 * Math.cos(t + p1) + e2 * Math.cos(2 * t + p2) + drift * i / n;
    const x = rx * k * Math.cos(t), y = ry * k * Math.sin(t);
    pts.push([cx + x * c - y * s, cy + x * s + y * c]);
  }
  return smooth(pts);
}
const curve = (pts, ox = 0, oy = 0, sx = 1, sy = 1) => smooth(pts.map(p => [ox + p[0] * sx, oy + p[1] * sy]));
const tick = (x, y, len = 8, vert = false) => vert ? line(x, y - len / 2, x, y + len / 2, { over: 1, wob: 0 }) : line(x - len / 2, y, x + len / 2, y, { over: 1, wob: 0 });
const cross = (x, y, r = 5) => line(x - r, y - r + j(1), x + r, y + r + j(1), { over: 1, wob: 0 }) + line(x - r, y + r + j(1), x + r, y - r + j(1), { over: 1, wob: 0 });
const plus = (x, y, r = 6) => line(x - r, y, x + r, y, { over: 1, wob: 0 }) + line(x, y - r, x, y + r, { over: 1, wob: 0 });
function arrow(x1, y1, x2, y2, h = 6) {
  const a = Math.atan2(y2 - y1, x2 - x1);
  return line(x1, y1, x2, y2, { over: 0 }) + 'M' + f(x2 - h * Math.cos(a - .5)) + ' ' + f(y2 - h * Math.sin(a - .5)) + 'L' + f(x2) + ' ' + f(y2) + 'L' + f(x2 - h * Math.cos(a + .5)) + ' ' + f(y2 - h * Math.sin(a + .5));
}
const DIG = {
  1: 'M1 3 3.4 .6 3.2 10', 2: 'M.8 2.6C1.6 .2 5.2 .2 5.2 2.8 5.2 5 2.4 7 .6 9.8L5.8 9.6',
  3: 'M1 1.6C3 .2 5.4 1 5 3 4.6 4.6 3 5 2.2 5 4 5 5.6 6 5.4 7.8 5 10 2 10.2 .6 8.6', 4: 'M4.4 10 4.6 .6 .6 6.8 6 6.6',
  5: 'M5.2 .8 1.6 1 1.2 4.6C3 3.6 5.6 4.4 5.4 7 5.2 9.8 2.2 10.2 .6 8.6', 6: 'M4.8 .8C2.4 2 .8 4.6 1 7.4 1.2 10 5 10.2 5.2 7.4 5.4 4.8 2 4.6 1.1 6.8',
  7: 'M.8 1 5.6 .8 2.4 10', 8: 'M3 5C1 4 1.2 .8 3.2 .8 5.2 .8 5.2 4 3 5 .6 6 .6 9.8 3 9.8 5.6 9.8 5.4 6 3 5', '/': 'M5 .4 1 10.4', ':': 'M3 3v.2M3 7.6v.2'
};

// a layer collects path data per pencil
function Layer() {
  const L = { b: '', b2: '', g: '', g2: '', r: '', x: '' };
  L.add = (k, d) => { L[k] += d; return L; };
  L.num = (k, str, x, y, s = 1) => { let cx = x; for (const ch of String(str)) { L.x += '<path class="' + k + '" transform="translate(' + f(cx) + ' ' + f(y) + ') scale(' + s + ') rotate(' + f(j(5)) + ' 3 5)" d="' + DIG[ch] + '"/>'; cx += (ch === '/' || ch === ':' ? 5.5 : 7.5) * s; } return L; };
  L.svg = () => ['b2', 'b', 'g2', 'g', 'r'].filter(k => L[k]).map(k => '<path class="' + k + '" d="' + L[k] + '"/>').join('\n') + '\n' + L.x;
  return L;
}

/* ---------- Loomis head, front view. (cx, cy) = centre of the cranium ball = brow line; R = ball radius.
   top of head cy-R, hairline cy-2R/3, brow cy, nose cy+2R/3, chin cy+4R/3; eye line at half height = cy+R/6. */
function loomisFront(L, cx, cy, R, o = {}) {
  const T = 2 * R / 3, sx = .745 * R, w = 2 * sx / 5;
  L.add('b', ell(cx, cy, R, R));
  L.add('b', ell(cx - .8 * R, cy, .075 * R, T * .98) + ell(cx + .8 * R, cy, .075 * R, T * .98));           // side planes seen nearly edge on
  L.add('b', line(cx, cy - R - 18, cx, cy + 2 * T + 22));                                                 // centre line
  const gw = o.guide ?? 1.12 * R;
  L.add('b', line(cx - gw, cy, cx + gw, cy));                                                             // brow
  L.add('b2', line(cx - gw * .92, cy - T, cx + gw * .92, cy - T) + line(cx - gw * .92, cy + T, cx + gw * .92, cy + T) + line(cx - gw * .7, cy + 2 * T, cx + gw * .7, cy + 2 * T));
  L.add('b2', line(cx - sx, cy + R / 6, cx + sx, cy + R / 6, { over: 6 }));                               // eye line (half the head)
  L.add('b2', line(cx - .42 * R, cy + T + T / 3, cx + .42 * R, cy + T + T / 3, { over: 4 }));             // mouth line, 1/3 down from nose to chin
  const jaw = s => curve([[.745, -.12], [.75, .32], [.7, .7], [.56, .98], [.3, 1.24], [.13, 1.325], [-.02, 1.335]], cx, cy, s * R, R);
  L.add('g', jaw(1) + jaw(-1));
  const ear = s => curve([[.78, .04], [.9, .0], [.94, .2], [.9, .46], [.82, .66], [.775, .62]], cx, cy, s * R, R);
  L.add('g', ear(1) + ear(-1));
  // eyes: five eye-widths across the head, one eye-width between the eyes
  const ey = cy + R / 6;
  for (const s of [-1, 1]) {
    const ex = cx + s * w;
    L.add('g', curve([[-.5, .04], [-.3, -.26], [.05, -.34], [.34, -.2], [.5, .06]], ex, ey, s * w, w) + curve([[-.5, .04], [-.25, .2], [.1, .24], [.36, .16], [.5, .06]], ex, ey, s * w, w));
    L.add('g2', ell(ex, ey - .03 * w, .21 * w, .21 * w));
  }
  for (let i = 0; i <= 5; i++) L.add('r', tick(cx - sx + i * w, ey, 9, true));
  L.add('g', curve([[-.5, -.05], [-.34, .1], [-.1, .06], [0, .14], [.1, .06], [.34, .1], [.5, -.05]], cx, cy + T, w * 1.05, w));   // nose base, one eye wide
  L.add('g', curve([[-.8, 0], [-.3, .05], [0, -.02], [.3, .05], [.8, 0]], cx, cy + T + T / 3, w, w));
  L.add('g2', line(cx - .34 * R, cy + 1.22 * R, cx - .38 * R, cy + 1.62 * R, { over: 3 }) + line(cx + .34 * R, cy + 1.22 * R, cx + .38 * R, cy + 1.62 * R, { over: 3 })); // neck
  for (const y of [cy - T, cy, cy + T, cy + 2 * T]) L.add('r', cross(cx, y, Math.max(3, R * .018)));
  return { T, sx, w, ey };
}

/* ---------- Loomis head, three-quarter view. s = +1: face turned to the viewer's left (side plane on the right). */
function loomis34(L, cx, cy, R, s = 1, o = {}) {
  const T = 2 * R / 3, X = v => cx + s * v * R, Y = v => cy + v * R, P = pts => smooth(pts.map(p => [X(p[0]), Y(p[1])]));
  L.add('b', ell(cx, cy, R, R));
  const px = .36;                                                           // side-plane centre
  L.add('b', ell(X(px), cy, .47 * R, T, { rot: s * 4 }));                    // the flat side of the ball
  L.add('b', line(X(px - .5), cy + s * .02 * R, X(px + .5), cy - s * .02 * R, { over: 5 }) + line(X(px + .03), cy - T - 8, X(px - .03), cy + T + 8, { over: 5 })); // cross on the side plane
  // brow line wraps the ball from the side plane round to the far side
  L.add('b', P([[px - .47, 0], [-.3, .07], [-.5, .075], [-.8, .04], [-.985, -.03]]));      // brow line wraps the ball
  L.add('b2', P([[-.04, -.6], [-.26, -.645], [-.48, -.66], [-.7, -.63]]));                 // hairline
  L.add('b2', P([[px - .2, .66], [-.3, .72], [-.5, .725], [-.84, .69]]));                  // nose line
  // centre line of the face: over the ball, then straight down to the chin
  L.add('b', P([[-.2, -.98], [-.36, -.8], [-.47, -.42], [-.5, .07], [-.505, .72], [-.48, 1.37]]));
  // jaw and far contour of the face
  L.add('g', P([[px + .1, .6], [px + .03, .86], [px - .14, 1.03], [-.1, 1.22], [-.32, 1.35], [-.48, 1.38]]));
  L.add('g', P([[-.985, -.02], [-.945, .16], [-.9, .3], [-.92, .5], [-.88, .76], [-.78, 1.06], [-.64, 1.3], [-.48, 1.38]]));
  L.add('g', P([[-.51, .12], [-.58, .4], [-.7, .63], [-.63, .73], [-.5, .72]]));           // nose wedge on the centre line
  L.add('g', P([[px + .1, .04], [px + .3, -.02], [px + .34, .3], [px + .22, .62], [px + .1, .66], [px + .07, .5]]));  // ear, brow line to nose line
  const ey = 1 / 6;                                                                        // eyes on the half-height line
  L.add('b2', P([[px - .44, ey + .02], [-.3, ey + .075], [-.5, ey + .08], [-.92, ey + .03]]));
  L.add('g', P([[-.08, ey + .08], [-.18, ey], [-.3, ey - .01], [-.39, ey + .08]]) + P([[-.08, ey + .08], [-.2, ey + .13], [-.31, ey + .13], [-.39, ey + .08]]));
  L.add('g', P([[-.62, ey + .08], [-.69, ey], [-.79, ey], [-.85, ey + .07]]) + P([[-.62, ey + .08], [-.7, ey + .12], [-.79, ey + .12], [-.85, ey + .07]]));
  L.add('g', P([[-.24, .98], [-.4, 1.0], [-.5, .96], [-.64, .98]]));                       // mouth
  L.add('g2', P([[px + .1, 1.0], [px + .2, 1.4], [px + .26, 1.72]]) + P([[-.22, 1.3], [-.18, 1.52], [-.16, 1.74]]));  // neck
  for (const p of [[-.42, -.66], [-.5, .07], [-.505, .72], [-.48, 1.37]]) L.add('r', cross(X(p[0]), Y(p[1]), Math.max(3, R * .018)));
  return { T };
}

/* ---------- Construction eye. w = width corner to corner; s = +1 puts the tear duct on the right. */
function eye(L, cx, cy, w, s = 1, o = {}) {
  const P = pts => smooth(pts.map(p => [cx + s * p[0] * w, cy + p[1] * w]));
  L.add('b', line(cx - w * .68, cy + .03 * w, cx + w * .68, cy + .03 * w));                         // eye-line axis
  L.add('b', ell(cx - s * .03 * w, cy - .01 * w, .195 * w, .195 * w));                             // whole iris, as constructed
  L.add('b2', line(cx - s * .03 * w, cy - .33 * w, cx - s * .03 * w, cy + .28 * w, { over: 3 }));   // iris centre line
  L.add('g', P([[-.5, .03], [-.42, -.06], [-.25, -.15], [-.03, -.185], [.2, -.14], [.36, -.04], [.45, .045]]));      // upper lid
  L.add('g', P([[-.5, .03], [-.36, .105], [-.12, .168], [.14, .16], [.32, .115], [.43, .085]]));                      // lower lid
  L.add('g', P([[.4, -.005], [.47, .03], [.525, .078], [.47, .098], [.43, .085]]));                                  // tear duct
  L.add('g2', P([[-.47, -.08], [-.34, -.18], [-.12, -.255], [.12, -.245], [.32, -.16], [.45, -.05]]));               // crease
  L.add('g2', P([[-.42, .1], [-.14, .19], [.14, .185], [.36, .13]]));                                              // lower lid thickness
  L.add('g', ell(cx - s * .03 * w, cy - .01 * w, .08 * w, .08 * w));                                            // pupil
  L.add('g', ell(cx - s * .09 * w, cy - .075 * w, .032 * w, .032 * w));                                             // highlight
  if (o.brow) L.add('g2', P([[-.6, -.27], [-.36, -.4], [0, -.43], [.34, -.37], [.56, -.26]]));
  L.add('r', tick(cx - w / 2, cy + .03 * w, Math.max(8, .09 * w), true) + tick(cx + w / 2, cy + .03 * w, Math.max(8, .09 * w), true));
}

/* ---------- Eight-heads figure: ruler at x0, mannequin centred on fx; top y0, head unit u. */
function figure8(L, x0, fx, y0, u, o = {}) {
  L.add('g', line(x0, y0, x0, y0 + 8 * u, { over: 6 }));
  for (let i = 0; i <= 8; i++) {
    L.add('g', tick(x0, y0 + i * u, 12));
    if (o.units !== false) L.add('b2', line(x0 + 10, y0 + i * u, fx + 1.5 * u, y0 + i * u, { over: 8 }));
    if (i < 8) { L.add('g2', tick(x0, y0 + (i + .5) * u, 6)); L.num('r', i + 1, x0 + (o.numdx ?? 6), y0 + i * u + u * .5 - 5 * (o.ns || 1), o.ns || 1); }
  }
  const X = v => fx + v * u, Y = v => y0 + v * u, P = pts => smooth(pts.map(p => [X(p[0]), Y(p[1])]));
  L.add('b', ell(X(0.02), Y(.5), .36 * u, .5 * u));                                   // head
  L.add('b', line(X(0.02), Y(-.12), X(0.02), Y(1.1), { over: 2 }) + line(X(-.36), Y(.5), X(.4), Y(.5), { over: 3 }));
  L.add('r', P([[.02, 1.0], [.1, 1.6], [.16, 2.4], [.02, 3.3], [-.12, 4.1], [-.3, 5.4], [-.2, 6.6], [-.34, 7.9]]));   // line of action
  L.add('b', ell(X(.1), Y(2.05), .66 * u, .82 * u, { rot: 6 }));                      // ribcage ovoid
  L.add('b', ell(X(-.04), Y(3.68), .62 * u, .42 * u, { rot: -7 }));                   // pelvis
  L.add('g', line(X(-.72), Y(1.52), X(.92), Y(1.4), { over: 5 }) + line(X(-.66), Y(3.6), X(.58), Y(3.76), { over: 5 }));   // shoulder and hip tilt
  L.add('g2', line(X(.1), Y(1.25), X(.1), Y(2.85), { over: 3 }));
  // limbs: single lines with joint circles
  const limb = pts => { let d = ''; for (let i = 0; i < pts.length - 1; i++) d += line(X(pts[i][0]), Y(pts[i][1]), X(pts[i + 1][0]), Y(pts[i + 1][1]), { over: 0, wob: .5 }); return d; };
  L.add('g', limb([[-.36, 3.9], [-.5, 6.0], [-.42, 7.75]]) + limb([[.34, 3.98], [.42, 6.05], [.2, 7.8]]));
  L.add('g', limb([[-.72, 1.52], [-.98, 3.0], [-.86, 4.1]]) + limb([[.92, 1.4], [1.16, 2.9], [1.36, 3.95]]));
  for (const p of [[-.72, 1.52], [.92, 1.4], [-.98, 3.0], [1.16, 2.9], [-.36, 3.9], [.34, 3.98], [-.5, 6.0], [.42, 6.05]]) L.add('b', ell(X(p[0]), Y(p[1]), .09 * u, .09 * u));
  L.add('g', P([[-.42, 7.75], [-.62, 7.96], [-.9, 8.0]]) + P([[.2, 7.8], [.42, 7.97], [.72, 8.0]]));
  L.add('g', line(X(-1.6), Y(8), X(1.9), Y(8)));                                      // ground line
}

/* ---------- Box in one-point perspective: front face rectangle, depth d (0..1) toward vp. */
function box1(L, x, y, w, h, vp, d = .35, o = {}) {
  const c = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
  L.add('g', line(c[0][0], c[0][1], c[1][0], c[1][1], { over: 5 }) + line(c[1][0], c[1][1], c[2][0], c[2][1], { over: 5 }) + line(c[2][0], c[2][1], c[3][0], c[3][1], { over: 5 }) + line(c[3][0], c[3][1], c[0][0], c[0][1], { over: 5 }));
  const b = c.map(p => [p[0] + (vp[0] - p[0]) * d, p[1] + (vp[1] - p[1]) * d]);
  c.forEach(p => L.add('b', line(p[0], p[1], vp[0], vp[1], { over: 0, wob: .4 })));
  L.add('g2', line(b[0][0], b[0][1], b[1][0], b[1][1], { over: 3 }) + line(b[1][0], b[1][1], b[2][0], b[2][1], { over: 3 }) + line(b[2][0], b[2][1], b[3][0], b[3][1], { over: 3 }) + line(b[3][0], b[3][1], b[0][0], b[0][1], { over: 3 }));
  if (o.diag) L.add('b2', line(c[0][0], c[0][1], c[2][0], c[2][1], { over: 0 }) + line(c[1][0], c[1][1], c[3][0], c[3][1], { over: 0 }));
}
/* ---------- Cylinder from stacked ellipses with axes. */
function cylinder(L, cx, y1, y2, rx, k1 = .22, k2 = .34) {
  L.add('b', line(cx, y1 - rx * k1 - 16, cx, y2 + rx * k2 + 16));
  L.add('g', ell(cx, y1, rx, rx * k1) + ell(cx, y2, rx, rx * k2));
  L.add('b2', ell(cx, (y1 + y2) / 2, rx, rx * (k1 + k2) / 2));
  L.add('b', line(cx - rx - 10, y1, cx + rx + 10, y1, { over: 2 }) + line(cx - rx - 10, y2, cx + rx + 10, y2, { over: 2 }));
  L.add('g', line(cx - rx, y1, cx - rx, y2, { over: 3 }) + line(cx + rx, y1, cx + rx, y2, { over: 3 }));
  L.add('r', cross(cx, y1, 3.5) + cross(cx, y2, 3.5));
}
