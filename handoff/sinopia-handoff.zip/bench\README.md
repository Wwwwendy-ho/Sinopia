# Sinopia auto-align benchmark

Measures the app's auto-align on research datasets (kept in `..\datasets`, never copied). Same seeds and case lists for every app, so results compare 1:1.

## Files
- `serve-multi.ps1` localhost-only server: `/app-baseline/` (frozen current app), `/app-fixed/` (modified app), `/data/` (datasets), `/bench/` (this folder). `POST /bench/results/<name>.json|.html` writes into `results\` (name regex `[A-Za-z0-9._-]{1,80}`, 64 MB cap).
- `run.html` + `bench.js` harness (loads the app in an iframe on the same origin, clears its IndexedDB, warms the face models). `summarize.js` shared metric code. `report.html` side-by-side report. `results\<label>-<suite>.json` raw per-case results (resumable).

## Start / stop the server
```
Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','<bench>\serve-multi.ps1','-port','8930' -WindowStyle Hidden -PassThru
Stop-Process -Id <pid>
```
## Run a suite
Open the page in a VISIBLE browser tab (background tabs throttle timers), then either use URL params
`http://localhost:8930/bench/run.html?app=baseline&suite=cufs&n=190&fresh=10&autorun=1` (`app=fixed` for the modified app; add `&rot=1` to switch on the fixed app's "Allow rotation in auto-align" setting, results label `fixed-rot`; `&reset=1` discards earlier results; `&label=` overrides the result label) or from the console:
```
Bench.start({app:'baseline', suite:'cufs', n:190, fresh:10})   // progress: Bench.state
Bench.stop()
```
Re-running with the same app/suite resumes (cases already in the results file are skipped). `n` is the prefix length of the fixed, seeded case list, so a larger `n` extends an earlier run.

| suite | what | mode | notes |
|---|---|---|---|
| `cufs` | CUFS sketch with random known transform (scale 0.6-1.6, translation, tilt 2-8 deg on every 3rd pair) vs original photo; NME vs 35 photo landmarks, rotation/scale error vs similarity fit, unwanted-tilt rate | end-to-end (`app.loadInto` x2, waits for the glide, reads layer transforms) | 188 pairs: 188 rotation-0 + 63 tilt cases = 251 |
| `fs2k` | sketch vs photo, transformed vs untransformed recovered transform consistency, per style | direct `Aligner.estimate` with the app's own options (`app.alignOptions()` when present) | 98+120+120 pairs available; `mode=e2e` also works (2 end-to-end loads per pair) |
| `cufsf` | face detector on artist sketches vs 3 points | direct `DrawingCompare.Subjects.analyze` | 1194 sketches |
| `cufs-det` | same detector check on CUFS photos and sketches (8-point named subset) | direct | extra |
| `retake` | sketch vs re-photographed copy (rot +-3, scale 0.9-1.1, shift, blur, brightness/contrast, paper tint), `preferStructure` as in the app's retake | direct | 100 cufsf + 60 cufs + 60 fs2k sketches |
| `poparts` | dataset stats only (no body alignment yet) | none | phase-3 placeholder |

Outcomes: `confident` (auto-applied), `approximate` (baseline: applied with a warning), `offered` (fixed app: a result shown in the Apply/Preview/Dismiss panel, not moved; its transform is read from the match result, which is what Apply would use), `declined`, `error`. Offered-but-correct is reported apart from applied-correct.

## Conventions
All transforms use centred pixel coordinates (origin = image centre), `p' = s R(th) p + t`, mapping the moving image (drawing) to the fixed one (reference) like the app's matcher. CUFS NME = mean over the 35 landmarks of |C(sketch pt) - photo pt| / inter-ocular distance (photo points 16 and 18), where C = recovered match after the known transform. The CUFS point indices are inferred (see `datasets\README.md`); only IOD and the "core-8" subset depend on the names, NME35 does not.

## Extending (e.g. proportion discrepancies)
Add `B.suites.<name> = {list(), runCase(item, ctx), setup?, finish?}` in `bench.js` and `Summ.suites.<name>` in `summarize.js`; report.html lists suites in the `SUITES` array. `Bench.e2eMatch(movBlob, fixBlob)` / `Bench.directMatch(...)` give the recovered transform for any pair of images.

## Caveats
Timings come from a CPU TensorFlow backend in the embedded browser (face detection dominates). Thumbnails are small data-URL JPEGs stored in the results (a bounded sample: first 30 not-good and 10 good cases per suite).

## Planted-error suite and detector comparison (added)
Pages: `planted.html` (case generation `PR.gen()`, previews `PR.preview(idx,name)`, oracle `PR.oracle()`, detector runs on the planted drawings `PR.runDet()`), `detectors.html` (`DC.runCufs(188)`, `DC.runCufsf(400)`). Libraries in `lib\`: `planted-core.js` (global `Planted`: `makeCases`, `groundTruth`, `render`, `measure`, `ENGINES`, `score`), `detectors.js` (global `Det`: tiny / full / mp / mp50 wrappers, `toLM`), `analysis.js` (global `DA`). Results: `results\planted-*.json`, `results\detectors-*.json`, `results\SUMMARY-planted.md`.
- Run in ONE visible tab (poll `PR.state` / `DC.state`; a JS tool call must return within ~45 s). The pages never load the app; they stub audio anyway.
- Evaluate any engine: give `Planted.score(caseRecs, ms, tol, bias)` per-case feature measures (`ms[i] = {m:{eye_spacing,eye_tilt,nose_len,mouth_width,mouth_height,chin_len,jaw_width}}` in % of eye-mid-to-chin, drawing minus reference, or null for no detection). Landmark sets go through `Planted.measure(drawLM, refLM, Planted.ENGINES[...])`. Cases and exact GT: `results\planted-cases.json`; seed `planted-v1`, sigma 0.2 EC.
- Extra files: `vendor\face-api-weights\` (face_landmark_68_model, MIT, official repo), `vendor\mediapipe\` (tasks-vision 0.10.21 wasm bundle + face_landmarker.task, Apache-2.0); research-use only, scratch, never copy into the app or a repo. `planted-cache\` holds preview sheets. serve-multi.ps1 now also serves .mjs/.wasm/.task.
