﻿const INK = '#2a2521', SOFT = '#625a51', PAPER = '#ece6da', PAPER2 = '#e3dccd', SIN = '#a5502f', VER = '#c2492a', GREY = '#7f7d79', ONG = '#f3eee5', HL = '#f1dc7a', SLATE = '#2f6f86', SLIP = '#f4efe5';
const SANS = 'Segoe UI, system-ui, sans-serif', SERIF = 'Palatino Linotype, Book Antiqua, Georgia, serif';
const mctx = document.createElement('canvas').getContext('2d');
const tw = (s, size = 13, font = SANS, weight = 400, italic = false) => { mctx.font = `${italic ? 'italic ' : ''}${weight} ${size}px ${font}`; return mctx.measureText(s).width; };
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
function T(x, y, s, o = {}) {
  const { size = 13, font = SANS, weight = 400, anchor = 'start', fill = INK, italic = false, op = 1, ls } = o;
  return `<text x="${f(x)}" y="${f(y)}" font-family="${font}" font-size="${size}" font-weight="${weight}"${italic ? ' font-style="italic"' : ''} text-anchor="${anchor}" fill="${fill}"${op < 1 ? ` fill-opacity="${op}"` : ''}${ls ? ` letter-spacing="${ls}"` : ''}>${esc(s)}</text>`;
}
const ink = (d, w = 1.1, o = .78, c = INK) => `<path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-opacity="${o}" stroke-linecap="round" stroke-linejoin="round"/>`;
const pd = pts => 'M' + pts.map(p => f(p[0]) + ' ' + f(p[1])).join('L') + 'Z';
function softRect(x, y, w, h, dx, dy, n = 5, op = .05, spread = 1.6) {
  let s = ''; for (let i = n; i >= 1; i--) s += `<rect x="${f(x + dx * i / n - spread * i / 2)}" y="${f(y + dy * i / n - spread * i / 2)}" width="${f(w + spread * i)}" height="${f(h + spread * i)}" rx="${2 + i}" fill="#1e1712" fill-opacity="${op}"/>`; return s;
}
function grain(id, size, n, dark, light, od = .16, ol = .35) {
  let a = '', b = '';
  for (let i = 0; i < n; i++) { const x = rnd() * size, y = rnd() * size, t = rnd() * TAU, l = 1 + rnd() * 5; a += `M${f(x)} ${f(y)}l${f(l * Math.cos(t))} ${f(l * Math.sin(t))}`; }
  for (let i = 0; i < n * .6; i++) { const x = rnd() * size, y = rnd() * size, t = rnd() * TAU, l = 1 + rnd() * 4; b += `M${f(x)} ${f(y)}l${f(l * Math.cos(t))} ${f(l * Math.sin(t))}`; }
  return `<pattern id="${id}" width="${size}" height="${size}" patternUnits="userSpaceOnUse"><path d="${a}" stroke="${dark}" stroke-opacity="${od}" stroke-width=".6" fill="none" stroke-linecap="round"/><path d="${b}" stroke="${light}" stroke-opacity="${ol}" stroke-width=".7" fill="none" stroke-linecap="round"/></pattern>`;
}
function defs() {
  seed(99);
  return `<defs>${grain('grainP', 190, 150, '#6b5a45', '#fffaf0', .15, .36)}${grain('grainB', 150, 170, '#5e4628', '#e6cfa6', .25, .3)}
<pattern id="washi1" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(38)"><rect width="2.6" height="7" fill="${SIN}" fill-opacity=".5"/></pattern>
<pattern id="washi2" width="8" height="8" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.3" fill="${VER}" fill-opacity=".55"/><circle cx="6" cy="6" r="1.3" fill="${VER}" fill-opacity=".55"/></pattern>
<pattern id="washi3" width="9" height="9" patternUnits="userSpaceOnUse"><path d="M0 4.5H9M4.5 0V9" stroke="#4a6f6a" stroke-opacity=".4" stroke-width="1"/></pattern>
<pattern id="hatchD" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="5" height="5" fill="#2f2a26"/><path d="M0 0V5" stroke="#fff" stroke-opacity=".05" stroke-width="2"/></pattern>
<linearGradient id="gutT" x1="0" x2="0" y1="1" y2="0"><stop offset="0" stop-color="#4a3826" stop-opacity="0"/><stop offset="1" stop-color="#4a3826" stop-opacity=".16"/></linearGradient>
<linearGradient id="gutL" x1="0" x2="1"><stop offset="0" stop-color="#4a3826" stop-opacity="0"/><stop offset=".7" stop-color="#4a3826" stop-opacity=".08"/><stop offset="1" stop-color="#4a3826" stop-opacity=".3"/></linearGradient>
<linearGradient id="gutR" x1="1" x2="0"><stop offset="0" stop-color="#4a3826" stop-opacity="0"/><stop offset=".7" stop-color="#4a3826" stop-opacity=".06"/><stop offset="1" stop-color="#4a3826" stop-opacity=".24"/></linearGradient>
<filter id="halo" x="-30%" y="-30%" width="160%" height="160%"><feMorphology in="SourceAlpha" operator="dilate" radius="1.6" result="d"/><feFlood flood-color="#fbf7ee" flood-opacity=".92"/><feComposite in2="d" operator="in" result="h"/><feMerge><feMergeNode in="h"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
<filter id="haloS" x="-30%" y="-30%" width="160%" height="160%"><feMorphology in="SourceAlpha" operator="dilate" radius="1" result="d"/><feFlood flood-color="#fbf7ee" flood-opacity=".85"/><feComposite in2="d" operator="in" result="h"/><feMerge><feMergeNode in="h"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
</defs>`;
}
function washiTape(x, y, w, h, r, pat) {
  const e = [[x, y], [x + w, y], [x + w - 1.6, y + h * .3], [x + w + .4, y + h * .55], [x + w - 1.2, y + h * .8], [x + w, y + h], [x, y + h], [x + 1.4, y + h * .7], [x - .5, y + h * .45], [x + 1.2, y + h * .2]];
  return `<g transform="rotate(${r} ${f(x + w / 2)} ${f(y + h / 2)})"><path d="${pd(e)}" fill="#1e1712" fill-opacity=".12" transform="translate(1 1.6)"/><path d="${pd(e)}" fill="#efe3bd" fill-opacity=".93"/>${pat ? `<path d="${pd(e)}" fill="url(#${pat})"/>` : ''}<path d="${pd(e)}" fill="none" stroke="${INK}" stroke-opacity=".16" stroke-width=".7"/></g>`;
}
function coilsH(x0, x1, yh, yt, pitch = 13, sc = 1) {
  let holes = '', sh = '', body = '', hi = '';
  for (let x = x0; x <= x1; x += pitch) {
    holes += `<rect x="${f(x - 1.2 * sc)}" y="${f(yh - 2.2 * sc)}" width="${f(7.4 * sc)}" height="${f(4.6 * sc)}" rx="1.5"/>`;
    for (const k of [0, 3.5 * sc]) { const a = x + k + j(.3), b = a + 1.2 * sc;
      body += `M${f(a)} ${f(yh + .6)}C${f(a - .7)} ${f(yh - 4)} ${f(b - .7)} ${f(yt + 4)} ${f(b)} ${f(yt)}`; sh += `M${f(a + 2.2)} ${f(yh + 2)}L${f(b + 2.4)} ${f(yt + 2.5)}`; hi += `M${f(a - .5)} ${f(yh - 4 * sc)}L${f(b - .8)} ${f(yt + 4 * sc)}`; }
  }
  return `<g fill="#3d3229" fill-opacity=".9">${holes}</g><path d="${sh}" stroke="#1e1510" stroke-opacity=".2" stroke-width="${f(2.3 * sc)}" stroke-linecap="round" fill="none"/><path d="${body}" stroke="#3a3633" stroke-width="${f(2.2 * sc)}" stroke-linecap="round" fill="none"/><path d="${hi}" stroke="#d8d2c6" stroke-opacity=".8" stroke-width="${f(.85 * sc)}" stroke-linecap="round" fill="none"/>`;
}
function coilsV(xl, xr, y0, y1, pitch = 14) {
  let holes = '', sh = '', body = '', hi = '';
  for (let y = y0; y <= y1; y += pitch) {
    const dy = j(.5);
    holes += `<rect x="${f(xl - 2.3)}" y="${f(y - 1.2)}" width="4.6" height="7.6" rx="1.6"/><rect x="${f(xr - 2.3)}" y="${f(y - 1.2)}" width="4.6" height="7.6" rx="1.6"/>`;
    for (const k of [0, 3.6]) { const a = y + k + dy, b = a - 1.1 + j(.3), m = (xl + xr) / 2;
      body += `M${f(xl)} ${f(a + .9)}C${f(xl + 3)} ${f(a - .8)} ${f(xr - 3)} ${f(b - .8)} ${f(xr)} ${f(b + .9)}`; sh += `M${f(xl + 1.6)} ${f(a + 2.6)}L${f(xr + 1.8)} ${f(b + 2.6)}`; hi += `M${f(m - 3.4)} ${f(a - .5)}L${f(m + 2.6)} ${f(b - .6)}`; }
  }
  return `<g fill="#3d3229" fill-opacity=".9">${holes}</g><path d="${sh}" stroke="#1e1510" stroke-opacity=".22" stroke-width="2.4" stroke-linecap="round" fill="none"/><path d="${body}" stroke="#3a3633" stroke-width="2.3" stroke-linecap="round" fill="none"/><path d="${hi}" stroke="#d8d2c6" stroke-opacity=".85" stroke-width=".9" stroke-linecap="round" fill="none"/>`;
}

/* ---------- icons, 16 px box at (x, y) ---------- */
const IC = {
  side: 'M2 3.5h5v9H2zM9 3.5h5v9H9z', stacked: 'M2.5 2h11v5.5h-11zM2.5 8.5h11V14h-11z', overlay: 'M2 2h8v8H2zM6 6h8v8H6z',
  link: 'M7 9l2-2M6 11.5l-1 1a2.5 2.5 0 01-3.5-3.5l2.5-2.5a2.5 2.5 0 013.5 0M10 4.5l1-1a2.5 2.5 0 013.5 3.5L12 9.5a2.5 2.5 0 01-3.5 0',
  grid: 'M2.5 2.5h11v11h-11zM6.2 2.5v11M9.8 2.5v11M2.5 6.2h11M2.5 9.8h11', fit: 'M2 5V2h3M11 2h3v3M14 11v3h-3M5 14H2v-3M7 8h2M8 7v2',
  prop: 'M7 1.8C4.2 1.8 2.6 4 2.6 6.8c0 3.6 2.2 7.2 4.4 7.2s4.4-3.6 4.4-7.2C11.4 4 9.8 1.8 7 1.8zM4.6 7h4.8M5.8 10.4h2.4M13.6 2v12M12.4 2h2.4M12.4 14h2.4',
  more: '', tools: 'M2 4h12M2 8h12M2 12h12M5 2.5v3M10 6.5v3M6.5 10.5v3', eye: 'M1.5 8s2.4-4.5 6.5-4.5S14.5 8 14.5 8 12.1 12.5 8 12.5 1.5 8 1.5 8zM8 6.2a1.8 1.8 0 100 3.6 1.8 1.8 0 000-3.6z',
  close: 'M4 4l8 8M12 4l-8 8', help: 'M6 6a2 2 0 114 .2c0 1.4-2 1.6-2 3M8 11.6v.4', chev: 'M4.5 6.5L8 10l3.5-3.5', check: 'M3 8.5l3 3 7-7', undo: 'M5 4L2 7l3 3M2 7h7.5a4 4 0 010 8H7', redo: 'M11 4l3 3-3 3M14 7H6.5a4 4 0 000 8H9',
  pin: 'M8 2.5a2.6 2.6 0 110 5.2 2.6 2.6 0 010-5.2zM8 7.7V14', ruler: 'M2 13L13 2M4 11l1.4 1.4M6.5 8.5l1 1M9 6l1.4 1.4M11.5 3.5l1 1', pencil: 'M3 13l1-3.5L11 2.5l2.5 2.5L6.5 12zM9.5 4l2.5 2.5', reset: 'M3 8a5 5 0 109-3M12 2v3H9'
};
function icon(name, x, y, c = INK, w = 1.3, sc = 1) {
  if (name === 'more') return `<g fill="${c}"><circle cx="${x + 3 * sc}" cy="${y + 8 * sc}" r="${1.3 * sc}"/><circle cx="${x + 8 * sc}" cy="${y + 8 * sc}" r="${1.3 * sc}"/><circle cx="${x + 13 * sc}" cy="${y + 8 * sc}" r="${1.3 * sc}"/></g>`;
  return `<path transform="translate(${f(x)} ${f(y)}) scale(${sc})" d="${IC[name]}" fill="none" stroke="${c}" stroke-width="${f(w / sc)}" stroke-linecap="round" stroke-linejoin="round"/>`;
}

/* ---------- page backgrounds ---------- */
function spreadTop(W, H) {          // Overlay and phones: one sheet, wire binding along the top
  seed(31);
  let s = `<rect width="${W}" height="${H}" fill="#b39468"/><rect width="${W}" height="${H}" fill="url(#grainB)"/>`;
  const big = W > 600, x0 = big ? 13 : 2.5, y0 = big ? 12 : 4, w = W - 2 * x0, h = H - y0 - (big ? 8 : 18);
  s += softRect(x0 - 4, y0, w + 8, h + 4, 3, 5, 5, .06);
  for (let i = 4; i >= 1; i--) { const e = i * (big ? 1.2 : .55); s += `<rect x="${f(x0 - e)}" y="${y0}" width="${f(w + 2 * e)}" height="${f(h + e * 1.4)}" rx="1.5" fill="${i % 2 ? '#e7e0d2' : '#d6ccba'}" stroke="#6f6456" stroke-opacity=".6" stroke-width=".6"/>`; }
  s += `<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="${PAPER}"/><rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="url(#grainP)"/><rect x="${x0}" y="${y0}" width="${w}" height="24" fill="url(#gutT)"/>`;
  s += `<path d="M${x0 - 4} ${y0 + 14.5}H${x0 + w + 4}" stroke="#4d4339" stroke-opacity=".55" stroke-width="1.1" stroke-dasharray="1.3 2.5" fill="none"/>`;
  s += big ? coilsH(x0 + 12, x0 + w - 12, y0 + 7, 0, 13, 1) : coilsH(9, 364, 10.5, 1, 11.2, .85);
  if (big) { const d = smooth([[25, 0], [25.6, 300], [25.2, 600], [25.5, H]]); s += `<path d="${d}" fill="none" stroke="#35302d" stroke-width="6"/><path d="${d}" fill="none" stroke="#7b736c" stroke-opacity=".5" stroke-width="4.4" stroke-dasharray=".8 2.2"/>`; }
  return s;
}
function spreadSide(W, H, gx) {     // Side: open spiral book, binding in the gap at gx
  seed(32);
  let s = `<rect width="${W}" height="${H}" fill="#b39468"/><rect width="${W}" height="${H}" fill="url(#grainB)"/>`;
  s += softRect(8, -30, W - 16, H + 24, 3, 5, 5, .06);
  for (let i = 4; i >= 1; i--) { const e = i * 1.25; s += `<rect x="${f(13 - e)}" y="-30" width="${f(W - 26 + 2 * e)}" height="${f(H - 11 + e * 1.3)}" rx="1.5" fill="${i % 2 ? '#e7e0d2' : '#d6ccba'}" stroke="#6f6456" stroke-opacity=".6" stroke-width=".6"/>`; }
  s += `<rect x="13" y="-30" width="${W - 26}" height="${H + 19}" fill="${PAPER}"/><rect x="13" y="-30" width="${W - 26}" height="${H + 19}" fill="url(#grainP)"/>`;
  s += `<rect x="${gx - 46}" y="-30" width="46" height="${H + 19}" fill="url(#gutL)"/><rect x="${gx}" y="-30" width="46" height="${H + 19}" fill="url(#gutR)"/><rect x="${gx - 3}" y="-30" width="6" height="${H + 30}" fill="#5a4936"/>`;
  s += `<path d="M${gx - 9} -5V${H + 5}M${gx + 9} -5V${H + 5}" stroke="#4d4339" stroke-opacity=".6" stroke-width="1.1" stroke-dasharray="1.3 2.5" fill="none"/>`;
  s += coilsV(gx - 5.8, gx + 5.8, 4, H - 4, 14);
  const d = smooth([[27.5, -20], [28, 300], [27.4, 600], [27.8, H + 20]]); s += `<path d="${d}" fill="none" stroke="#35302d" stroke-width="6.4"/><path d="${d}" fill="none" stroke="#7b736c" stroke-opacity=".5" stroke-width="4.6" stroke-dasharray=".8 2.2"/>`;
  return s;
}

/* ---------- chrome pieces ---------- */
const slipShadow = (x, y, w, h) => `<rect x="${x + 2}" y="${y + 3}" width="${w}" height="${h}" rx="3" fill="${INK}" fill-opacity=".14"/>`;
function masthead(x, y, phone) {
  const w = phone ? 104 : 122, h = phone ? 25 : 27;
  return slipShadow(x, y, w, h) + `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4" fill="${PAPER2}" fill-opacity=".95"/>` +
    `<g transform="translate(${x + 8} ${y + 4})">${ink('M9 1.5C4.5 1.5 2 4.6 2 8.4c0 3.3 1.8 6 4.4 7.3M9 1.5c3.6 0 6.2 2.6 6.2 6 0 2.4-1.3 4.2-2.8 5.2', 1.3, .85)}${ink('M4.5 8.5c2.4-.6 5-.3 8 .6M9 1.5c-1.6 2.8-1.8 7.2 0 10', .9, .7, SIN)}</g>` +
    T(x + 30, y + (phone ? 18 : 20), 'Sinopia', { size: phone ? 17 : 19, font: SERIF, weight: 700 }) + `<path d="M${x + 30} ${y + h - 2}C${x + 52} ${y + h - 3.5} ${x + 74} ${y + h - 1.5} ${x + 96} ${y + h - 2.6}" stroke="${SIN}" stroke-width="2" fill="none"/>`;
}
// desktop top toolbar; active = 'side' | 'overlay'
function toolbar(active, propOn) {
  const items = [['link', 'Link', true], ['grid', 'Grid'], ['fit', 'Fit all'], ['prop', 'Proportions', propOn], ['more', 'More']];
  const segs = [['side', 'Side'], ['stacked', 'Stacked'], ['overlay', 'Overlay']];
  const segW = segs.map(([, l]) => tw(l, 13) + 34), btnW = items.map(([, l]) => tw(l, 13) + 36);
  const total = segW.reduce((a, b) => a + b) + 8 + 18 + btnW.reduce((a, b) => a + b) + 6 * (items.length - 1) + 22;
  const x0 = 1270 - total, y = 6;
  let s = slipShadow(x0, y, total, 36) + `<rect x="${x0}" y="${y}" width="${f(total)}" height="36" rx="4" fill="${PAPER2}" fill-opacity=".95"/>`;
  let x = x0 + 6;
  s += `<rect x="${f(x)}" y="${y + 3.5}" width="${f(segW.reduce((a, b) => a + b) + 4)}" height="29" fill="none" stroke="${INK}" stroke-opacity=".7"/>`;
  x += 2;
  segs.forEach(([k, l], i) => {
    const w = segW[i];
    if (k === active) s += `<path d="M${f(x + 5)} ${y + 12}q${f(w / 2)} -2 ${f(w - 10)} 0v13q${f(-w / 2)} 2 ${f(-(w - 10))} 0z" fill="${HL}"/><path d="M${f(x + 20)} ${y + 28.5}q${f((w - 26) / 2)} -1.5 ${f(w - 28)} .3" stroke="${SIN}" stroke-width="1.6" fill="none"/>`;
    s += icon(k, x + 8, y + 10, INK, 1.2) + T(x + 28, y + 23, l, { size: 13 });
    if (i < 2) s += `<path d="M${f(x + w)} ${y + 11}v14" stroke="${INK}" stroke-opacity=".35"/>`;
    x += w;
  });
  x += 14; s += `<path d="M${f(x - 6)} ${y + 9}v18" stroke="${INK}" stroke-opacity=".35"/>`; x += 6;
  items.forEach(([k, l, on], i) => {
    const w = btnW[i];
    if (on) s += `<rect x="${f(x)}" y="${y + 2}" width="${f(w)}" height="32" rx="5" fill="url(#hatchD)"/>`;
    s += icon(k, x + 10, y + 10, on ? ONG : INK, 1.2) + T(x + 31, y + 23, l, { size: 13, fill: on ? ONG : INK });
    if (k === 'prop' && !on) s += `<circle cx="${f(x + 24)}" cy="${y + 10}" r="3" fill="${VER}"/>`;
    x += w + 6;
    if (k === 'fit') s += `<path d="M${f(x - 3)} ${y + 9}v18" stroke="${INK}" stroke-opacity=".35"/>`;
  });
  return s;
}
function paneFrame(x1, y1, x2, y2, head = 40) {
  const w = x2 - x1, h = y2 - y1;
  let s = softRect(x1, y1, w, h, 5, 8, 6, .045, 2.2) + `<rect x="${x1 + 3}" y="${y1 + 4}" width="${w}" height="${h}" fill="${INK}" fill-opacity=".2"/>`;
  s += `<rect x="${x1}" y="${y1}" width="${w}" height="${h}" fill="${PAPER2}"/><rect x="${x1}" y="${y1}" width="${w}" height="${head + 4}" fill="url(#grainP)" opacity=".6"/>`;
  s += `<rect x="${x1 + 4}" y="${y1 + 4 + head}" width="${w - 8}" height="${h - 8 - head}" fill="${GREY}"/>`;
  s += `<rect x="${x1 + 1.5}" y="${y1 + 1.5}" width="${w - 3}" height="${h - 3}" fill="none" stroke="${INK}" stroke-width="1.5" stroke-opacity=".85"/><path d="M${x1 + 3} ${y1 + 4 + head}h${w - 6}" stroke="${INK}" stroke-opacity=".62" stroke-width="1.2"/>`;
  return s;
}
function toolsBtn(x, y, label = true) {
  return icon('tools', x, y, INK, 1.2, .9) + (label ? T(x + 20, y + 12, 'Tools', { size: 13 }) : '');
}
function layerTab(x, y, label, swatch, selected, h = 28) {
  const w = tw(label, 14, SERIF, 600) + 46;
  let s = `<rect x="${x}" y="${y}" width="${f(w)}" height="${h}" fill="${selected ? '#efe8da' : 'none'}" stroke="${INK}" stroke-opacity="${selected ? .75 : .4}"/>`;
  if (selected) s += `<path d="M${x + 22} ${y + h / 2 - 7}q${f((w - 28) / 2)} -2 ${f(w - 28)} 0v14q${f(-(w - 28) / 2)} 2 ${f(-(w - 28))} 0z" fill="${HL}"/>`;
  s += `<circle cx="${x + 10}" cy="${y + h / 2}" r="3" fill="${selected ? SIN : 'none'}" stroke="${selected ? 'none' : SOFT}"/>` + `<rect x="${x + 16}" y="${y + h / 2 - 4}" width="8" height="8" fill="${swatch}"/>`;
  s += T(x + 30, y + h / 2 + 5, label, { size: 14, font: SERIF, weight: 600, fill: selected ? INK : SOFT });
  if (selected) s += `<path d="M${x + 30} ${y + h - 5}q${f((w - 40) / 2)} -1.5 ${f(w - 40)} .4" stroke="${SIN}" stroke-width="1.4" fill="none"/>`;
  return { s, w };
}
function chip(x, y, label, o = {}) {        // dropdown or toggle chip; returns {s, w}
  const { size = 12.5, h = 26, on = false, drop = false, check = false, bold = false, fill } = o;
  const w = tw(label, size, SANS, bold ? 600 : 400) + 20 + (drop ? 14 : 0) + (check ? 16 : 0);
  let s = `<rect x="${f(x)}" y="${f(y)}" width="${f(w)}" height="${h}" rx="4" fill="${fill || (on ? '#efe8da' : 'none')}" stroke="${INK}" stroke-opacity="${on ? .7 : .35}"/>`;
  let tx = x + 10;
  if (check) { s += on ? icon('check', x + 7, y + h / 2 - 7, INK, 1.6, .85) : `<rect x="${f(x + 8.5)}" y="${f(y + h / 2 - 5.5)}" width="11" height="11" rx="2" fill="none" stroke="${INK}" stroke-opacity=".5"/>`; tx += 16; }
  s += T(tx, y + h / 2 + size * .36, label, { size, weight: bold ? 600 : 400 });
  if (drop) s += icon('chev', x + w - 20, y + h / 2 - 8, INK, 1.4, .9);
  return { s, w };
}
function seg3(x, y, items, activeIdx, w, h = 28, size = 12) {
  let s = `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="none" stroke="${INK}" stroke-opacity=".6"/>`; const cw = w / items.length;
  items.forEach((l, i) => {
    const cx = x + cw * i;
    if (i === activeIdx) s += `<path d="M${f(cx + 4)} ${y + 6}q${f(cw / 2 - 4)} -2 ${f(cw - 8)} 0v${h - 12}q${f(-(cw / 2 - 4))} 2 ${f(-(cw - 8))} 0z" fill="${HL}"/>`;
    s += T(cx + cw / 2, y + h / 2 + 4.3, l, { size, anchor: 'middle', weight: i === activeIdx ? 600 : 400 });
    if (i) s += `<path d="M${f(cx)} ${y + 6}v${h - 12}" stroke="${INK}" stroke-opacity=".3"/>`;
  });
  return s;
}
function ruleH(x1, x2, y, o = .3) { return ink(line(x1, y, x2, y + j(.4), { over: 0, wob: .5 }), .9, o); }

/* ---------- report marks ---------- */
function sevTag(cx, cy, n, major, r = 9.5) {
  return major
    ? `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${VER}"/>` + T(cx, cy + r * .44, n, { size: r * 1.25, weight: 700, anchor: 'middle', fill: '#fff8ef' })
    : `<circle cx="${cx}" cy="${cy}" r="${r - .7}" fill="#fbf7ee" stroke="${SIN}" stroke-width="1.6"/>` + T(cx, cy + r * .44, n, { size: r * 1.25, weight: 700, anchor: 'middle', fill: SIN });
}
const ISSUES = [
  { n: '1', major: true, text: 'Nose 8% too long', sub: 'The mouth sits 6% low with it' },
  { n: '2', major: true, text: 'Jaw 7% too narrow' },
  { n: '3', major: false, text: 'Eyes 4% too close together' },
  { n: '4', major: false, text: 'Left eye 4% too high' }
];

// Report column (desktop). opts: selected index, grid (bool), arrows (bool)
function reportSlip(x, y, w, h, o = {}) {
  seed(81);
  const { sel = 0, grid = false, arrows = true } = o;
  let s = softRect(x, y, w, h, 4, 7, 6, .05, 2) + `<rect x="${x + 2}" y="${y + 3}" width="${w}" height="${h}" fill="${INK}" fill-opacity=".16"/>`;
  s += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${SLIP}"/><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#grainP)" opacity=".7"/>`;
  s += `<rect x="${x + .5}" y="${y + .5}" width="${w - 1}" height="${h - 1}" fill="none" stroke="${INK}" stroke-opacity=".55"/>`;
  s += washiTape(x + w / 2 - 34, y - 9, 68, 18, -2.5, 'washi1');
  const L = x + 16, R = x + w - 16;
  let yy = y + 36;
  s += T(L, yy, 'Proportions', { size: 19, font: SERIF, weight: 700 }) + `<path d="M${L} ${yy + 5}C${L + 40} ${yy + 3.5} ${L + 80} ${yy + 5.5} ${L + 108} ${yy + 4}" stroke="${SIN}" stroke-width="1.8" fill="none"/>`;
  s += icon('help', R - 42, yy - 13, SOFT, 1.4) + icon('close', R - 16, yy - 13, INK, 1.5);
  yy += 22;
  s += T(L, yy, 'Your drawing, measured against the reference.', { size: 12, font: SERIF, italic: true, fill: SOFT });
  // pin and size pickers
  yy += 16;
  const lab = (t, yv) => T(L, yv, t, { size: 11, fill: SOFT, ls: .6 });
  s += lab('PIN', yy + 17) + icon('pin', L + 26, yy + 5, VER, 1.6, .95);
  let c = chip(L + 64, yy, 'Between the eyes', { drop: true }); s += c.s;
  yy += 32;
  s += lab('SIZE BY', yy + 17);
  c = chip(L + 64, yy, 'Eye line to chin', { drop: true }); s += c.s;
  yy += 40;
  s += ruleH(L - 4, R + 4, yy);
  yy += 22;
  s += T(L, yy, '4 differences', { size: 14, font: SERIF, weight: 700 }) + T(R, yy, 'over 3%', { size: 12, anchor: 'end', fill: SOFT });
  yy += 10;
  ISSUES.forEach((it, i) => {
    const hgt = it.sub ? 52 : 36, isSel = i === sel;
    if (isSel) s += `<path d="M${L - 8} ${yy + 3}q${(R - L + 16) / 2} -2 ${R - L + 16} 0v${hgt - 4}q${-(R - L + 16) / 2} 2 ${-(R - L + 16)} 0z" fill="${HL}" fill-opacity=".72"/>` + `<rect x="${L - 8}" y="${yy + 3}" width="3" height="${hgt - 4}" fill="${SIN}"/>`;
    s += sevTag(L + 9, yy + 19, it.n, it.major);
    s += T(L + 28, yy + 24, it.text, { size: 14, weight: it.major ? 600 : 400 });
    if (it.sub) s += T(L + 28, yy + 42, '↳ ' + it.sub, { size: 12, fill: SOFT, italic: true });
    if (!isSel) s += ink(line(L + 26, yy + hgt, R, yy + hgt, { over: 0, wob: .3 }), .6, .14);
    yy += hgt;
  });
  yy += 22;
  s += icon('check', L, yy - 12, '#4d6b47', 1.6, .9) + T(L + 20, yy, 'Close enough: brows, mouth width,', { size: 12.5, fill: SOFT });
  s += T(L + 20, yy + 17, 'cheekbones, chin.', { size: 12.5, fill: SOFT });
  yy += 34;
  s += ruleH(L - 4, R + 4, yy);
  yy += 22;
  s += lab('SHOW', yy);
  yy += 8;
  let cx = L;
  for (const [t, on] of [['Arrows', arrows], ['Points', true], ['Grid', grid]]) { c = chip(cx, yy, t, { check: true, on }); s += c.s; cx += c.w + 7; }
  yy += 44;
  if (grid) {
    s += `<rect x="${L}" y="${yy}" width="14" height="10" fill="${SIN}" fill-opacity=".38" stroke="${SIN}" stroke-opacity=".6"/>` + T(L + 20, yy + 9.5, 'Stretched', { size: 12, fill: SOFT });
    s += `<rect x="${L + 96}" y="${yy}" width="14" height="10" fill="${SLATE}" fill-opacity=".34" stroke="${SLATE}" stroke-opacity=".6"/>` + T(L + 116, yy + 9.5, 'Squashed', { size: 12, fill: SOFT });
    yy += 30;
  }
  s += lab('TOLERANCE', yy);
  yy += 8;
  s += seg3(L, yy, ['Strict 2%', 'Usual 3%', 'Relaxed 6%'], 1, R - L, 28, 12);
  yy += 44;
  s += ruleH(L - 4, R + 4, yy);
  yy += 14;
  c = chip(L, yy, 'Edit points', { h: 30, size: 13 }); s += c.s.replace('<text', '<text') ;
  const c2 = chip(L + c.w + 8, yy, 'Reset points', { h: 30, size: 13 }); s += c2.s;
  yy += 44;
  c = chip(L, yy, 'Match head tilt', { check: true, on: false, h: 26 }); s += c.s;
  yy += 46;
  s += icon('check', L, yy - 12, '#4d6b47', 1.6, .9) + T(L + 20, yy, 'Both heads face the same way,', { size: 12.5, fill: SOFT }) + T(L + 20, yy + 17, 'so every measurement counts.', { size: 12.5, fill: SOFT });
  s += T(L, y + h - 14, 'Left and right as you look at the picture.', { size: 11.5, fill: SOFT, italic: true, font: SERIF });
  return s;
}

/* ---------- on-canvas marks (screen space). V(u) maps measure units to screen ---------- */
function mapper(ox, oy, k) { return p => [ox + p[0] * k, oy + p[1] * k]; }
function refRing(p, r = 3.6, op = 1) { return `<circle cx="${f(p[0])}" cy="${f(p[1])}" r="${r}" fill="none" stroke="${SIN}" stroke-width="1.6" stroke-opacity="${op}" filter="url(#haloS)"/>`; }
function drwDot(p, r = 2.8, op = 1) { return `<circle cx="${f(p[0])}" cy="${f(p[1])}" r="${r}" fill="${INK}" fill-opacity="${op}" filter="url(#haloS)"/>`; }
function arrowMark(a, b, major, op = 1, w) {
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]), ang = Math.atan2(b[1] - a[1], b[0] - a[0]), c = major ? VER : SIN, sw = w || (major ? 2.4 : 1.7), h = major ? 7 : 6;
  const tip = b, back = [b[0] - Math.cos(ang) * 1.5, b[1] - Math.sin(ang) * 1.5];
  const head = `M${f(tip[0] - h * Math.cos(ang - .45))} ${f(tip[1] - h * Math.sin(ang - .45))}L${f(tip[0])} ${f(tip[1])}L${f(tip[0] - h * Math.cos(ang + .45))} ${f(tip[1] - h * Math.sin(ang + .45))}`;
  return `<g opacity="${op}" filter="url(#halo)"><path d="M${f(a[0])} ${f(a[1])}L${f(back[0])} ${f(back[1])}${head}" fill="none" stroke="${c}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"/></g>`;
}
function canvasTag(p, n, major, op = 1, r = 9) { return `<g opacity="${op}" filter="url(#halo)">${sevTag(p[0], p[1], n, major, r)}</g>`; }
function pinMark(p, sc = 1) {
  const [x, y] = p;
  return `<g filter="url(#halo)"><circle cx="${x}" cy="${y}" r="${11 * sc}" fill="none" stroke="${VER}" stroke-width="1.3" stroke-dasharray="2.5 2"/>` +
    `<path d="M${x - 16 * sc} ${y}h${8 * sc}M${x + 8 * sc} ${y}h${8 * sc}M${x} ${y - 16 * sc}v${8 * sc}M${x} ${y + 8 * sc}v${8 * sc}" stroke="${VER}" stroke-width="1.6" stroke-linecap="round"/>` +
    `<circle cx="${x}" cy="${y}" r="${4.4 * sc}" fill="${VER}"/><circle cx="${x - 1.3 * sc}" cy="${y - 1.4 * sc}" r="${1.3 * sc}" fill="#fff" fill-opacity=".7"/></g>`;
}
function measureMark(a, b, xLine, label, sc = 1, extFrom = [null, null]) {
  // a, b: screen points of the two measure ends; drawn as a vertical dimension line at xLine with extension lines
  let s = '';
  const ext = (p, from) => `<path d="M${f(from)} ${f(p[1])}H${f(xLine + 6)}" stroke="${SIN}" stroke-width="1" stroke-dasharray="3 3" stroke-opacity=".9"/>`;
  s += ext(a, extFrom[0] ?? a[0] + 8) + ext(b, extFrom[1] ?? b[0] + 8);
  s += `<path d="M${xLine} ${f(a[1])}V${f(b[1])}" stroke="${SIN}" stroke-width="1.6"/>`;
  s += `<path d="M${xLine - 4} ${f(a[1] + 6)}L${xLine} ${f(a[1])}L${xLine + 4} ${f(a[1] + 6)}M${xLine - 4} ${f(b[1] - 6)}L${xLine} ${f(b[1])}L${xLine + 4} ${f(b[1] - 6)}" stroke="${SIN}" stroke-width="1.6" fill="none" stroke-linecap="round"/>`;
  for (const p of [a, b]) s += `<rect x="${xLine - 4.5}" y="${f(p[1] - 4.5)}" width="9" height="9" fill="#fbf7ee" stroke="${SIN}" stroke-width="1.6"/>`;
  const my = (a[1] + b[1]) / 2, lw = tw(label, 11.5 * sc, SERIF, 400, true) + 12;
  s += `<rect x="${f(xLine - lw / 2)}" y="${f(my - 10 * sc)}" width="${f(lw)}" height="${f(20 * sc)}" rx="3" fill="#fbf7ee" stroke="${SIN}" stroke-opacity=".6"/>` + T(xLine, my + 4 * sc, label, { size: 11.5 * sc, font: SERIF, italic: true, anchor: 'middle', fill: SIN });
  return `<g filter="url(#haloS)">${s}</g>`;
}
function bubble(x, y, name, desc, dir = 'left') {   // info bubble (graphite slip with tape); (x, y) = the point it describes
  const w = Math.max(tw(name, 13, SERIF, 600), tw(desc, 12)) + 22, h = 44;
  const bx = dir === 'left' ? x - w - 14 : x + 14, by = y - h / 2;
  let s = `<rect x="${bx + 1.5}" y="${by + 2}" width="${w}" height="${h}" rx="4" fill="${INK}" fill-opacity=".18"/><rect x="${bx}" y="${by}" width="${w}" height="${h}" rx="4" fill="url(#hatchD)"/>`;
  s += dir === 'left' ? `<path d="M${bx + w - 1} ${y - 5}l6 5-6 5z" fill="#2f2a26"/>` : `<path d="M${bx + 1} ${y - 5}l-6 5 6 5z" fill="#2f2a26"/>`;
  s += washiTape(bx - 6, by - 6, 28, 9, -7, null);
  s += T(bx + 11, by + 18, name, { size: 13, font: SERIF, weight: 600, fill: PAPER }) + T(bx + 11, by + 35, desc, { size: 12, fill: PAPER, op: .86 });
  return s;
}
function undoSlip(cx, y, note) {
  const nw = tw(note, 13.5, SERIF, 600), w = nw + 24 + 104 + 76 + 16, x = cx - w / 2;
  let s = `<rect x="${x + 2}" y="${y + 3}" width="${w}" height="40" rx="3" fill="${INK}" fill-opacity=".2"/><rect x="${x}" y="${y}" width="${w}" height="40" rx="3" fill="url(#hatchD)"/>`;
  s += washiTape(x - 8, y - 7, 36, 11, -6, null);
  s += T(x + 14, y + 25, note, { size: 13.5, font: SERIF, weight: 600, fill: ONG });
  let bx = x + 24 + nw;
  s += `<rect x="${bx}" y="${y + 5}" width="96" height="30" rx="4" fill="none" stroke="${ONG}" stroke-opacity=".5"/>` + icon('undo', bx + 9, y + 12, ONG, 1.4, .95) + T(bx + 30, y + 25, 'Undo align', { size: 13, fill: ONG });
  bx += 104;
  s += `<rect x="${bx}" y="${y + 5}" width="68" height="30" rx="4" fill="none" stroke="${ONG}" stroke-opacity=".5"/>` + icon('redo', bx + 9, y + 12, ONG, 1.4, .95) + T(bx + 30, y + 25, 'Redo', { size: 13, fill: ONG });
  return s;
}

/* ---------- the marks for one face ---------- */
// layer: 'both' (overlay), 'drw' (drawing pane), 'ref' (reference pane)
function faceMarks(V, o = {}) {
  const { layer = 'both', sel = 0, arrows = true, points = true, tags = true, phone = false, bracket = true } = o;
  let s = '';
  const dim = i => (sel === null || sel === i) ? 1 : .5;
  const SEL_PTS = [['bridge', 'noseTip', 'alaL', 'alaR', 'noseBase', 'mouthL', 'mouthC', 'mouthR', 'lipTop', 'lipBot'], ['jawL', 'jawLL', 'chin', 'jawRR', 'jawR'], ['eyeL', 'eyeR', 'eyeLo', 'eyeLi', 'eyeRi', 'eyeRo'], ['eyeL', 'eyeR']];
  const showPts = points === true ? SHOWN : points === 'sel' ? SEL_PTS[sel] : [];
  {
    for (const k of showPts) {
      if (layer !== 'drw') s += refRing(V(REF[k]), phone ? 3 : 3.6, .95);
      if (layer !== 'ref') s += drwDot(V(DRW[k]), phone ? 2.3 : 2.8);
    }
  }
  if (layer === 'ref') return s;
  const tgt = k => V(REF[k]), src = k => V(DRW[k]);
  if (arrows) {
    // 1: nose (with the mouth as its knock-on)
    s += arrowMark(src('noseBase'), tgt('noseBase'), true, dim(0)) + arrowMark(src('noseTip'), tgt('noseTip'), true, dim(0)) + arrowMark(src('mouthC'), tgt('mouthC'), true, dim(0) * .75, phone ? 1.6 : 1.8);
    s += arrowMark(src('mouthL'), tgt('mouthL'), true, dim(0) * .75, phone ? 1.6 : 1.8) + arrowMark(src('mouthR'), tgt('mouthR'), true, dim(0) * .75, phone ? 1.6 : 1.8);
    // 2: jaw
    s += arrowMark(src('jawL'), tgt('jawL'), true, dim(1)) + arrowMark(src('jawR'), tgt('jawR'), true, dim(1)) + arrowMark(src('jawLL'), tgt('jawLL'), true, dim(1) * .8, 1.8) + arrowMark(src('jawRR'), tgt('jawRR'), true, dim(1) * .8, 1.8);
    // 3 + 4: eyes
    s += arrowMark(src('eyeL'), tgt('eyeL'), false, Math.max(dim(2), dim(3))) + arrowMark(src('eyeR'), tgt('eyeR'), false, dim(2));
  }
  // nose bracket for the selected item: reference length (dashed) beside the drawing's (solid), excess in vermilion
  if (bracket && sel === 0) {
    const x = V([phone ? -27 : 25, 0])[0], y0 = V([0, 0])[1] + 8, yr = V([0, 46])[1], yd = V([0, 54])[1];
    s += `<g filter="url(#halo)"><path d="M${x - 4} ${y0}V${f(yr)}" stroke="${SIN}" stroke-width="1.6" stroke-dasharray="4 2.5"/><path d="M${x + 4} ${y0}V${f(yd)}" stroke="${INK}" stroke-width="1.6"/>`;
    s += `<path d="M${x - 8} ${f(yr)}h8M${x - 8} ${f(y0)}h16M${x} ${f(yd)}h8" stroke="${INK}" stroke-width="1.4"/>`;
    s += `<path d="M${x + 4} ${f(yr)}V${f(yd)}" stroke="${VER}" stroke-width="4" stroke-linecap="butt"/></g>`;
    if (!phone) {
      const lx = x + 12, ly = (yr + yd) / 2, lab = '8% too long';
      const lw = tw(lab, 12, SANS, 600) + 12;
      s += `<g filter="url(#haloS)"><rect x="${f(lx)}" y="${f(ly - 10)}" width="${f(lw)}" height="20" rx="3" fill="${VER}"/></g>` + T(lx + lw / 2, ly + 4.3, lab, { size: 12, weight: 600, anchor: 'middle', fill: '#fff8ef' });
    }
  }
  if (tags) {
    const r = phone ? 8 : 9;
    s += canvasTag(V(phone ? [24, 51] : [-24, 47]), '1', true, dim(0), r);
    s += canvasTag(V([-72, 66]), '2', true, dim(1), r);
    s += canvasTag(V([0, -15]), '3', false, dim(2), r);
    s += canvasTag(V(phone ? [-31, -12] : [-31, 11]), '4', false, dim(3), r);
  }
  return s;
}

/* ---------- distortion grid ---------- */
function gridMarks(V, warped) {
  const xs = [], ys = []; for (let x = -64; x <= 64; x += 16) xs.push(x); for (let y = -40; y <= 104; y += 16) ys.push(y);
  const M = p => V(warped ? warp(p[0], p[1]) : p);
  let shade = '', lines = '';
  if (warped) {
    const area = q => { let a = 0; for (let i = 0; i < q.length; i++) { const p = q[i], r = q[(i + 1) % q.length]; a += p[0] * r[1] - r[0] * p[1]; } return Math.abs(a) / 2; };
    const sx = [], sy = []; for (let x = -64; x <= 64; x += 4) sx.push(x); for (let y = -40; y <= 104; y += 4) sy.push(y);
    for (let i = 0; i < sx.length - 1; i++) for (let jx = 0; jx < sy.length - 1; jx++) {
      const x0 = sx[i], x1 = sx[i + 1], y0 = sy[jx], y1 = sy[jx + 1], q = [];
      // local stretch, measured over a 16-unit neighbourhood so the map reads as smooth areas, not speckle
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, h = 8;
      const nb = [warp(cx - h, cy - h), warp(cx + h, cy - h), warp(cx + h, cy + h), warp(cx - h, cy + h)];
      const r = area(nb) / (4 * h * h) - 1;
      const a = Math.min(.3, Math.max(0, (Math.abs(r) - .04) * 2.4));
      if (a > .01) shade += `<path d="${pd([[x0, y0], [x1, y0], [x1, y1], [x0, y1]].map(p => V(warp(p[0], p[1]))))}" fill="${r > 0 ? SIN : SLATE}" fill-opacity="${f(a * 100) / 100}" stroke="${r > 0 ? SIN : SLATE}" stroke-opacity="${f(a * 60) / 100}" stroke-width=".35"/>`;
    }
    for (let i = 0; i < 0; i++) for (let jx = 0; jx < 0; jx++) {
      const x0 = xs[i], x1 = xs[i + 1], y0 = ys[jx], y1 = ys[jx + 1], q = [];
      for (let t = 0; t < 4; t++) q.push(warp(x0 + (x1 - x0) * t / 4, y0));
      for (let t = 0; t < 4; t++) q.push(warp(x1, y0 + (y1 - y0) * t / 4));
      for (let t = 0; t < 4; t++) q.push(warp(x1 - (x1 - x0) * t / 4, y1));
      for (let t = 0; t < 4; t++) q.push(warp(x0, y1 - (y1 - y0) * t / 4));
      const r = area(q) / (16 * 16) - 1;
      if (Math.abs(r) > .05) { const a = Math.min(.3, (Math.abs(r) - .05) * 2 + .07); shade += `<path d="${pd(q.map(V))}" fill="${r > 0 ? SIN : SLATE}" fill-opacity="${f(a * 100) / 100}"/>`; }
    }
  }
  const poly = pts => 'M' + pts.map(p => f(p[0]) + ' ' + f(p[1])).join('L');
  for (const x of xs) { const pts = []; for (let y = ys[0]; y <= ys[ys.length - 1] + .01; y += 4) pts.push(M([x, y])); lines += poly(pts); }
  for (const y of ys) { const pts = []; for (let x = xs[0]; x <= xs[xs.length - 1] + .01; x += 4) pts.push(M([x, y])); lines += poly(pts); }
  return shade + `<path d="${lines}" fill="none" stroke="#fbf7ee" stroke-opacity=".55" stroke-width="2.4"/><path d="${lines}" fill="none" stroke="${warped ? INK : SIN}" stroke-opacity="${warped ? .7 : .5}" stroke-width="${warped ? 1 : .9}"${warped ? '' : ' stroke-dasharray="3 3"'}/>`;
}
