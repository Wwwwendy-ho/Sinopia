// Phase 3 mock-ups: geometry helpers, stand-in figure / hand / half figure drawn as SVG (no dataset images).
const P2 = p => f(p[0]) + ' ' + f(p[1]);
const vadd = (a, b) => [a[0] + b[0], a[1] + b[1]], vsub = (a, b) => [a[0] - b[0], a[1] - b[1]], vmul = (a, k) => [a[0] * k, a[1] * k];
const vlen = a => Math.hypot(a[0], a[1]), vunit = a => vmul(a, 1 / (vlen(a) || 1)), vperp = a => [-a[1], a[0]];
const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
const mapU = (ox, oy, u) => p => [ox + p[0] * u, oy + p[1] * u];

// filled tapered capsule from a to b (screen space)
function capsule(a, b, ra, rb) {
  const d = vunit(vsub(b, a)), n = vperp(d);
  const p1 = vadd(a, vmul(n, ra)), p2 = vadd(b, vmul(n, rb)), p3 = vsub(b, vmul(n, rb)), p4 = vsub(a, vmul(n, ra));
  return `M${P2(p1)}L${P2(p2)}A${f(rb)} ${f(rb)} 0 0 0 ${P2(p3)}L${P2(p4)}A${f(ra)} ${f(ra)} 0 0 0 ${P2(p1)}Z`;
}
// pencil version: two wobbly sides and a rounded end
function capsuleLines(a, b, ra, rb, end = true) {
  const d = vunit(vsub(b, a)), n = vperp(d);
  const p1 = vadd(a, vmul(n, ra)), p2 = vadd(b, vmul(n, rb)), p3 = vsub(b, vmul(n, rb)), p4 = vsub(a, vmul(n, ra));
  let s = line(p1[0], p1[1], p2[0], p2[1], { over: 2, wob: .8 }) + line(p4[0], p4[1], p3[0], p3[1], { over: 2, wob: .8 });
  if (end) { const tip = vadd(b, vmul(d, rb)); s += smooth([p2, vadd(lerp(p2, tip, .5), vmul(n, rb * .35)), tip, vsub(lerp(p3, tip, .5), vmul(n, rb * .35)), p3]); }
  return s;
}
const closedSmooth = pts => smooth([...pts, pts[0], pts[1]]);
function densify(pts, step = 3) {           // Catmull-Rom resample of an open polyline (screen space)
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    const n = Math.max(2, Math.ceil(vlen(vsub(p2, p1)) / step));
    for (let k = 0; k < n; k++) {
      const t = k / n, t2 = t * t, t3 = t2 * t;
      out.push([0, 1].map(c => .5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3)));
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}
const polyD = pts => 'M' + pts.map(P2).join('L');

// ---------------- full figure (units: heads; origin top of head, x = 0 on the pit of the neck) ----------------
const RJ = { top: [0, 0], nose: [.04, .6], chin: [.03, 1.0], earR: [-.33, .52], earL: [.35, .5], pit: [0, 1.3],
  shR: [-.95, 1.52], shL: [.95, 1.32], elR: [-1.12, 2.9], elL: [1.45, 2.5], wrR: [-1.2, 4.05], wrL: [.85, 3.45], haR: [-1.22, 4.52], haL: [.6, 3.62],
  hR: [-.48, 3.85], hL: [.5, 4.0], kR: [-.3, 5.75], kL: [.6, 5.7], aR: [-.08, 7.25], aL: [.95, 7.1], heR: [-.18, 7.38], toR: [.28, 7.45], heL: [.86, 7.22], toL: [1.28, 7.36] };
const DJ = JSON.parse(JSON.stringify(RJ));
Object.assign(DJ, { nose: [.02, .6], shR: [-.95, 1.41], shL: [.95, 1.41], elR: [-1.1, 2.85], elL: [1.45, 2.55], wrR: [-1.18, 3.98], wrL: [.796, 3.586],
  haR: [-1.198, 4.394], haL: [.56, 3.74], hR: [-.5, 3.83], hL: [.5, 3.98], kR: [-.36, 5.55], kL: [.62, 5.5], aR: [-.38, 6.85], aL: [.95, 6.72],
  heR: [-.48, 6.98], toR: [-.02, 7.05], heL: [.86, 6.84], toL: [1.28, 6.97] });
const BONES = [['shR', 'shL'], ['shR', 'elR'], ['elR', 'wrR'], ['wrR', 'haR'], ['shL', 'elL'], ['elL', 'wrL'], ['wrL', 'haL'], ['shR', 'hR'], ['shL', 'hL'], ['hR', 'hL'],
  ['hR', 'kR'], ['kR', 'aR'], ['aR', 'heR'], ['heR', 'toR'], ['aR', 'toR'], ['hL', 'kL'], ['kL', 'aL'], ['aL', 'heL'], ['heL', 'toL'], ['aL', 'toL'], ['earR', 'nose'], ['earL', 'nose']];
const FIG_PTS = ['nose', 'earR', 'earL', 'shR', 'shL', 'elR', 'elL', 'wrR', 'wrL', 'haR', 'haL', 'hR', 'hL', 'kR', 'kL', 'aR', 'aL', 'heR', 'toR', 'heL', 'toL'];

function torsoPts(J) {
  return [[-.22, 1.18], vadd(J.shR, [-.03, -.04]), vadd(J.shR, [-.08, .2]), [J.shR[0] + .17, 2.1], [-.55, 3.0], vadd(J.hR, [-.22, .05]), vadd(J.hR, [-.12, .5]),
    [.02, 4.42], vadd(J.hL, [.12, .48]), vadd(J.hL, [.22, .05]), [.62, 3.1], [J.shL[0] - .15, 1.98], vadd(J.shL, [.08, .2]), vadd(J.shL, [.03, -.04]), [.22, 1.18]];
}
function refFigure(V, u) {       // the "reference photo" stand-in: a lit plaster mannequin on a studio wall
  const S = p => V(p);
  let s = `<rect x="0" y="0" width="1400" height="900" fill="url(#wall)"/><path d="M0 ${f(V([0, 7.42])[1])}H1400V900H0Z" fill="#b7aa98"/>`;
  s += `<ellipse cx="${f(V([.4, 7.42])[0])}" cy="${f(V([.4, 7.42])[1])}" rx="${f(1.3 * u)}" ry="${f(.12 * u)}" fill="#6d5f50" fill-opacity=".35"/>`;
  const J = RJ, sk = 'url(#skin)';
  const limbs = [[J.hL, J.kL, .27, .19], [J.kL, J.aL, .19, .1], [J.shL, J.elL, .17, .13], [J.elL, J.wrL, .13, .09],
    [J.hR, J.kR, .28, .2], [J.kR, J.aR, .2, .1], [J.shR, J.elR, .17, .13], [J.elR, J.wrR, .13, .09]];
  for (const [a, b, ra, rb] of limbs) s += `<path d="${capsule(S(a), S(b), ra * u, rb * u)}" fill="${sk}"/>`;
  s += `<path d="${closedSmooth(torsoPts(J).map(S))}" fill="${sk}"/>`;
  s += `<path d="${capsule(S([0, 1.0]), S([0, 1.36]), .17 * u, .2 * u)}" fill="${sk}"/>`;
  for (const [a, b, r] of [[J.wrR, J.haR, .1], [J.wrL, J.haL, .09]]) s += `<path d="${capsule(S(a), S(b), r * u, r * .8 * u)}" fill="${sk}"/>`;
  for (const [h, t] of [[J.heR, J.toR], [J.heL, J.toL]]) s += `<path d="${capsule(S(h), S(t), .08 * u, .06 * u)}" fill="${sk}"/>`;
  s += `<ellipse cx="${f(V([.02, .5])[0])}" cy="${f(V([.02, .5])[1])}" rx="${f(.36 * u)}" ry="${f(.5 * u)}" fill="${sk}"/>`;
  s += `<path d="M${P2(V([-.37, .45]))}C${P2(V([-.4, -.08]))} ${P2(V([.42, -.1]))} ${P2(V([.39, .42]))}C${P2(V([.3, .2]))} ${P2(V([-.2, .12]))} ${P2(V([-.37, .45]))}Z" fill="#5b4535" fill-opacity=".8"/>`;
  // form shadows: one soft side shadow down the figure's left (light from the image left)
  s += `<path d="${smooth([J.shL, [.86, 2.0], [.64, 3.0], [.7, 3.9], [.62, 4.4]].map(S))}" stroke="#7a5a45" stroke-opacity=".25" stroke-width="${f(.12 * u)}" fill="none" stroke-linecap="round"/>`;
  s += `<path d="${smooth([[-.4, 2.05], [-.05, 2.25], [.4, 2.05]].map(S))}" stroke="#7a5a45" stroke-opacity=".22" stroke-width="3" fill="none"/>`;
  s += `<path d="${smooth([[-.3, 4.05], [0, 4.25], [.32, 4.1]].map(S))}" stroke="#7a5a45" stroke-opacity=".2" stroke-width="3" fill="none"/>`;
  return s;
}
function pencilFigure(V, u) {     // the gesture drawing (pencil), with its errors built in
  seed(140);
  const J = DJ, S = p => V(p);
  let g = '', g2 = '', b = '';
  b += smooth([[.05, .05], [.04, 1.0], [-.08, 2.2], [.08, 3.4], [-.12, 4.6], [-.32, 6.2], [-.3, 7.0]].map(S));                // line of action
  g += ell(S([.02, .5])[0], S([.02, .5])[1], .35 * u, .49 * u, { rot: 3 });
  g2 += line(...S([.02, -.02]), ...S([.03, 1.02]), { over: 4 }) + line(...S([-.34, .45]), ...S([.38, .45]), { over: 4 });
  g += line(...S([-.17, 1.0]), ...S([-.2, 1.25]), { over: 2 }) + line(...S([.19, .98]), ...S([.22, 1.24]), { over: 2 });
  b += ell(S([0, 2.05])[0], S([0, 2.05])[1], .68 * u, .8 * u, { rot: 2 }) + ell(S([0, 3.75])[0], S([0, 3.75])[1], .62 * u, .42 * u, { rot: -6 });
  g += line(...S(J.shR), ...S(J.shL), { over: 8 }) + line(...S(J.hR), ...S(J.hL), { over: 8 });
  g += smooth(torsoPts(J).slice(0, 7).map(S)) + smooth(torsoPts(J).slice(8).map(S));
  const segs = [[J.shR, J.elR, .16, .12], [J.elR, J.wrR, .12, .085], [J.shL, J.elL, .16, .12], [J.elL, J.wrL, .12, .085],
    [J.hR, J.kR, .27, .19], [J.kR, J.aR, .19, .095], [J.hL, J.kL, .26, .18], [J.kL, J.aL, .18, .095]];
  for (const [a, c, ra, rb] of segs) g += capsuleLines(S(a), S(c), ra * u, rb * u, false);
  for (const k of ['elR', 'elL', 'kR', 'kL', 'shR', 'shL']) b += ell(S(J[k])[0], S(J[k])[1], .1 * u, .1 * u);
  g += capsuleLines(S(J.wrR), S(J.haR), .085 * u, .07 * u) + capsuleLines(S(J.wrL), S(J.haL), .08 * u, .065 * u);
  g += capsuleLines(S(J.heR), S(J.toR), .07 * u, .055 * u) + capsuleLines(S(J.heL), S(J.toL), .07 * u, .055 * u);
  g2 += line(...S([-1.6, 7.05]), ...S([1.8, 7.0]), { over: 0 });
  return ink(b, .9, .42, '#5d544b') + ink(g2, 1, .55) + ink(g, 1.35, .82);
}

// ---------------- hand (units: palm length = wrist to middle knuckle; origin the wrist; fingers up) ----------------
const RH = [[0, 0], [-.32, -.18], [-.58, -.42], [-.78, -.62], [-.92, -.8], [-.3, -.95], [-.36, -1.38], [-.39, -1.64], [-.41, -1.86],
  [-.05, -1.0], [-.05, -1.5], [-.05, -1.8], [-.05, -2.04], [.19, -.95], [.25, -1.42], [.29, -1.69], [.32, -1.9], [.4, -.85], [.52, -1.2], [.59, -1.39], [.65, -1.56]];
const DH = RH.map(p => p.slice());
(() => {
  // thumb 6% low, palm 4% narrow, index 8% short, little finger 5% long, knuckle line flatter
  for (let i = 1; i <= 4; i++) DH[i] = vadd(RH[i], [0, .065]);
  DH[5] = [-.285, -.965]; DH[17] = [.385, -.89]; DH[13] = [.185, -.965];
  const chain = (ids, k, base) => { let prev = base; for (let i = 1; i < ids.length; i++) { const v = vmul(vsub(RH[ids[i]], RH[ids[i - 1]]), k); prev = vadd(prev, v); DH[ids[i]] = prev; } };
  chain([5, 6, 7, 8], .92, DH[5]); chain([13, 14, 15, 16], 1, DH[13]); chain([17, 18, 19, 20], 1.05, DH[17]);
})();
const FINGERS = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]];
const FR = [.11, .088, .095, .086, .074];
function palmPts(H) { return [[-.34, .03], [-.47, -.3], vadd(H[2], [-.04, .02]), vadd(H[5], [-.1, -.02]), vadd(H[9], [0, -.07]), vadd(H[13], [.02, -.07]), vadd(H[17], [.09, -.02]), [.47, -.45], [.36, .03]]; }
function refHand(V, u) {
  let s = `<rect x="0" y="0" width="1400" height="900" fill="url(#wall2)"/>`;
  const S = p => V(p), sk = 'url(#skin)';
  s += `<path d="${capsule(S([0, .1]), S([.08, 1.3]), .34 * u, .4 * u)}" fill="${sk}"/>`;
  s += `<path d="${closedSmooth(palmPts(RH).map(S))}" fill="${sk}"/>`;
  FINGERS.forEach((fi, k) => { const r = FR[k] * u; s += `<path d="${capsule(S(RH[fi[0]]), S(RH[fi[1]]), r * 1.15, r)}" fill="${sk}"/><path d="${capsule(S(RH[fi[1]]), S(RH[fi[2]]), r, r * .92)}" fill="${sk}"/><path d="${capsule(S(RH[fi[2]]), S(RH[fi[3]]), r * .92, r * .85)}" fill="${sk}"/>`; });
  // knuckles and creases (soft)
  let c = '';
  for (const fi of FINGERS.slice(1)) for (const i of [fi[1], fi[2]]) { const p = S(RH[i]); c += `M${f(p[0] - 7)} ${f(p[1] + 1)}q7 -3 14 0`; }
  for (const fi of FINGERS.slice(1)) { const p = S(RH[fi[0]]); c += `M${f(p[0] - 8)} ${f(p[1] + 3)}q8 -6 16 0`; }
  s += `<path d="${c}" stroke="#7a5442" stroke-opacity=".35" stroke-width="1.4" fill="none" stroke-linecap="round"/>`;
  for (const fi of FINGERS.slice(1)) { const t = S(RH[fi[3]]), d = S(RH[fi[2]]); const m = lerp(d, t, .55); s += `<ellipse cx="${f(m[0])}" cy="${f(m[1])}" rx="5" ry="7" fill="#f4ddd0" fill-opacity=".55"/>`; }
  s += `<path d="${smooth([[-.25, -.1], [-.05, -.45], [.25, -.6]].map(S))}" stroke="#7a5442" stroke-opacity=".18" stroke-width="10" fill="none" stroke-linecap="round"/>`;
  return s;
}
function pencilHand(V, u) {
  seed(150);
  const S = p => V(p), H = DH;
  let g = '', b = '', g2 = '';
  g += smooth(palmPts(H).slice(0, 4).map(S)) + smooth(palmPts(H).slice(6).map(S));
  g += line(...S([-.34, .03]), ...S([-.4, .9]), { over: 3 }) + line(...S([.36, .03]), ...S([.46, .9]), { over: 3 });
  FINGERS.forEach((fi, k) => {
    const r = FR[k] * u;
    g += capsuleLines(S(H[fi[0]]), S(H[fi[1]]), r * 1.1, r, false) + capsuleLines(S(H[fi[1]]), S(H[fi[2]]), r, r * .92, false) + capsuleLines(S(H[fi[2]]), S(H[fi[3]]), r * .92, r * .85, true);
    b += line(...S(H[fi[0]]), ...S(H[fi[3]]), { over: 6, wob: .5 });
    for (const i of [fi[1], fi[2]]) { const p = S(H[i]); g2 += `M${f(p[0] - r)} ${f(p[1] + 2)}q${f(r)} -4 ${f(2 * r)} 0`; }
  });
  b += smooth([H[5], H[9], H[13], H[17]].map(S));
  b += ell(S(H[0])[0], S(H[0])[1], .34 * u, .1 * u, { rot: 4 });
  return ink(b, .9, .45, '#5d544b') + ink(g2, 1, .6) + ink(g, 1.35, .84);
}

// ---------------- half figure for the outline band (units: heads) ----------------
function halfFigureContours() {
  const R = [[.17, 1.08], [.2, 1.22], [.5, 1.32], [.88, 1.42], [1.08, 1.62], [1.14, 1.95], [1.12, 2.4], [1.1, 2.85], [1.06, 3.3], [1.02, 3.75], [1.0, 4.1]];
  const Lf = [[-.17, 1.08], [-.2, 1.24], [-.5, 1.36], [-.88, 1.48], [-1.07, 1.68], [-1.13, 2.0], [-1.12, 2.45], [-1.1, 2.9], [-1.06, 3.35], [-1.02, 3.8], [-1.0, 4.1]];
  const head = [[-.17, 1.08], [-.22, 1.0], [-.33, .88], [-.4, .6], [-.4, .35], [-.3, .1], [0, 0], [.3, .1], [.4, .35], [.4, .6], [.33, .88], [.22, 1.0], [.17, 1.08]];
  const outer = [...Lf.slice().reverse(), ...head.slice(1, -1), ...R];
  const torsoR = [[.7, 1.9], [.66, 2.4], [.58, 2.95], [.6, 3.4], [.68, 3.8], [.7, 4.1]], armR = [[.74, 1.86], [.8, 2.4], [.82, 2.9], [.79, 3.4], [.77, 4.1]];
  const torsoL = torsoR.map(p => [-p[0], p[1] + .03]), armL = armR.map(p => [-p[0], p[1] + .03]);
  return { outer, torsoR, armR, torsoL, armL };
}
