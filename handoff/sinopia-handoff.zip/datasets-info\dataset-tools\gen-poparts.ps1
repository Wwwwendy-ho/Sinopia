﻿param([string]$D)
Add-Type -AssemblyName System.Drawing
$items=@(); $skipped=@()
foreach($sp in 'train','val','test'){
  $a=Get-Content "$D\x\annotations\person_keypoints_$sp.json" -Raw | ConvertFrom-Json
  $by=@{}; foreach($an in $a.annotations){ if(-not $by.ContainsKey($an.image_id)){$by[$an.image_id]=@()}; $by[$an.image_id]+=$an }
  foreach($im in $a.images){
    $p="$D\x\images\$sp\$($im.file_name)"
    if(-not (Test-Path -LiteralPath $p)){ $skipped+=$im.file_name; continue }
    $i=[Drawing.Image]::FromFile($p); $w=$i.Width;$h=$i.Height;$i.Dispose()
    $figs=@(); foreach($an in $by[$im.id]){ $k=@(); if($an.keypoints){ for($j=0;$j -lt 51;$j+=3){ $k+=,@([double]$an.keypoints[$j],[double]$an.keypoints[$j+1],[int]$an.keypoints[$j+2]) } }
      $figs+=[ordered]@{bbox=$an.bbox;num_keypoints=$an.num_keypoints;keypoints=$k} }
    $items+=[ordered]@{id="$sp/$($im.id)";split=$sp;image="x/images/$sp/$($im.file_name)";width=$w;height=$h;style=$im.metadata.wikiart_style;wikiart_url=$im.metadata.wikiart_url;figures=$figs}
  }
}
[ordered]@{dataset='PoPArt';count=$items.Count;skipped_missing_files=$skipped;
 keypoint_order='17 COCO keypoints: nose,left_eye,right_eye,left_ear,right_ear,left_shoulder,right_shoulder,left_elbow,right_elbow,left_wrist,right_wrist,left_hip,right_hip,left_knee,right_knee,left_ankle,right_ankle. Each keypoint [x,y,v] in pixels of the image file; v=0 not labelled, 1 labelled-occluded, 2 visible (COCO). Paths relative to this directory (images under x/ ). Max 4 labelled figures per image.';
 items=$items} | ConvertTo-Json -Depth 8 -Compress | Set-Content -Encoding UTF8 "$D\manifest.json"
"items $($items.Count) skipped $($skipped.Count)"

