// Phase 3 snapshots: (1) desktop Overlay, full figure; (2) desktop Side, hand study; (3) phone, outline band + sheet.
function defs3() {
  const extra = `<linearGradient id="wall" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#d9d2c6"/><stop offset="1" stop-color="#bfb5a6"/></linearGradient>
<linearGradient id="wall2" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#cfd0cb"/><stop offset="1" stop-color="#a9aaa4"/></linearGradient>
<linearGradient id="skin" x1="0" x2="1" y1="0" y2=".3"><stop offset="0" stop-color="#ecd2bf"/><stop offset=".55" stop-color="#d8b39b"/><stop offset="1" stop-color="#b98c73"/></linearGradient>
<pattern id="hatchO" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V5" stroke="${SIN}" stroke-opacity=".55" stroke-width="1.2"/></pattern>
<pattern id="hatchI" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><path d="M0 0V5" stroke="${SLATE}" stroke-opacity=".55" stroke-width="1.2"/></pattern>`;
  return defs().replace('</defs>', extra + '</defs>');
}
const chipLabel = (x, y, lab, fill = VER, size = 12) => { const w = tw(lab, size, SANS, 600) + 12; return `<g filter="url(#haloS)"><rect x="${f(x)}" y="${f(y - 10)}" width="${f(w)}" height="20" rx="3" fill="${fill}"/></g>` + T(x + w / 2, y + 4.3, lab, { size, weight: 600, anchor: 'middle', fill: '#fff8ef' }); };
const capsLab = (x, y, t, anchor = 'end') => T(x, y, t, { size: 9.5, fill: SOFT, ls: .8, anchor, op: .85 });
// bracket along a direction: from a, reference end r, drawing end d (screen); offset o px to one side
function bracketAlong(a, r, d, o, label, labelSide = 1) {
  const u = vunit(vsub(r, a)), n = vperp(u);
  const A1 = vadd(a, vmul(n, o - 4)), R1 = vadd(r, vmul(n, o - 4)), A2 = vadd(a, vmul(n, o + 4)), D2 = vadd(d, vmul(n, o + 4)), R2 = vadd(vadd(a, vmul(u, vlen(vsub(r, a)))), vmul(n, o + 4));
  const dproj = vadd(a, vmul(u, ((d[0] - a[0]) * u[0] + (d[1] - a[1]) * u[1])));
  const D2p = vadd(dproj, vmul(n, o + 4));
  let s = `<g filter="url(#halo)"><path d="M${P2(A1)}L${P2(R1)}" stroke="${SIN}" stroke-width="1.6" stroke-dasharray="4 2.5"/><path d="M${P2(A2)}L${P2(D2p)}" stroke="${INK}" stroke-width="1.6"/>`;
  const tk = (p, k) => { const q1 = vadd(p, vmul(n, -k)), q2 = vadd(p, vmul(n, k)); return `M${P2(q1)}L${P2(q2)}`; };
  s += `<path d="${tk(vadd(a, vmul(n, o)), 9)}${tk(R1, 5)}${tk(D2p, 5)}" stroke="${INK}" stroke-width="1.3"/>`;
  s += `<path d="M${P2(D2p)}L${P2(R2)}" stroke="${VER}" stroke-width="4"/></g>`;
  // extension lines from the features to the bracket
  s += `<path d="M${P2(a)}L${P2(vadd(a, vmul(n, o)))}M${P2(r)}L${P2(R1)}M${P2(d)}L${P2(D2p)}" stroke="${INK}" stroke-opacity=".45" stroke-dasharray="2 3" fill="none"/>`;
  return s;
}

/* ================= (1) desktop Overlay: full figure ================= */
function snap1() {
  const W = 1280, H = 800;
  let s = spreadTop(W, H) + masthead(10, 6) + toolbar('overlay', true);
  const P = [44, 58, 978, 760];
  s += paneFrame(...P);
  seed(70); s += washiTape(P[0] + 14, P[1] - 12, 64, 19, -4, 'washi1') + washiTape(P[2] - 84, P[1] - 11, 64, 19, 3, 'washi3');
  const lt = layerTab(60, 68, 'Drawing', '#29bad5', true); s += lt.s + icon('eye', 60 + lt.w + 6, 74, INK, 1.2);
  const lt2 = layerTab(60 + lt.w + 34, 68, 'Reference', '#d6452a', false); s += lt2.s + icon('eye', 60 + lt.w + 34 + lt2.w + 6, 74, INK, 1.2);
  s += toolsBtn(P[2] - 70, 75);
  const u = 74, ox = 560, oy = 128, V = mapU(ox, oy, u);
  s += `<svg x="48" y="102" width="926" height="654" viewBox="48 102 926 654" overflow="hidden">`;
  s += `<g opacity=".62">${refFigure(V, u)}</g><rect x="48" y="102" width="926" height="654" fill="#f1ece2" opacity=".3"/>`;
  s += pencilFigure(V, u);
  const dim = k => k === 0 ? 1 : .5;
  // skeleton (reference dashed sinopia, drawing graphite)
  let skR = '', skD = '';
  for (const [a, b] of BONES) { skR += `M${P2(V(RJ[a]))}L${P2(V(RJ[b]))}`; skD += `M${P2(V(DJ[a]))}L${P2(V(DJ[b]))}`; }
  s += `<path d="${skR}" stroke="${SIN}" stroke-opacity=".55" stroke-width="1.1" stroke-dasharray="3 2.5" fill="none"/><path d="${skD}" stroke="${INK}" stroke-opacity=".45" stroke-width="1" fill="none"/>`;
  for (const k of FIG_PTS) s += refRing(V(RJ[k]), 3.6, .95) + drwDot(V(DJ[k]), 2.8);
  // head-height ruler (size by head height): reference heads on the left of the figure
  { const x = V([-2.6, 0])[0]; let r = `<path d="M${x} ${f(V([0, 0])[1])}V${f(V([0, 7.45])[1])}" stroke="${SIN}" stroke-width="1.4"/>`;
    for (let i = 0; i <= 7; i++) r += `<path d="M${x - 6} ${f(V([0, i])[1])}h12" stroke="${SIN}" stroke-width="1.4"/>`;
    r += `<path d="M${x - 6} ${f(V([0, 7.45])[1])}h12" stroke="${SIN}" stroke-width="2"/>`;
    s += `<g filter="url(#haloS)">${r}<path d="M${x} ${f(V([0, 7.05])[1])}h14" stroke="${INK}" stroke-width="2"/></g>`;
    for (let i = 0; i < 7; i++) s += T(x - 11, V([0, i + .5])[1] + 4, String(i + 1), { size: 11.5, font: SERIF, italic: true, anchor: 'end', fill: SIN });
    s += T(x + 18, V([0, 7.05])[1] + 4, '7.1', { size: 11.5, weight: 600, fill: INK }) + T(x + 18, V([0, 7.45])[1] + 9, '7.5', { size: 11.5, weight: 600, fill: SIN });
    const cap = 'heads', cw = tw(cap, 11.5, SERIF, 400, true) + 12;
    s += `<rect x="${f(x - cw / 2)}" y="${f(V([0, 0])[1] - 22)}" width="${f(cw)}" height="18" rx="3" fill="#fbf7ee" stroke="${SIN}" stroke-opacity=".6"/>` + T(x, V([0, 0])[1] - 9, cap, { size: 11.5, font: SERIF, italic: true, anchor: 'middle', fill: SIN });
  }
  // size-by measure: head height beside the head
  s += measureMark(V([0, 0]), V([0, 1.0]), V([.95, 0])[0], 'head height', 1, [V([.1, 0])[0], V([.2, 0])[0]]);
  // balance line from the pit of the neck
  { const x = V([0, 0])[0], y1 = V([0, 1.42])[1], y2 = V([0, 7.5])[1];
    s += `<g filter="url(#haloS)"><path d="M${x} ${y1}V${y2}" stroke="${SIN}" stroke-width="1.3" stroke-dasharray="6 4"/></g>`;
    s += T(x + 6, V([0, 6.3])[1], 'balance line', { size: 11, font: SERIF, italic: true, fill: SIN }); }
  // shoulder tilt: both lines extended, arc and angle
  { const ext = (J, c) => { const a = V(J.shR), b = V(J.shL), d = vunit(vsub(b, a)); const e = vadd(b, vmul(d, 70)); return `<path d="M${P2(vadd(a, vmul(d, -10)))}L${P2(e)}" stroke="${c}" stroke-width="1.5"${c === SIN ? ' stroke-dasharray="4 2.5"' : ''}/>`; };
    s += `<g filter="url(#haloS)" opacity="${dim(2)}">${ext(RJ, SIN)}${ext(DJ, INK)}</g>`;
    const piv = V(DJ.shL), r = 52, a1 = Math.atan2(V(RJ.shL)[1] - V(RJ.shR)[1], V(RJ.shL)[0] - V(RJ.shR)[0]);
    s += `<path d="M${f(piv[0] + r)} ${f(piv[1])}A${r} ${r} 0 0 0 ${f(piv[0] + r * Math.cos(a1))} ${f(piv[1] + r * Math.sin(a1))}" stroke="${SIN}" stroke-width="1.6" fill="none" opacity="${dim(2)}"/>`;
    s += canvasTag([piv[0] + 88, piv[1] - 2], '3', false, dim(2)); }
  // arrows (drawing point to where the reference puts it)
  for (const k of ['kR', 'kL', 'aR', 'aL', 'toR', 'toL']) s += arrowMark(V(DJ[k]), V(RJ[k]), true, k[0] === 'k' ? .8 : 1);
  s += arrowMark(V(DJ.wrL), V(RJ.wrL), true, dim(1)) + arrowMark(V(DJ.haL), V(RJ.haL), true, dim(1) * .8, 1.8);
  s += arrowMark(V(DJ.haR), V(RJ.haR), false, dim(4));
  // outline item: a short band at the left hip
  { const ref = [[.64, 3.55], [.73, 3.85], [.74, 4.1], [.66, 4.42]].map(V), out = [[.66, 3.55], [.8, 3.82], [.84, 4.1], [.69, 4.42]].map(V);
    s += `<path d="${polyD(densify(ref))}L${polyD(densify(out.slice().reverse())).slice(1)}Z" fill="${SIN}" fill-opacity=".34" opacity="${dim(3)}"/><path d="${smooth(ref)}" stroke="${SIN}" stroke-width="1.2" fill="none" opacity="${dim(3)}"/>`; }
  // the selected item: legs bracket along the right (supporting) leg
  s += bracketAlong(V(RJ.hR), V(RJ.aR), V(DJ.aR), 70);
  const lgN = vperp(vunit(vsub(V(RJ.aR), V(RJ.hR)))), lgM = vadd(lerp(V(RJ.hR), V(RJ.aR), .62), vmul(lgN, 70));
  s += chipLabel(lgM[0] - 138, lgM[1], '0.4 heads too short');
  // tags
  s += canvasTag(vadd(vadd(V(RJ.hR), vmul(lgN, 70)), [-18, -8]), '1', true, 1) + canvasTag(V([1.62, 3.25]), '2', true, dim(1)) + canvasTag(V([1.1, 4.15]), '4', false, dim(3));
  s += canvasTag(V([-1.62, 4.35]), '5', false, dim(4)) + canvasTag(V([-.78, 7.24]), '6', false, dim(5));
  s += pinMark(V(RJ.pit));
  s += `</svg>`;
  s += undoSlip(511, 712, 'Pinned at the pit of the neck');
  s += seg3(52, 766, ['Tint', 'Blend', 'Wipe', 'Outline'], 1, 250, 26, 12);
  s += T(318, 783.5, 'Reference', { size: 12, fill: SOFT }) + `<path d="M380 779H520" stroke="${INK}" stroke-opacity=".45" stroke-width="2"/><path d="M380 779H436" stroke="${SIN}" stroke-width="2.4"/><circle cx="436" cy="779" r="7" fill="${PAPER}" stroke="${INK}" stroke-width="1.4"/>` + T(530, 783.5, '40%', { size: 12, fill: SOFT });
  s += reportCol(996, 58, 266, 728, FIG_REPORT);
  return s;
}

// shared desktop report column (phase 1 slip, with mode picker, section tabs and ranked list)
function reportCol(x, y, w, h, R) {
  seed(81);
  let s = softRect(x, y, w, h, 4, 7, 6, .05, 2) + `<rect x="${x + 2}" y="${y + 3}" width="${w}" height="${h}" fill="${INK}" fill-opacity=".16"/>`;
  s += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${SLIP}"/><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#grainP)" opacity=".7"/>`;
  s += `<rect x="${x + .5}" y="${y + .5}" width="${w - 1}" height="${h - 1}" fill="none" stroke="${INK}" stroke-opacity=".55"/>`;
  s += washiTape(x + w / 2 - 34, y - 9, 68, 18, -2.5, 'washi1');
  const L = x + 16, Rr = x + w - 16;
  let yy = y + 34;
  s += T(L, yy, 'Proportions', { size: 19, font: SERIF, weight: 700 }) + `<path d="M${L} ${yy + 5}C${L + 40} ${yy + 3.5} ${L + 80} ${yy + 5.5} ${L + 108} ${yy + 4}" stroke="${SIN}" stroke-width="1.8" fill="none"/>`;
  s += icon('help', Rr - 42, yy - 13, SOFT, 1.4) + icon('close', Rr - 16, yy - 13, INK, 1.5);
  yy += 14;
  const lab = (t, yv) => T(L, yv, t, { size: 10.5, fill: SOFT, ls: .6 });
  for (const [k, v, ic] of [['CHECKING', R.mode], ['PIN', R.pin, 'pin'], ['SIZE BY', R.size]]) {
    s += lab(k, yy + 17); if (ic) s += icon('pin', L + 24, yy + 5, VER, 1.6, .95);
    const c = chip(L + 72, yy, v, { drop: true, size: 12 }); s += c.s; yy += 30;
  }
  yy += 8; s += ruleH(L - 4, Rr + 4, yy); yy += 22;
  s += T(L, yy, R.count, { size: 14, font: SERIF, weight: 700 }) + T(Rr, yy, 'Usual tolerance', { size: 11.5, anchor: 'end', fill: SOFT });
  yy += 10;
  // section tabs: text tabs with counts; the selected one has the highlighter wash
  let tx = L - 4;
  R.tabs.forEach(([t, n, on, off]) => {
    const tw1 = tw(t, 12, SANS, on ? 600 : 400), tw2 = tw(n, 10.5, SANS, 600), ww = tw1 + tw2 + 14;
    if (on) s += `<path d="M${f(tx)} ${yy + 4}q${f(ww / 2)} -2 ${f(ww)} 0v17q${f(-ww / 2)} 2 ${f(-ww)} 0z" fill="${HL}" fill-opacity=".8"/>`;
    s += T(tx + 5, yy + 17, t, { size: 12, weight: on ? 600 : 400, fill: off ? SOFT : INK, op: off ? .6 : 1 }) + T(tx + 8 + tw1, yy + 17, n, { size: 10.5, weight: 600, fill: off ? SOFT : SIN, op: off ? .6 : 1 });
    tx += ww + 3;
  });
  yy += 26;
  R.items.forEach((it, i) => {
    const hgt = it.sub ? 46 : 31, isSel = i === R.sel;
    if (isSel) s += `<path d="M${L - 8} ${yy + 2}q${(Rr - L + 16) / 2} -2 ${Rr - L + 16} 0v${hgt - 3}q${-(Rr - L + 16) / 2} 2 ${-(Rr - L + 16)} 0z" fill="${HL}" fill-opacity=".72"/><rect x="${L - 8}" y="${yy + 2}" width="3" height="${hgt - 3}" fill="${SIN}"/>`;
    s += sevTag(L + 9, yy + 16, it.n, it.major, 9);
    s += T(L + 26, yy + 20.5, it.text, { size: 13, weight: it.major ? 600 : 400 });
    if (it.sub) s += T(L + 26, yy + 37, '↳ ' + it.sub, { size: 11.5, fill: SOFT, italic: true });
    if (!isSel) s += ink(line(L + 24, yy + hgt, Rr, yy + hgt, { over: 0, wob: .3 }), .6, .14);
    yy += hgt;
  });
  yy += 6;
  if (R.extra) { const r = R.extra(L, Rr, yy); s += r.s; yy = r.yy; }
  for (const [ic, lines, col] of R.notes) {
    yy += 17;
    s += (ic === 'check' ? icon('check', L, yy - 12, '#4d6b47', 1.6, .85) : T(L + 6, yy, ic, { size: 12.5, weight: 700, fill: col || SIN, anchor: 'middle' }));
    lines.forEach((ln, k) => { s += T(L + 18, yy + k * 15.5, ln, { size: 12, fill: SOFT }); });
    yy += (lines.length - 1) * 15.5 + 2;
  }
  yy += 12; s += ruleH(L - 4, Rr + 4, yy); yy += 20;
  s += lab('SHOW', yy); yy += 7;
  let cx = L;
  for (const it of R.show) { if (!it) { cx = L; yy += 31; continue; } const c = chip(cx, yy, it[0], { check: true, on: it[1], size: 12, h: 25 }); s += c.s; cx += c.w + 5; }
  yy += 40;
  s += lab('TOLERANCE', yy); yy += 7;
  s += seg3(L, yy, ['Strict', 'Usual', 'Relaxed'], 1, Rr - L, 26, 12);
  yy += 40;
  s += T(L, yy, 'Edit points', { size: 12.5, fill: INK }) + `<path d="M${L} ${yy + 3}h${f(tw('Edit points', 12.5))}" stroke="${INK}" stroke-opacity=".4"/>`;
  s += T(L + 84, yy, 'Reset points', { size: 12.5, fill: INK }) + `<path d="M${L + 84} ${yy + 3}h${f(tw('Reset points', 12.5))}" stroke="${INK}" stroke-opacity=".4"/>`;
  s += T(L, y + h - 14, R.foot, { size: 11.5, fill: SOFT, italic: true, font: SERIF });
  return s;
}

const FIG_REPORT = {
  mode: 'Full figure (auto)', pin: 'Pit of the neck', size: 'Head height', count: '6 differences', sel: 0,
  tabs: [['All', '6', true], ['Body', '4'], ['Hands', '1'], ['Outline', '1'], ['Face', '–', false, true]],
  items: [
    { n: '1', major: true, text: 'Legs 0.4 heads too short', sub: 'The knees sit 0.2 heads high with it' },
    { n: '2', major: true, text: 'Left forearm 9% too long' },
    { n: '3', major: false, text: 'Shoulders tilted 6° less than ref.' },
    { n: '4', major: false, text: 'Left hip outline 5% too far out' },
    { n: '5', major: false, text: 'Right hand 8% too small' },
    { n: '6', major: false, text: 'Standing foot 0.3 heads off balance' }
  ],
  extra: (L, R, yy) => {
    let s = icon('ruler', L - 1, yy + 2, SIN, 1.3, .9) + T(L + 18, yy + 14, 'Heads tall: 7.1', { size: 12.5, weight: 600 }) + T(L + 112, yy + 14, '(reference 7.5)', { size: 12, fill: SOFT });
    return { s, yy: yy + 16 };
  },
  notes: [['check', ['Close enough: torso, upper arms,', 'hip tilt, head size.']], ['~', ['Right thigh is foreshortened in the', 'reference: its length is approximate.']],
    ['·', ['Face too small here for features.', 'Crop to the head to check them.'], SOFT]],
  show: [['Arrows', true], ['Points', true], ['Skeleton', true], null, ['Outline band', false], ['Grid', false]],
  foot: 'Left and right are the person’s own.'
};

/* ================= (2) desktop Side: hand study ================= */
function snap2() {
  const W = 1280, H = 800, gx = 512;
  let s = spreadSide(W, H, gx) + masthead(10, 6) + toolbar('side', true);
  const PL = [44, 58, 497, 760], PR = [527, 58, 980, 760];
  s += paneFrame(...PL) + paneFrame(...PR);
  seed(72); s += washiTape(PL[0] + 14, PL[1] - 12, 60, 18, -4, 'washi1') + washiTape(PR[2] - 80, PR[1] - 11, 60, 18, 3, 'washi2');
  s += `<circle cx="${PL[0] + 18}" cy="82" r="3.2" fill="${VER}"/>` + T(PL[0] + 30, 87, 'Drawing', { size: 15, font: SERIF, weight: 700 }) + toolsBtn(PL[2] - 70, 75);
  s += `<circle cx="${PR[0] + 18}" cy="82" r="3.2" fill="none" stroke="${SOFT}"/>` + T(PR[0] + 30, 87, 'Reference', { size: 15, font: SERIF, weight: 700 }) + toolsBtn(PR[2] - 70, 75);
  const u = 172;
  const knuck = (Hh, V, c, dash) => { const a = V(Hh[5]), b = V(Hh[17]), d = vunit(vsub(b, a)); return `<path d="M${P2(vadd(a, vmul(d, -46)))}L${P2(vadd(b, vmul(d, 40)))}" stroke="${c}" stroke-width="1.5"${dash ? ' stroke-dasharray="4 2.5"' : ''}/>`; };
  // drawing pane
  { const ox = 300, oy = 640, V = mapU(ox, oy, u);
    s += `<svg x="48" y="102" width="445" height="654" viewBox="48 102 445 654" overflow="hidden"><rect x="0" y="0" width="1400" height="900" fill="#efe9dd"/><rect x="0" y="0" width="1400" height="900" fill="url(#grainP)" opacity=".8"/>`;
    s += pencilHand(V, u);
    let skR = '', skD = '';
    for (const fi of FINGERS) { const ch = [0, ...fi]; skD += polyD(ch.map(i => V(DH[i]))); }
    s += `<path d="${skD}" stroke="${INK}" stroke-opacity=".4" fill="none"/>`;
    for (let i = 0; i < 21; i++) s += refRing(V(RH[i]), 3.4, .9) + drwDot(V(DH[i]), 2.7);
    // knuckle line: reference (dashed) and drawing
    s += `<g filter="url(#haloS)" opacity=".5">${knuck(RH, V, SIN, true)}${knuck(DH, V, INK)}</g>`;
    // arrows: thumb (item 2), little finger tip (item 5), palm width (item 4)
    for (const i of [2, 3, 4]) s += arrowMark(V(DH[i]), V(RH[i]), true, .5);
    s += arrowMark(V(DH[20]), V(RH[20]), false, .5) + arrowMark(V(DH[19]), V(RH[19]), false, .5, 1.4);
    s += arrowMark(V(DH[17]), V(RH[17]), false, .5) + arrowMark(V(DH[5]), V(RH[5]), false, .5);
    // selected item 1: index finger bracket
    s += bracketAlong(V(RH[5]), V(RH[8]), V(DH[8]), -26);
    s += chipLabel(V(RH[7])[0] - 140, V(RH[7])[1], '8% too short');
    s += canvasTag(vadd(V(RH[8]), [-34, -22]), '1', true);
    s += canvasTag(vadd(V(DH[3]), [-28, 14]), '2', true, .5) + canvasTag(vadd(V(DH[17]), [44, 4]), '3', false, .5) + canvasTag(vadd(V(DH[5]), [-34, 18]), '4', false, .5) + canvasTag(vadd(V(DH[20]), [18, -8]), '5', false, .5);
    s += pinMark(V(RH[0]), .9);
    s += `</svg>`; }
  // reference pane
  { const ox = 783, oy = 640, V = mapU(ox, oy, u);
    s += `<svg x="531" y="102" width="445" height="654" viewBox="531 102 445 654" overflow="hidden">${refHand(V, u)}`;
    for (let i = 0; i < 21; i++) s += refRing(V(RH[i]), 3.4, .95);
    s += `<g filter="url(#haloS)" opacity=".6">${knuck(RH, V, SIN, true)}</g>`;
    // highlight the selected finger on the reference too
    s += `<path d="${polyD([5, 6, 7, 8].map(i => V(RH[i])))}" stroke="${HL}" stroke-width="9" stroke-opacity=".6" fill="none" stroke-linecap="round"/>`;
    s += measureMark(V(RH[9]), V(RH[0]), V([.78, 0])[0], 'palm length', 1, [V([.05, 0])[0], V([.42, 0])[0]]);
    s += pinMark(V(RH[0]), .9);
    s += `</svg>`; }
  const cap = 'Hand study: right hand, back view', cw = tw(cap, 12.5, SERIF, 400, true) + 20;
  s += `<rect x="58" y="114" width="${f(cw)}" height="24" rx="3" fill="#fbf7ee" fill-opacity=".94" stroke="${INK}" stroke-opacity=".35"/>` + T(68, 130, cap, { size: 12.5, font: SERIF, italic: true });
  s += reportCol(996, 58, 266, 728, HAND_REPORT);
  return s;
}
const HAND_REPORT = {
  mode: 'Hand study (auto)', pin: 'Wrist', size: 'Palm length', count: '5 differences', sel: 0,
  tabs: [['All', '5', true], ['Hands', '5'], ['Outline', '0'], ['Body', '–', false, true], ['Face', '–', false, true]],
  items: [
    { n: '1', major: true, text: 'Index finger 8% too short' },
    { n: '2', major: true, text: 'Thumb sits 6% too low' },
    { n: '3', major: false, text: 'Knuckle line 5° flatter than ref.' },
    { n: '4', major: false, text: 'Palm 4% too narrow' },
    { n: '5', major: false, text: 'Little finger 5% too long' }
  ],
  extra: (L, R, yy) => {
    let s = T(L, yy + 16, 'FINGER LENGTHS', { size: 10.5, fill: SOFT, ls: .6 }) + T(R, yy + 16, 'of palm length', { size: 11, fill: SOFT, anchor: 'end', italic: true });
    yy += 24;
    const rows = [['Thumb', .70, .70], ['Index', .92, .85], ['Middle', 1.04, 1.04], ['Ring', .95, .95], ['Little', .72, .76]];
    const x0 = L + 52, sc = 118;
    rows.forEach(([n, r, d], i) => {
      const y = yy + i * 15;
      if (i === 1) s += `<rect x="${L - 8}" y="${y - 1}" width="${R - L + 16}" height="14" fill="${HL}" fill-opacity=".5"/>`;
      s += T(L, y + 10, n, { size: 11.5, fill: i === 1 ? INK : SOFT, weight: i === 1 ? 600 : 400 });
      s += `<path d="M${x0} ${y + 4}h${f(r * sc)}" stroke="${SIN}" stroke-width="1.5" stroke-dasharray="3 2"/><path d="M${x0} ${y + 9}h${f(d * sc)}" stroke="${INK}" stroke-width="2.4"/>`;
      if (Math.abs(r - d) > .03) s += `<path d="M${f(x0 + Math.min(r, d) * sc)} ${y + 9}h${f(Math.abs(r - d) * sc)}" stroke="${VER}" stroke-width="4"/>`;
      s += T(R, y + 10, d.toFixed(2), { size: 11, anchor: 'end', fill: SOFT });
    });
    return { s, yy: yy + 5 * 15 };
  },
  notes: [['check', ['Close enough: middle and ring', 'fingers, finger spread.']]],
  show: [['Arrows', true], ['Points', true], ['Knuckles', true]],
  foot: 'Left and right are the person’s own.'
};

/* ================= (3) phone: outline band + bottom sheet ================= */
function snap3() {
  const W = 375, H = 812;
  let s = spreadTop(W, H) + masthead(5, 3, true);
  const P = [8, 38, 368, 742];
  s += paneFrame(P[0], P[1], P[2], P[3], 46);
  seed(74); s += washiTape(20, 31, 38, 12, -4, 'washi1');
  const lt = layerTab(18, 46, 'Drawing', '#29bad5', true, 32); s += lt.s;
  const lt2 = layerTab(18 + lt.w + 8, 46, 'Reference', '#d6452a', false, 32); s += lt2.s;
  s += icon('tools', 336, 54, INK, 1.3);
  const u = 84, ox = 188, oy = 104, V = mapU(ox, oy, u), C = halfFigureContours();
  const figH = 4.1 * u, tol = .03 * figH;
  s += `<svg x="12" y="88" width="352" height="372" viewBox="12 88 352 372" overflow="hidden">`;
  // reference stand-in (faded in Blend), then pencil drawing
  let ref = `<rect x="0" y="0" width="400" height="900" fill="url(#wall)"/>`;
  const outerS = C.outer.map(V);
  ref += `<path d="${smooth(outerS)}L${P2(V([1.0, 4.4]))}L${P2(V([-1.0, 4.4]))}Z" fill="url(#skin)"/>`;
  for (const [t, a] of [[C.torsoR, C.armR], [C.torsoL, C.armL]]) ref += `<path d="${smooth(t.map(V))}L${P2(V(vadd(a[a.length - 1], [0, .3])))}L${P2(V(vadd(t[t.length - 1], [0, .3])))}Z" fill="none"/><path d="${polyD(densify(t.map(V)))}L${polyD(densify(a.slice().reverse().map(V))).slice(1)}Z" fill="#cbc3b6"/>`;
  ref += `<path d="M${P2(V([-.41, .5]))}C${P2(V([-.44, -.12]))} ${P2(V([.44, -.12]))} ${P2(V([.41, .5]))}C${P2(V([.3, .2]))} ${P2(V([-.2, .12]))} ${P2(V([-.41, .5]))}Z" fill="#5b4535" fill-opacity=".85"/>`;
  s += `<g opacity=".5">${ref}</g><rect x="12" y="88" width="352" height="372" fill="#f1ece2" opacity=".45"/>`;
  // drawing contour = reference + offsets along the outward normal
  const bumpsOuter = [[[1.1, 1.75], .06 * figH, .32], [[0, 0], -.04 * figH, .28], [[-.9, 1.5], .012 * figH, .3], [[-1.06, 3.4], -.012 * figH, .4]];
  const bumpsTorsoL = [[[-.58, 2.95], -.05 * figH, .32]];
  const offsetC = (pts, bumps) => {
    const D = densify(pts.map(V), 2.5), out = [], dd = [];
    for (let i = 0; i < D.length; i++) {
      const p = D[i], t = vsub(D[Math.min(i + 1, D.length - 1)], D[Math.max(i - 1, 0)]); let n = vunit(vperp(t));
      const c = [ox, oy + Math.min(Math.max((p[1] - oy) / u, .5), 3.2) * u]; if ((p[0] - c[0]) * n[0] + (p[1] - c[1]) * n[1] < 0) n = vmul(n, -1);
      let d = 0; for (const [q, A, sg] of bumps) { const qq = V(q), r = vlen(vsub(p, qq)) / (sg * u); d += A * Math.exp(-r * r); }
      d += Math.sin(i * .05) * 1.2;
      out.push(vadd(p, vmul(n, d))); dd.push(d);
    }
    return { D, out, dd };
  };
  const band = (o) => {
    let b = '';
    let i = 0;
    while (i < o.dd.length) {
      if (Math.abs(o.dd[i]) <= tol) { i++; continue; }
      const sgn = Math.sign(o.dd[i]); let k = i; while (k < o.dd.length && Math.abs(o.dd[k]) > tol * .55 && Math.sign(o.dd[k]) === sgn) k++;
      let i0 = i; while (i0 > 0 && Math.abs(o.dd[i0 - 1]) > tol * .55 && Math.sign(o.dd[i0 - 1]) === sgn) i0--;
      const A = o.D.slice(i0, k), B = o.out.slice(i0, k).reverse();
      b += `<path d="${polyD(A)}L${polyD(B).slice(1)}Z" fill="${sgn > 0 ? SIN : SLATE}" fill-opacity=".3"/><path d="${polyD(A)}L${polyD(B).slice(1)}Z" fill="url(#${sgn > 0 ? 'hatchO' : 'hatchI'})"/>`;
      i = k;
    }
    return b;
  };
  const oO = offsetC(C.outer, bumpsOuter), oL = offsetC(C.torsoL, bumpsTorsoL), oR = offsetC(C.torsoR, []);
  const aL = offsetC(C.armL, []), aR = offsetC(C.armR, []);
  s += band(oO) + band(oL);
  // pencil drawing: its contour (from the offsets) plus a few inner lines
  seed(160);
  const pen = o => smooth(o.out.filter((_, i) => i % 6 === 0));
  let g = pen(oO) + pen(oL) + pen(oR) + pen(aL) + pen(aR);
  let b = line(...V([0, .02]), ...V([0, 4.1]), { over: 4 }) + line(...V([-.38, .5]), ...V([.38, .5]), { over: 4 }) + line(...V([-.95, 1.47]), ...V([.95, 1.4]), { over: 6 }) + ell(V([0, 2.1])[0], V([0, 2.1])[1], .62 * u, .78 * u);
  g += smooth([[-.45, 1.5], [-.15, 1.56], [-.02, 1.5]].map(V)) + smooth([[.45, 1.48], [.15, 1.55], [.02, 1.5]].map(V));
  g += smooth([[-.16, .44], [-.08, .4], [-.02, .44]].map(V)) + smooth([[.04, .44], [.1, .4], [.18, .44]].map(V)) + smooth([[-.08, .78], [.03, .8], [.12, .78]].map(V));
  s += ink(b, .9, .42, '#5d544b') + ink(g, 1.3, .85);
  // reference outline: thin sinopia line over everything
  s += `<g filter="url(#haloS)"><path d="${polyD(oO.D)}${polyD(oL.D)}${polyD(oR.D)}${polyD(aL.D)}${polyD(aR.D)}" stroke="${SIN}" stroke-width="1.3" fill="none"/></g>`;
  // selected item 1: distance tick across the shoulder band
  { const i = oO.dd.reduce((m, v, k) => v > oO.dd[m] ? k : m, 0), a = oO.D[i], c = oO.out[i];
    s += `<g filter="url(#haloS)"><path d="M${P2(a)}L${P2(c)}" stroke="${VER}" stroke-width="2.4"/><path d="M${P2(vadd(c, [0, -5]))}L${P2(vadd(c, [0, 5]))}M${P2(vadd(a, [0, -5]))}L${P2(vadd(a, [0, 5]))}" stroke="${INK}" stroke-width="1.3"/></g>`;
    s += chipLabel(c[0] - 30, c[1] - 30, '6% out', VER, 11.5);
    s += canvasTag(vadd(c, [10, 22]), '1', true, 1, 8); }
  { const i = oL.dd.reduce((m, v, k) => v < oL.dd[m] ? k : m, 0); s += canvasTag(vadd(oL.out[i], [24, 0]), '2', false, .55, 8); }
  { const i = oO.dd.reduce((m, v, k) => (v < oO.dd[m] && oO.D[k][1] < oy + u * .3) ? k : m, Math.round(oO.dd.length / 2)); s += canvasTag(vadd(oO.D[i], [24, 8]), '3', false, .55, 8); }
  s += pinMark(V([0, 1.3]), .75);
  s += `</svg>`;
  // bottom sheet
  seed(76);
  const sy = 458;
  s += `<rect x="0" y="${sy - 6}" width="375" height="330" fill="${INK}" fill-opacity=".1"/><rect x="0" y="${sy - 2}" width="375" height="330" fill="${INK}" fill-opacity=".1"/>`;
  s += `<path d="M0 ${sy}Q2 ${sy - 1} 6 ${sy - 1.5}H369Q373 ${sy - 1} 375 ${sy}V760H0Z" fill="${SLIP}"/><rect x="0" y="${sy}" width="375" height="302" fill="url(#grainP)" opacity=".7"/>`;
  s += `<path d="M0 ${sy}Q2 ${sy - 1} 6 ${sy - 1.5}H369Q373 ${sy - 1} 375 ${sy}" stroke="${INK}" stroke-opacity=".55" fill="none"/>`;
  s += washiTape(160, sy - 9, 56, 15, -2, 'washi1');
  const L = 16, R = 359;
  let yy = sy + 32;
  s += T(L, yy, 'Proportions', { size: 18, font: SERIF, weight: 700 }) + `<path d="M${L} ${yy + 5}C${L + 40} ${yy + 3.5} ${L + 80} ${yy + 5.5} ${L + 102} ${yy + 4}" stroke="${SIN}" stroke-width="1.8" fill="none"/>`;
  s += T(L + 116, yy, '4 differences', { size: 12.5, fill: SOFT }) + icon('close', R - 18, yy - 14, INK, 1.6, 1.1);
  yy += 12;
  let c = chip(L, yy, 'Half figure', { drop: true, h: 32, size: 12.5 }); s += c.s;
  // section tabs (segmented)
  const segX = L + c.w + 8; s += seg3(segX, yy + 2, ['All 4', 'Body 1', 'Outline 3'], 2, R - segX, 28, 12);
  yy += 42;
  const items = [{ n: '1', major: true, text: 'Left shoulder outline 6% too far out' }, { n: '2', major: false, text: 'Right waist outline 5% too far in' }, { n: '3', major: false, text: 'Top of the head 4% too low' }];
  items.forEach((it, i) => {
    const hgt = 42, isSel = i === 0;
    if (isSel) s += `<path d="M${L - 8} ${yy + 2}q${(R - L + 16) / 2} -2 ${R - L + 16} 0v${hgt - 4}q${-(R - L + 16) / 2} 2 ${-(R - L + 16)} 0z" fill="${HL}" fill-opacity=".72"/><rect x="${L - 8}" y="${yy + 2}" width="3" height="${hgt - 4}" fill="${SIN}"/>`;
    s += sevTag(L + 10, yy + 21, it.n, it.major, 10);
    s += T(L + 32, yy + 26, it.text, { size: 14.5, weight: it.major ? 600 : 400 });
    if (!isSel) s += ink(line(L + 30, yy + hgt, R, yy + hgt, { over: 0, wob: .3 }), .6, .14);
    yy += hgt;
  });
  yy += 18;
  s += `<rect x="${L}" y="${yy - 9}" width="16" height="11" fill="${SIN}" fill-opacity=".3"/><rect x="${L}" y="${yy - 9}" width="16" height="11" fill="url(#hatchO)" stroke="${SIN}" stroke-opacity=".6"/>` + T(L + 22, yy, 'Drawing outside', { size: 12, fill: SOFT });
  s += `<rect x="${L + 132}" y="${yy - 9}" width="16" height="11" fill="${SLATE}" fill-opacity=".3"/><rect x="${L + 132}" y="${yy - 9}" width="16" height="11" fill="url(#hatchI)" stroke="${SLATE}" stroke-opacity=".6"/>` + T(L + 154, yy, 'Drawing inside', { size: 12, fill: SOFT });
  yy += 20;
  s += T(L, yy, '% of the figure’s height. Bands show only over tolerance.', { size: 11.5, fill: SOFT, italic: true, font: SERIF });
  // bottom bar (as phase 1)
  s += `<rect x="0" y="756" width="375" height="56" fill="${PAPER2}"/><rect x="0" y="756" width="375" height="56" fill="url(#grainP)" opacity=".6"/><path d="M0 756.5C60 755.6 130 757.3 190 756.4 250 755.6 320 757.2 375 756.5" stroke="${INK}" stroke-opacity=".62" stroke-width="1.2" fill="none"/>`;
  s += `<rect x="8.5" y="762.5" width="132" height="43" fill="none" stroke="${INK}" stroke-opacity=".7"/><path d="M98 772q20 -2 38 0v26q-20 2 -38 0z" fill="${HL}"/>`;
  s += icon('side', 22, 776, INK, 1.4, 1.1) + icon('stacked', 66, 776, INK, 1.4, 1.1) + icon('overlay', 109, 776, INK, 1.4, 1.1) + `<path d="M53 774v20M96 774v20" stroke="${INK}" stroke-opacity=".35"/>`;
  for (const [n, x, on] of [['link', 167, true], ['grid', 213], ['fit', 259], ['prop', 305, true], ['more', 345]]) { if (on) s += `<rect x="${x - 20}" y="762" width="40" height="44" rx="6" fill="url(#hatchD)"/>`; s += icon(n, x - 9, 775, on ? ONG : INK, 1.4, 1.15); }
  return s;
}

function build(name) {
  const S = { 1: [1280, 800, snap1], 2: [1280, 800, snap2], 3: [375, 812, snap3] }[name];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${S[0]}" height="${S[1]}" viewBox="0 0 ${S[0]} ${S[1]}">${defs3()}${S[2]()}</svg>`;
}
async function save(name, file, scale = 1) {
  const svg = build(name), W = +svg.match(/width="(\d+)"/)[1], H = +svg.match(/height="(\d+)"/)[1];
  const img = new Image(); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); await img.decode();
  const cv = document.createElement('canvas'); cv.width = W * scale; cv.height = H * scale; const cx = cv.getContext('2d'); cx.scale(scale, scale); cx.drawImage(img, 0, 0);
  const blob = await new Promise(r => cv.toBlob(r, 'image/png'));
  const res = await fetch('/__save/' + file, { method: 'POST', body: blob });
  return file + ' ' + blob.size + ' ' + res.status;
}
