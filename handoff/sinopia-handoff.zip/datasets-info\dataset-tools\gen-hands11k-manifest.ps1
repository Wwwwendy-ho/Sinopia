﻿param($root)
Add-Type -AssemblyName System.Drawing
$rows = Import-Csv (Join-Path $root 'HandInfo.csv')
$items = New-Object System.Collections.ArrayList; $missing = @(); $sizes=@{}
foreach($r in $rows){
  $rel = 'Hands/' + $r.imageName; $p = Join-Path $root ('Hands\' + $r.imageName)
  if(-not (Test-Path -LiteralPath $p)){ $missing += $r.imageName; continue }
  $fs=[IO.File]::OpenRead($p); try{ $im=[System.Drawing.Image]::FromStream($fs,$false,$false); $w=$im.Width; $h=$im.Height; $im.Dispose() } finally { $fs.Dispose() }
  $sizes["$($w)x$($h)"] = 1 + [int]$sizes["$($w)x$($h)"]
  $parts = $r.aspectOfHand.Split(' ')
  [void]$items.Add([ordered]@{ id=($r.imageName -replace '\.jpg$',''); image=$rel; width=$w; height=$h; subject=$r.id; age=[int]$r.age; gender=$r.gender; skinColor=$r.skinColor; accessories=[int]$r.accessories; nailPolish=[int]$r.nailPolish; irregularities=[int]$r.irregularities; aspect=$r.aspectOfHand; view=$parts[0]; side=$parts[1] })
}
$m = [ordered]@{ dataset='11k Hands (Afifi 2017)'; count=$items.Count; source='https://sites.google.com/view/11khands (Hands.zip + HandInfo.csv from the page Google Drive links)'; terms='The dataset is FREE for reasonable academic fair use.'; note='Paths relative to this folder. No keypoints. aspect = "<dorsal|palmar> <left|right>" copied from HandInfo.csv aspectOfHand (side is the person''s own hand). accessories/nailPolish/irregularities are 0/1 flags from the CSV.'; imageSizes=$sizes; missing=$missing; items=$items }
$m | ConvertTo-Json -Depth 5 -Compress | Set-Content (Join-Path $root 'manifest.json') -Encoding utf8
"items $($items.Count) missing $($missing.Count)"; $sizes.GetEnumerator() | % { "$($_.Key) $($_.Value)" }
$items | group { $_.aspect } | % { "$($_.Name) $($_.Count)" }
"accessories=1: " + ($items | ? { $_.accessories -eq 1 }).Count + " nailPolish=1: " + ($items | ? { $_.nailPolish -eq 1 }).Count + " subjects: " + ($items | group { $_.subject }).Count

