# Proportions check: decisions (override SPEC.md where they differ)

Approved by the user on 2026-11-18. SPEC.md (same folder) is the UX design; the snapshots a-desktop-overlay.png, b-desktop-side-grid.png, c-phone-sheet.png were shown to the user. Evidence: ..\bench\results\SUMMARY-planted.md.

## Engine
1. **Detector: MediaPipe Face Landmarker** (@mediapipe/tasks-vision 0.10.21, float16 face_landmarker.task, Apache-2.0). Self-host the files in the app repo (vendor/mediapipe/ for the bundle + wasm, models/face/face_landmarker.task), include the licence file. Load lazily on first use of Proportions (not on page load), show a small loading state, rely on the HTTP cache afterwards. Keep the existing face-api tiny model as fallback if WASM/model loading fails. Tested files are in ..\bench\vendor\mediapipe\ (copy those exact files; record SHA256 in README).
2. **Default "Size by": Robust auto.** Scale + translation from a robust L1 (IRLS) fit over the stable features, so a single mis-drawn feature does not move the fit and every feature can be flagged. Menu alternatives: Head height (hairline-to-chin; note the detector's top point is the hairline, not the crown), Eye line to chin, Eye spacing, Custom two points. When a single-measure option is chosen, the features defining that measure cannot be flagged and the report says so.
3. **Pin (reference point):** default "Auto (best fit)" which uses the robust fit's placement; user can pin to a feature preset (Between the eyes, Nose, Chin, Mouth) or drag a custom pin; when pinned, the drawing and reference coincide exactly at the pin and offsets are read relative to it. Pin and measure changes are Undo/Redo steps.
4. **Tilt:** never rotate the drawing by default. Measure features in a tilt-compensated frame using the midline axis (nose-mouth-chin vs reference), and report a tilt difference as ONE report item ("Head tilted 4 degrees more than the reference") instead of flagging every feature. "Match head tilt" checkbox (off by default) also rotates the displayed drawing to remove it.
5. **Tolerance (UPDATED after validation, see review/proportions-engine.md):** values are gain-corrected (they match the real drawn error). Usual: 3.5% for eye spacing, eye height/tilt, nose length, mouth height; 6.5% mouth width; 7% chin; jaw only "possible" above 10%; nose width and brow height 4%; head tilt 3 degrees. Strict = 0.72x, Relaxed = 2x. "Major" = 2x tolerance. The UI must label presets as Strict / Usual / Relaxed WITHOUT a single % number (tolerances differ per feature); the tooltip explains. Validation: Usual catches 68% of planted errors >= 4% (eyes 77-82%, nose 64%, mouth height 76% at 4%; ~100% at 6-8%), with 2.5% of clean controls flagged.
6. **Left/right = the subject's own left and right** (anatomical: the subject's left eye appears on the right of the image). The panel footnote says "Left and right are the person's own."
7. Distortion grid: thin-plate spline from drawing landmarks to reference landmarks; diagnostic overlay only, never warps the drawing.

## UI (from SPEC.md, confirmed)
- Desktop: report in a taped paper column on the right; the images shrink so nothing is covered.
- Phone: bottom sheet with three heights.
- Entry: "Proportions" toggle (key K) between Fit all and More; vermilion dot when faces are found in both; never opens by itself.
- Editable landmarks (drag on desktop, long-press then drag on touch), Reset points, Arrows/Points/Grid toggles, tolerance Strict/Usual/Relaxed, "Close enough" line.
- All new strings in en, zh-Hans, zh-Hant, es, fr as whole-sentence templates with placeholders via a key-based t(key, params).
- Tests must be silent (localStorage 'sinopia:interaction-sounds'='off' and stub audio).
