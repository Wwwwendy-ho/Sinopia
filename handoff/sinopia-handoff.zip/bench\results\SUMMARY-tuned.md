﻿# Sinopia auto-align benchmark: tuned confidence rule

Labels: **baseline** = original app; **fixed** = previous modified app (rotation off, approximate results offered, old confidence rule); **tuned** = this app (new evidence-based confidence rule, plausibility checks, method-switch protection, toast stacked above the Undo bar). Raw data: `bench\results\<label>-<suite>.json`; `calib-cufs/fs2k` hold the calibration evidence run; side-by-side live report: `bench\report.html`. Audio muted in every run. Same seeded case lists for all labels.

Split: cases are assigned to **calibration** or **held-out** by an FNV hash of the person/photo id (`bench\calib.js`). Thresholds were chosen on the calibration half only. Numbers below are the **held-out half** unless marked all. "Applied" = auto-applied (baseline: confident + approximate-with-warning; fixed/tuned: confident only).

## CUFS, rotation-0 cases (held-out n=79; all n=143 in brackets)
| metric | baseline | fixed | tuned |
|---|---|---|---|
| applied | 100% (100) | 68.4% (64.3) | 100% (98.6) |
| offered | 0 | 31.6% (35.7) | 0% (1.4) |
| declined | 0 | 0 | 0 |
| accurate-applied (NME<=0.15) | 100% | 68.4% | 100% |
| offered although accurate | 0 | 31.6% (35.7) | 0% (1.4) |
| confident but wrong (NME>0.25) | 0 | 0 | 0 |
| NME35 median (applied) | 0.046 | 0.042 | 0.041 |
| unwanted tilt (>2 deg applied) | 3.8% (3.5) | 0% | 0% |
| median ms/case (end-to-end, see timing caveat) | 7525 | 9351 | 1579 |

## CUFS, camera tilt 2-8 deg, rotation off (held-out n=27; all n=47)
| metric | baseline | fixed | tuned |
|---|---|---|---|
| applied | 100% (100) | 70.4% (63.8) | 7.4% (10.6) |
| offered | 0 | 29.6% (36.2) | 92.6% (89.4) |
| accurate-applied | 100% (97.9) | 63.0% (55.3) | 7.4% (10.6) |
| offered and accurate | - | 18.5% (29.8) | 74.1% (74.5) |
| confident but wrong | 0 | 0 | 0 |
| NME35 median (applied) | 0.044 | 0.102 | 0.059 (only 2 applied) |
Tilted photos are deliberately offered (the unmodelled tilt exceeds 2.5 deg); the fixed rule applied crooked fits (NME up to 0.17). With "Allow rotation in auto-align" on, the free-rotation term is no longer unmodelled (not re-benchmarked on tuned).

## FS2K (held-out n=44 pairs; all 120 in brackets). Consistency of the untransformed vs transformed sketch; bad = inconsistent >2% diagonal or >2 deg or a side without a match
| metric | baseline | fixed | tuned |
|---|---|---|---|
| both sketches auto-applied | 93.3% (95.9) | 40.9% (34.2) | 27.3% (25.0) |
| confident but wrong (both applied, >3% diag or >2 deg) | 4 (13) | 4 (10) | **0 (0)** |
| bad pairs | 8 (23) | 14 (45) | 14 (45) |
| bad pairs not applied (offered/declined) | 3 (5) | 9 (33) | **14/14 (44/45 = 98%)** |
| good pairs applied | 37 (98) | 13 (29) | 12 (29) |
| median consistency position error, applied pairs, % diagonal | 1.00 (0.89) | 0.68 (0.73) | 0.54 (0.45) |
| rotation-0 pairs only (held-out bad=6; all bad=19/19/17): wrong-applied; bad not applied | 3; 2 of 6 (all: 11; 4 of 19) | 1; 4 of 6 (all: 2; 13 of 17) | 0; 6 of 6 (all: 0; 16 of 17) |
Honest cost: the share of pairs applied automatically falls (fixed/tuned both 25-35%) because FS2K faces with turned heads, strong style differences or tilt are offered; good-and-applied pairs are unchanged vs fixed (29 of 120).

Named failures: `photo1/image1432` (tiny on the cheek) is now offered on both sides; `photo2/image0018` offered on both sides; `photo1/image0710` (3/4 view, 12.8% inconsistent): the untransformed sketch is offered but the transformed sketch is still auto-applied with no warning flag (a remaining miss, but the pair is not both-applied).

## Retake (100 cases; rotation +-3, same estimator path as before)
| | baseline | fixed | tuned |
|---|---|---|---|
| confident / correct (<=1% diag, <=1 deg) / confident-but-wrong | 100 / 99 / 0 | 100 / 99 / 0 | 100 / 99 / 0 |
| median ms (earlier runs) | 1179 | 3054 | 318 |

## Speed (single visible tab, same session, same case lists; app-fixed0 = copy of the app before this work)
| path | before | after |
|---|---|---|
| CUFS end-to-end, 24 cases, estimate ms median / p90 | 1544 / 1608 | 1528 / 2238 |
| FS2K, 12 pairs (two matches), ms median / p90 | 2514 / 3429 | 2401 / 3496 |
| retake, 30 cases, ms median | 312 | 322 |
No measurable speed-up: face detection (about 0.75-1.4 s per image on the CPU backend) dominates, there was no duplicated detector pass to remove (a retry at 416 px runs only when the first pass finds nothing). Changes made: round/silhouette analysis only on demand, the structural matcher runs concurrently in its worker (and is never recomputed for a retake). The earlier 15-22 s per FS2K pair and 3.1 s retake were measurement artefacts of a hidden/throttled pane and concurrent tabs; the 9 s CUFS medians above also came from that condition (tuned run median 1.6 s with the pane visible).

## Not done / caveats
CUFSF was not re-run (the detector is unchanged; lazy shape analysis does not touch detection). Thresholds were fitted on 190 CUFS cases and 120 FS2K pairs; the held-out half is small (CUFS 79+27, FS2K 44). In-app UI checks are listed in the final report.

