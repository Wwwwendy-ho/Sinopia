﻿/* Shared by bench.js (console) and report.html: turns per-case records into summary rows.
   To add a suite: add a function to Summ.suites[<name>] returning {title, groups:[{name, rows:[[label,value],...]}]}. */
(() => {
  'use strict';
  const q = (arr, p) => {
    const a = arr.filter(Number.isFinite).sort((x, y) => x - y);
    if (!a.length) return null;
    const i = (a.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i);
    return a[lo] + (a[hi] - a[lo]) * (i - lo);
  };
  const med = a => q(a, 0.5), p90 = a => q(a, 0.9);
  const pct = (n, d) => (d ? (100 * n / d) : null);
  const f = (v, d = 3) => (v == null || !Number.isFinite(v) ? '–' : v.toFixed(d));
  const fp = v => (v == null || !Number.isFinite(v) ? '–' : v.toFixed(1) + '%');
  const mp = (a, d = 3, suffix = '') => `${f(med(a), d)}${suffix} / ${f(p90(a), d)}${suffix}`;
  const applied = c => c.outcome === 'confident' || c.outcome === 'approximate';
  const outcomes = cs => {
    const n = cs.length, c = k => cs.filter(x => x.outcome === k).length;
    return [
      ['cases (n)', n],
      ['confident (auto-applied)', fp(pct(c('confident'), n))],
      ['approximate (applied with warning)', fp(pct(c('approximate'), n))],
      ['offered only (fixed app: panel with Apply, nothing moved)', fp(pct(c('offered'), n))],
      ['declined (nothing moved)', fp(pct(c('declined'), n))],
      ['error / no result', fp(pct(cs.filter(x => !['confident', 'approximate', 'offered', 'declined'].includes(x.outcome)).length, n))],
    ];
  };
  const timing = cs => ['time per case ms, median / p90', `${f(med(cs.map(c => c.ms)), 0)} / ${f(p90(cs.map(c => c.ms)), 0)}`];

  const suites = {};

  suites.cufs = cs => {
    const groups = [];
    const mk = (name, list) => {
      if (!list.length) return;
      const ap = list.filter(applied), m = x => ap.map(c => c.m && c.m[x]);
      const rows = outcomes(list);
      const ok = (t) => pct(list.filter(c => applied(c) && c.m.nme35 <= t).length, list.length);
      rows.push(['success: applied and NME<=0.10', fp(ok(0.10))], ['success: applied and NME<=0.15 (headline)', fp(ok(0.15))], ['success: applied and NME<=0.25', fp(ok(0.25))]);
      rows.push(['offered and correct (NME<=0.15), share of all cases', fp(pct(list.filter(c => c.outcome === 'offered' && c.m && c.m.nme35 <= 0.15).length, list.length))], ['offered but wrong (NME>0.25)', fp(pct(list.filter(c => c.outcome === 'offered' && c.m && c.m.nme35 > 0.25).length, list.length))], ['usable (applied or offered) and NME<=0.15', fp(pct(list.filter(c => (applied(c) || c.outcome === 'offered') && c.m && c.m.nme35 <= 0.15).length, list.length))]);
      rows.push(['confident but wrong (NME>0.25)', fp(pct(list.filter(c => c.outcome === 'confident' && c.m.nme35 > 0.25).length, list.length))]);
      rows.push(['NME35 median / p90 (applied cases)', mp(m('nme35'))], ['NME core-8 median / p90 (applied)', mp(m('nmeCore'))]);
      rows.push(['|rotation error| deg vs GT similarity, median / p90', mp(ap.map(c => Math.abs(c.m.rotErrDeg)), 2)]);
      rows.push(['|scale error| % vs GT, median / p90', mp(ap.map(c => Math.abs(c.m.scaleErrPct)), 2)]);
      if (list[0].params.tiltDeg === 0) {
        rows.push(['unwanted tilt: |applied rotation|>2 deg (share of applied)', fp(pct(ap.filter(c => Math.abs(c.m.appliedRotDeg) > 2).length, ap.length))]);
        rows.push(['unwanted tilt: |rotation error vs GT|>2 deg (share of applied)', fp(pct(ap.filter(c => Math.abs(c.m.rotErrDeg) > 2).length, ap.length))]);
      }
      rows.push(['floor: GT similarity-fit NME35 median / p90', mp(list.map(c => c.gt && c.gt.nmeSim))]);
      rows.push(['floor: GT scale+translation-fit NME35 median / p90', mp(list.map(c => c.gt && c.gt.nmeST))]);
      rows.push(timing(list));
      groups.push({ name, rows });
    };
    mk('rotation 0 (known scale + translation)', cs.filter(c => c.params.tiltDeg === 0));
    mk('camera tilt +-2..8 deg', cs.filter(c => c.params.tiltDeg !== 0));
    return { title: 'CUFS known-transform (sketch -> photo, end-to-end through app.loadInto)', groups };
  };

  suites.fs2k = cs => {
    const groups = [];
    const mk = (name, list) => {
      if (!list.length) return;
      const valid = list.filter(c => c.consistency);
      const rows = [['pairs (n)', list.length],
        ['untransformed pair: confident / approximate / offered / declined %', [0, 1, 2, 3].map(i => fp(pct(list.filter(c => c.o0 === ['confident', 'approximate', 'offered', 'declined'][i]).length, list.length))).join(' / ')],
        ['transformed sketch: confident / approximate / offered / declined %', [0, 1, 2, 3].map(i => fp(pct(list.filter(c => c.o1 === ['confident', 'approximate', 'offered', 'declined'][i]).length, list.length))).join(' / ')],
        ['both applied (consistency measurable)', fp(pct(valid.length, list.length))]];
      const tol = (c) => c.consistency.posPct <= 1 && Math.abs(c.consistency.rotDeg) <= 1;
      rows.push(['consistent within 1% diagonal and 1 deg (of all pairs)', fp(pct(valid.filter(tol).length, list.length))]);
      rows.push(['consistency position error % of diagonal, median / p90', mp(valid.map(c => c.consistency.posPct), 2)]);
      rows.push(['consistency rotation error deg, median / p90 (abs)', mp(valid.map(c => Math.abs(c.consistency.rotDeg)), 2)]);
      rows.push(['consistency scale error %, median / p90 (abs)', mp(valid.map(c => Math.abs(c.consistency.scalePct)), 2)]);
      const abs = list.filter(c => c.abs0 != null);
      if (abs.length) rows.push(['untransformed pair vs pixel-aligned assumption: error % diagonal, median / p90 (n=' + abs.length + ')', mp(abs.map(c => c.abs0.posPct), 2)],
        ['  ...share within 2% diagonal and 2 deg', fp(pct(abs.filter(c => c.abs0.posPct <= 2 && Math.abs(c.abs0.rotDeg) <= 2).length, abs.length))]);
      rows.push(['unwanted tilt on untransformed pair: |theta|>2 deg (share of applied)', fp(pct(list.filter(c => applied({ outcome: c.o0 }) && Math.abs(c.m0.th * 180 / Math.PI) > 2).length, list.filter(c => applied({ outcome: c.o0 })).length))]);
      rows.push(['time per pair ms (two matches), median / p90', `${f(med(list.map(c => c.ms)), 0)} / ${f(p90(list.map(c => c.ms)), 0)}`]);
      groups.push({ name, rows });
    };
    mk('all styles', cs);
    mk('all styles, rotation-0 pairs only', cs.filter(c => c.params.tiltDeg === 0));
    mk('all styles, tilted (+-2..8 deg) only', cs.filter(c => c.params.tiltDeg !== 0));
    for (const st of [0, 1, 2]) mk('style ' + st + ' (' + ['pencil-like sketch1', 'sketch2 (png)', 'sketch3'][st] + ')', cs.filter(c => c.style === st));
    return { title: 'FS2K self-consistency (known transform composed with transform recovered for the untransformed pair)', groups };
  };

  suites.cufsf = cs => {
    const det = cs.filter(c => c.nFaces > 0);
    const dom = cs.filter(c => c.dominant);
    const good = det.filter(c => c.nme3 != null);
    const rows = [['sketches (n)', cs.length], ['detection rate (>=1 face passes app sanity filter)', fp(pct(det.length, cs.length))],
      ['dominant face (what subject alignment uses)', fp(pct(dom.length, cs.length))],
      ['largest face located on the true face (within 1 IOD of eye mid)', fp(pct(det.filter(c => c.onFace).length, cs.length))],
      ['NME eyes+mouth (3 pts), on-face detections, median / p90', mp(det.filter(c => c.onFace).map(c => c.nme3))],
      ['NME eye centres only, median / p90', mp(det.filter(c => c.onFace).map(c => c.nmeEyes))],
      ['NME mouth centre only, median / p90', mp(det.filter(c => c.onFace).map(c => c.nmeMouth))],
      ['|roll error| deg (eye line vs truth), median / p90', mp(det.filter(c => c.onFace).map(c => Math.abs(c.rollErrDeg)), 2)],
      ['detections with NME3 <= 0.10 (share of all sketches)', fp(pct(good.filter(c => c.onFace && c.nme3 <= 0.1).length, cs.length))],
      ['detections with NME3 <= 0.25 (share of all sketches)', fp(pct(good.filter(c => c.onFace && c.nme3 <= 0.25).length, cs.length))],
      ['multiple faces reported', fp(pct(cs.filter(c => c.nFaces > 1).length, cs.length))],
      ['time per sketch ms, median / p90', `${f(med(cs.map(c => c.ms)), 0)} / ${f(p90(cs.map(c => c.ms)), 0)}`]];
    return { title: 'CUFSF detector check (app face-landmark detector on artist sketches)', groups: [{ name: 'CUFSF original sketches', rows }] };
  };

  suites['cufs-det'] = cs => {
    const groups = [];
    for (const kind of ['photo', 'sketch']) {
      const l = cs.filter(c => c.kind === kind); if (!l.length) continue;
      const det = l.filter(c => c.nFaces > 0), on = det.filter(c => c.onFace);
      groups.push({ name: 'CUFS ' + kind + 's', rows: [['n', l.length], ['detection rate', fp(pct(det.length, l.length))], ['on the true face', fp(pct(on.length, l.length))],
        ['NME3 median / p90', mp(on.map(c => c.nme3))], ['NME eyes median / p90', mp(on.map(c => c.nmeEyes))], ['NME mouth median / p90', mp(on.map(c => c.nmeMouth))], ['time ms median / p90', `${f(med(l.map(c => c.ms)), 0)} / ${f(p90(l.map(c => c.ms)), 0)}`]] });
    }
    return { title: 'CUFS detector check (photos vs sketches, 3 landmarks from the inferred named points)', groups };
  };

  suites.retake = cs => {
    const groups = [];
    const mk = (name, list) => {
      if (!list.length) return;
      const ap = list.filter(c => c.outcome === 'confident');
      const rows = outcomes(list);
      rows.push(['(retake path applies confident matches only; approximate/declined leave the new photo where the old one was)', '']);
      rows.push(['correct: confident and error <=1% diagonal, <=1 deg', fp(pct(ap.filter(c => c.m.posPct <= 1 && Math.abs(c.m.rotDeg) <= 1).length, list.length))]);
      rows.push(['confident but wrong (>3% diagonal)', fp(pct(ap.filter(c => c.m.posPct > 3).length, list.length))]);
      rows.push(['position error % diagonal, median / p90 (confident)', mp(ap.map(c => c.m.posPct), 2)]);
      rows.push(['|rotation error| deg, median / p90', mp(ap.map(c => Math.abs(c.m.rotDeg)), 2)]);
      rows.push(['|scale error| %, median / p90', mp(ap.map(c => Math.abs(c.m.scalePct)), 2)]);
      rows.push(timing(list));
      groups.push({ name, rows });
    };
    mk('all', cs);
    for (const src of ['cufsf', 'cufs', 'fs2k']) mk('source: ' + src, cs.filter(c => c.source === src));
    return { title: 'Retake (sketch vs the same sketch re-photographed: rotation +-3, scale 0.9-1.1, blur, brightness; direct Aligner call with preferStructure as the app does)', groups };
  };

  suites.poparts = cs => {
    const c = cs[0] || {};
    return { title: 'PoPArt (placeholder: no body alignment exists yet)', groups: [{ name: 'dataset stats', rows: Object.entries(c.stats || {}).map(([k, v]) => [k, typeof v === 'number' ? f(v, Number.isInteger(v) ? 0 : 2) : String(v)]) }] };
  };

  window.Summ = { suites, q, med, p90, summarize: (suite, cases) => (suites[suite] ? suites[suite](cases) : null) };
})();


