// Stand-in faces for the Proportions mock-ups. Everything is in "measure units": the eye midpoint is (0, 0)
// and the eye line to chin distance is 100. Both faces are already pinned at the eyes and sized eyes-to-chin,
// so the difference between REF and DRW is exactly what the check reports.
const REF = {
  browLo: [-52, -12], browL: [-33, -18], browLi: [-13, -14], browRi: [13, -14], browR: [33, -18], browRo: [52, -12],
  eyeLo: [-46, 1], eyeL: [-32, 0], eyeLi: [-19, 1.5], eyeRi: [19, 1.5], eyeR: [32, 0], eyeRo: [46, 1],
  bridge: [0, 10], noseTip: [0, 40], alaL: [-15, 42], alaR: [15, 42], noseBase: [0, 46],
  mouthL: [-24, 66], lipTop: [0, 61], mouthC: [0, 66], lipBot: [0, 73], mouthR: [24, 66],
  cheekL: [-68, 14], jawL: [-61, 58], jawLL: [-43, 87], chin: [0, 100], jawRR: [43, 87], jawR: [61, 58], cheekR: [68, 14],
  templeL: [-70, -32], templeR: [70, -32], top: [0, -112]
};
const DRW = {
  browLo: [-50, -14], browL: [-31, -20], browLi: [-11, -16], browRi: [11, -12], browR: [31, -16], browRo: [50, -10],
  eyeLo: [-43, -1], eyeL: [-30, -2], eyeLi: [-17, -0.5], eyeRi: [17, 3.5], eyeR: [30, 2], eyeRo: [43, 3],
  bridge: [0, 11], noseTip: [0, 48], alaL: [-14.5, 50], alaR: [14.5, 50], noseBase: [0, 54],
  mouthL: [-24, 72], lipTop: [0, 67], mouthC: [0, 72], lipBot: [0, 79], mouthR: [24, 72],
  cheekL: [-67, 14], jawL: [-57.5, 58], jawLL: [-41, 88], chin: [0, 100], jawRR: [41, 88], jawR: [57.5, 58], cheekR: [67, 14],
  templeL: [-70, -32], templeR: [70, -32], top: [0, -112]
};
const NAMES = {
  browLo: 'Left brow, outer end', browL: 'Left brow', browLi: 'Left brow, inner end', browRi: 'Right brow, inner end', browR: 'Right brow', browRo: 'Right brow, outer end',
  eyeLo: 'Left eye, outer corner', eyeL: 'Left eye', eyeLi: 'Left eye, inner corner', eyeRi: 'Right eye, inner corner', eyeR: 'Right eye', eyeRo: 'Right eye, outer corner',
  bridge: 'Bridge of the nose', noseTip: 'Tip of the nose', alaL: 'Left nostril wing', alaR: 'Right nostril wing', noseBase: 'Base of the nose',
  mouthL: 'Left mouth corner', lipTop: 'Top of the upper lip', mouthC: 'Centre of the mouth', lipBot: 'Bottom of the lower lip', mouthR: 'Right mouth corner',
  cheekL: 'Left cheekbone', jawL: 'Left jaw corner', jawLL: 'Left jaw line', chin: 'Chin', jawRR: 'Right jaw line', jawR: 'Right jaw corner', cheekR: 'Right cheekbone'
};
// the points the check shows (temples and head top are only TPS anchors)
const SHOWN = Object.keys(NAMES);

/* ---------- thin-plate spline from REF to DRW (the diagnostic distortion map) ---------- */
function tps(src, dst) {
  const n = src.length, U = r2 => r2 < 1e-9 ? 0 : r2 * Math.log(r2), N = n + 3;
  const A = Array.from({ length: N }, () => new Float64Array(N + 2));
  for (let i = 0; i < n; i++) {
    for (let k = 0; k < n; k++) { const dx = src[i][0] - src[k][0], dy = src[i][1] - src[k][1]; A[i][k] = U(dx * dx + dy * dy); }
    A[i][i] += 2;                                       // a little regularisation: smooth, not exact
    A[i][n] = 1; A[i][n + 1] = src[i][0]; A[i][n + 2] = src[i][1];
    A[n][i] = 1; A[n + 1][i] = src[i][0]; A[n + 2][i] = src[i][1];
    A[i][N] = dst[i][0]; A[i][N + 1] = dst[i][1];
  }
  for (let c = 0; c < N; c++) {                          // Gauss-Jordan with partial pivoting
    let p = c; for (let r = c + 1; r < N; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    [A[c], A[p]] = [A[p], A[c]];
    const d = A[c][c]; for (let k = c; k < N + 2; k++) A[c][k] /= d;
    for (let r = 0; r < N; r++) if (r !== c && A[r][c]) { const m = A[r][c]; for (let k = c; k < N + 2; k++) A[r][k] -= m * A[c][k]; }
  }
  const wx = A.map(r => r[N]), wy = A.map(r => r[N + 1]);
  return (x, y) => {
    let X = wx[n] + wx[n + 1] * x + wx[n + 2] * y, Y = wy[n] + wy[n + 1] * x + wy[n + 2] * y;
    for (let i = 0; i < n; i++) { const dx = x - src[i][0], dy = y - src[i][1], u = U(dx * dx + dy * dy); X += wx[i] * u; Y += wy[i] * u; }
    return [X, Y];
  };
}
const KEYS = Object.keys(REF);
const warp = tps(KEYS.map(k => REF[k]), KEYS.map(k => DRW[k]));

/* ---------- shapes shared by both renderings ---------- */
const closed = pts => smooth([...pts, pts[0], pts[1]]).replace(/^M[^C]*/, m => m) + 'Z';
function headOutline(F) {
  return [F.templeL, [-72, -62], [-55, -96], F.top, [55, -96], [72, -62], F.templeR, F.cheekR, F.jawR, F.jawRR, [20, 97], F.chin, [-20, 97], F.jawLL, F.jawL, F.cheekL];
}

/* ---------- the reference: a soft tonal "photograph" ---------- */
function refPhoto(k) {
  const F = REF, S = (d, fillc, extra = '') => `<path d="${d}" fill="${fillc}" ${extra}/>`;
  let s = `<defs>
  <linearGradient id="rp-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b9b0a4"/><stop offset="1" stop-color="#7d7369"/></linearGradient>
  <radialGradient id="rp-skin" cx=".36" cy=".38" r=".75"><stop offset="0" stop-color="#e3c2a6"/><stop offset=".55" stop-color="#c99f80"/><stop offset="1" stop-color="#8d6650"/></radialGradient>
  <linearGradient id="rp-side" x1="0" x2="1"><stop offset=".5" stop-color="#3b2418" stop-opacity="0"/><stop offset=".78" stop-color="#3b2418" stop-opacity=".22"/><stop offset="1" stop-color="#3b2418" stop-opacity=".5"/></linearGradient>
  <linearGradient id="rp-hair" x1="0" y1="0" x2=".3" y2="1"><stop offset="0" stop-color="#4a3326"/><stop offset=".6" stop-color="#2c1e17"/><stop offset="1" stop-color="#1d1410"/></linearGradient>
  <linearGradient id="rp-neck" x1="0" x2="1"><stop offset="0" stop-color="#b38668"/><stop offset=".6" stop-color="#9a6f55"/><stop offset="1" stop-color="#6b4a39"/></linearGradient>
  <linearGradient id="rp-cloth" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5d6b6f"/><stop offset="1" stop-color="#2f383b"/></linearGradient>
  <filter id="rp-b1" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.1"/></filter>
  <filter id="rp-b3" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
  <filter id="rp-b6" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6"/></filter>
  <clipPath id="rp-clip"><rect x="-110" y="-150" width="220" height="320"/></clipPath>
  <clipPath id="rp-face"><path d="${closed(headOutline(F))}"/></clipPath>
</defs><g clip-path="url(#rp-clip)">`;
  s += `<rect x="-110" y="-150" width="220" height="320" fill="url(#rp-bg)"/>`;
  s += `<ellipse cx="-40" cy="-90" rx="90" ry="70" fill="#d8d0c4" opacity=".35" filter="url(#rp-b6)"/>`;
  // hair mass behind
  s += S(closed([[-82, -40], [-86, -100], [-40, -140], [20, -142], [76, -110], [90, -40], [86, 30], [78, 74], [60, 80], [-60, 80], [-82, 60], [-88, 10]]), 'url(#rp-hair)');
  // shoulders and neck
  s += S('M-110 170L-110 150C-96 128 -66 118 -38 112L38 112C66 118 96 128 110 150L110 170Z', 'url(#rp-cloth)');
  s += S('M-36 70C-36 96 -38 112 -44 124C-20 134 20 134 44 124C38 112 36 96 36 70Z', 'url(#rp-neck)');
  s += `<ellipse cx="4" cy="108" rx="40" ry="12" fill="#3b2418" opacity=".42" filter="url(#rp-b3)"/>`;
  s += S('M-44 124C-20 134 20 134 44 124L50 128C20 140 -20 140 -50 128Z', '#20282a', 'opacity=".5"');
  // ears
  s += S(closed([[-68, 0], [-79, -6], [-82, 10], [-77, 30], [-66, 38]]), '#b88c6e') + S(closed([[68, 0], [79, -6], [82, 10], [77, 30], [66, 38]]), '#8a624d');
  // face
  s += S(closed(headOutline(F)), 'url(#rp-skin)');
  s += `<g clip-path="url(#rp-face)">`;
  s += `<rect x="-90" y="-130" width="180" height="240" fill="url(#rp-side)"/>`;
  // eye sockets, cheek shadow, nose shadow, under-lip and jaw shadow
  for (const x of [-32, 32]) s += `<ellipse cx="${x}" cy="-3" rx="20" ry="11" fill="#5a3a2a" opacity="${x < 0 ? .28 : .4}" filter="url(#rp-b3)"/>`;
  s += `<path d="M8 12C12 26 16 34 18 42L8 46Z" fill="#4a2e22" opacity=".35" filter="url(#rp-b3)"/>`;
  s += `<ellipse cx="0" cy="49" rx="17" ry="4" fill="#4a2e22" opacity=".45" filter="url(#rp-b3)"/>`;
  s += `<ellipse cx="2" cy="80" rx="12" ry="4" fill="#4a2e22" opacity=".35" filter="url(#rp-b3)"/>`;
  s += `<path d="M52 20C58 40 54 60 42 84L64 70L70 20Z" fill="#3b2418" opacity=".3" filter="url(#rp-b6)"/>`;
  s += `<ellipse cx="-30" cy="28" rx="16" ry="10" fill="#f0d4bc" opacity=".35" filter="url(#rp-b6)"/>`;
  s += `<ellipse cx="-14" cy="-40" rx="26" ry="14" fill="#f3dcc6" opacity=".35" filter="url(#rp-b6)"/>`;
  s += `<ellipse cx="-4" cy="30" rx="3.5" ry="9" fill="#f6e2cf" opacity=".55" filter="url(#rp-b1)"/>`;
  s += `</g>`;
  // hair over the forehead
  s += S(closed([[-72, -30], [-76, -80], [-44, -122], [10, -128], [62, -110], [78, -70], [74, -30], [62, -58], [34, -72], [6, -66], [-24, -70], [-52, -62]]), 'url(#rp-hair)');
  s += `<path d="M-50 -100C-30 -116 10 -120 40 -108" fill="none" stroke="#7a5640" stroke-width="5" opacity=".35" filter="url(#rp-b3)"/>`;
  // brows
  for (const sd of [-1, 1]) {
    const o = F[sd < 0 ? 'browLo' : 'browRo'], m = F[sd < 0 ? 'browL' : 'browR'], i = F[sd < 0 ? 'browLi' : 'browRi'];
    s += `<path d="${smooth([i, [(i[0] + m[0]) / 2, m[1] - 1], m, o])}" fill="none" stroke="#2e1d15" stroke-width="5" stroke-linecap="round" opacity=".75" filter="url(#rp-b1)"/>`;
  }
  // eyes
  for (const sd of [-1, 1]) {
    const c = F[sd < 0 ? 'eyeL' : 'eyeR'], o = F[sd < 0 ? 'eyeLo' : 'eyeRo'], i = F[sd < 0 ? 'eyeLi' : 'eyeRi'];
    const up = smooth([i, [c[0] - sd * 2, c[1] - 5.5], o]), lo = smooth([o, [c[0], c[1] + 4], i]);
    s += `<path d="${up.replace(/^M/, 'M') + lo.replace(/^M[^C]*/, '')}Z" fill="#e9e1d8"/>`;
    s += `<circle cx="${c[0]}" cy="${c[1] - .3}" r="5" fill="#3a2a20"/><circle cx="${c[0]}" cy="${c[1] - .3}" r="2.2" fill="#120c09"/><circle cx="${c[0] - 1.6}" cy="${c[1] - 1.8}" r="1" fill="#fff" opacity=".85"/>`;
    s += `<path d="${up}" fill="none" stroke="#2a1a12" stroke-width="1.6" opacity=".9"/><path d="${smooth([[i[0], i[1] - 3], [c[0] - sd * 2, c[1] - 9], [o[0], o[1] - 4]])}" fill="none" stroke="#5a3a2a" stroke-width="1" opacity=".5" filter="url(#rp-b1)"/>`;
  }
  // nose
  s += `<path d="${smooth([F.alaL, [-9, 47], [-3, 46], F.noseBase])}" fill="none" stroke="#5a3324" stroke-width="1.6" opacity=".6" filter="url(#rp-b1)"/>`;
  s += `<path d="${smooth([F.alaR, [9, 47], [3, 46], F.noseBase])}" fill="none" stroke="#4a2a1e" stroke-width="1.8" opacity=".7" filter="url(#rp-b1)"/>`;
  s += `<ellipse cx="-6" cy="45" rx="3" ry="1.6" fill="#2a160e" opacity=".75"/><ellipse cx="6" cy="45" rx="3" ry="1.6" fill="#2a160e" opacity=".8"/>`;
  s += `<path d="${smooth([[-16, 36], [-17, 42], F.alaL])}" fill="none" stroke="#5a3324" stroke-width="1.4" opacity=".45" filter="url(#rp-b1)"/><path d="${smooth([[16, 36], [17, 42], F.alaR])}" fill="none" stroke="#4a2a1e" stroke-width="1.6" opacity=".6" filter="url(#rp-b1)"/>`;
  // mouth
  s += `<path d="${smooth([F.mouthL, [-12, 61], [-3, 62], [0, 63], [3, 62], [12, 61], F.mouthR])} ${smooth([F.mouthR, [12, 67.5], [0, 68], [-12, 67.5], F.mouthL]).replace(/^M[^C]*/, '')}Z" fill="#8e4a3e"/>`;
  s += `<path d="${smooth([F.mouthL, [-12, 67], [0, 68], [12, 67], F.mouthR])} ${smooth([F.mouthR, [14, 71], [0, 74], [-14, 71], F.mouthL]).replace(/^M[^C]*/, '')}Z" fill="#a8604f"/>`;
  s += `<path d="${smooth([F.mouthL, [-12, 66.5], [0, 67.5], [12, 66.5], F.mouthR])}" fill="none" stroke="#3a1a14" stroke-width="1.4" opacity=".85"/>`;
  s += `<ellipse cx="-4" cy="70.5" rx="6" ry="1.4" fill="#e6a898" opacity=".45" filter="url(#rp-b1)"/>`;
  s += `</g>`;
  return s;
}

/* ---------- the drawing: a pencil study on paper, with the deliberate errors in DRW ---------- */
function hatch(pts, ang, sp, jit = .5) {
  const a = ang * Math.PI / 180, nx = -Math.sin(a), ny = Math.cos(a), pr = pts.map(p => p[0] * nx + p[1] * ny);
  const lo = Math.min(...pr), hi = Math.max(...pr); let d = '';
  for (let t = lo + sp * (.45 + rnd() * .3); t < hi; t += sp * (1 + j(.18))) {
    const hit = [];
    for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length], tp = pr[i], tq = pr[(i + 1) % pts.length]; if ((tp - t) * (tq - t) < 0) { const u = (t - tp) / (tq - tp); hit.push([p[0] + u * (q[0] - p[0]), p[1] + u * (q[1] - p[1])]); } }
    if (hit.length >= 2) { const [A, B] = hit, L = Math.hypot(B[0] - A[0], B[1] - A[1]) || 1, ux = (B[0] - A[0]) / L, uy = (B[1] - A[1]) / L, e1 = j(jit), e2 = j(jit); d += `M${f(A[0] + ux * e1)} ${f(A[1] + uy * e1)}L${f(B[0] + ux * e2)} ${f(B[1] + uy * e2)}`; }
  }
  return d;
}
function pencilStudy(k, paper = '#f1ece2', paperOp = 1) {
  seed(5);
  const F = DRW, px = w => f(w / k);
  const P = (d, w = 1, o = .78, c = '#33302d') => `<path d="${d}" fill="none" stroke="${c}" stroke-width="${px(w)}" stroke-opacity="${o}" stroke-linecap="round" stroke-linejoin="round"/>`;
  const jit = (pts, a = .8) => pts.map(p => [p[0] + j(a), p[1] + j(a)]);
  const twice = (pts, w = 1.1, o = .8) => P(smooth(jit(pts, .5)), w, o) + P(smooth(jit(pts, 1.4)), w * .7, o * .45);
  let s = `<defs><clipPath id="dp-clip"><rect x="-118" y="-156" width="226" height="330"/></clipPath>
  <pattern id="dp-tooth" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M2 3l2 1M9 8l1.5-1M5 11l2 .5M12 2l-1 1.5" stroke="#8a7a62" stroke-opacity=".18" stroke-width=".5"/></pattern></defs>`;
  s += `<g clip-path="url(#dp-clip)"><rect x="-118" y="-156" width="226" height="330" fill="${paper}" fill-opacity="${paperOp}"/><rect x="-118" y="-156" width="226" height="330" fill="url(#dp-tooth)"/>`;
  // construction, light
  s += P(ell(0, -40, 74, 74, { wob: .012 }), .8, .22) + P(line(0, -128, 0, 112, { over: 4 }), .7, .22) + P(line(-80, 0, 80, 0), .7, .2) + P(line(-60, 54, 60, 54), .6, .16) + P(line(-50, 72, 50, 72), .6, .14);
  // hair: long flowing strokes
  let hr = '';
  const hairLine = [[-70, -30], [-60, -62], [-30, -72], [6, -66], [36, -72], [64, -58], [72, -30]];
  for (let i = 0; i < 26; i++) {
    const t = i / 25, x0 = -78 + t * 156, top = -128 + Math.abs(t - .45) * 40;
    const end = hairLine[Math.min(6, Math.round(t * 6))];
    hr += smooth([[x0 * .6, top + j(4)], [x0 * .9 + j(3), (top + end[1]) / 2 - 10], [end[0] + j(3), end[1] + j(3)]]);
  }
  for (const sd of [-1, 1]) for (let i = 0; i < 7; i++) hr += smooth([[sd * (70 + i * 2), -60 + i * 4], [sd * (84 + i * 1.5), -10 + i * 6], [sd * (80 + i), 50 + i * 4], [sd * (66 + i * 2), 78 + j(3)]]);
  s += P(hr, .8, .5);
  s += twice([[-74, 0], [-80, -60], [-50, -114], [0, -130], [52, -116], [82, -62], [80, 0]], 1.2, .75);
  // head contour and jaw
  s += twice([F.templeL, F.cheekL, F.jawL, F.jawLL, [-20, 97], F.chin], 1.3, .85) + twice([F.templeR, F.cheekR, F.jawR, F.jawRR, [20, 97], F.chin], 1.3, .85);
  // ears
  s += twice([[-67, 0], [-77, -5], [-80, 10], [-75, 30], [-64, 38]], 1, .7) + twice([[67, 0], [77, -5], [80, 10], [75, 30], [64, 38]], 1, .7);
  // neck and collar
  s += twice([[-34, 74], [-35, 100], [-40, 124]], 1.1, .75) + twice([[34, 74], [35, 100], [40, 124]], 1.1, .75) + twice([[-100, 160], [-70, 128], [-40, 124]], 1, .6) + twice([[100, 160], [70, 128], [40, 124]], 1, .6);
  // brows (short strokes)
  let br = '';
  for (const sd of [-1, 1]) {
    const o = F[sd < 0 ? 'browLo' : 'browRo'], m = F[sd < 0 ? 'browL' : 'browR'], i = F[sd < 0 ? 'browLi' : 'browRi'];
    for (let t = 0; t <= 1; t += .07) { const x = i[0] + (o[0] - i[0]) * t, y = i[1] + (m[1] - i[1]) * Math.sin(t * Math.PI * .8) * 1.1 + (o[1] - i[1]) * t * .3; br += line(x, y + 2, x + sd * 4, y - 2, { over: 0, wob: .2 }); }
  }
  s += P(br, 1.1, .7);
  // eyes
  for (const sd of [-1, 1]) {
    const c = F[sd < 0 ? 'eyeL' : 'eyeR'], o = F[sd < 0 ? 'eyeLo' : 'eyeRo'], i = F[sd < 0 ? 'eyeLi' : 'eyeRi'];
    s += twice([i, [c[0] - sd * 2, c[1] - 5.5], o], 1.4, .9) + P(smooth(jit([o, [c[0], c[1] + 4], i], .3)), .9, .6);
    s += P(smooth(jit([[i[0], i[1] - 3.5], [c[0] - sd * 2, c[1] - 9], [o[0] + sd, o[1] - 4]], .4)), .8, .45);
    s += P(ell(c[0], c[1] - .4, 4.8, 4.8, { wob: .03 }), 1, .8) + `<circle cx="${c[0]}" cy="${c[1] - .4}" r="2" fill="#2b2826" fill-opacity=".85"/>`;
    s += P(hatch([[c[0] - 4.2, c[1] - 3], [c[0] + 4.2, c[1] - 3], [c[0] + 4.2, c[1] + 3], [c[0] - 4.2, c[1] + 3]], 60, 1.2, .3), .6, .55);
  }
  // nose
  s += twice([[-6, 14], [-9, 30], [-15, 42], F.alaL], 1, .55) + twice([F.alaL, [-10, 54.5], [-4, 53], F.noseBase], 1.2, .8) + twice([F.alaR, [10, 54.5], [4, 53], F.noseBase], 1.2, .8);
  s += P(ell(-6, 52.5, 2.8, 1.4, { wob: .05 }) + ell(6, 52.5, 2.8, 1.4, { wob: .05 }), 1, .8) + twice([[-5, 46], [0, 48.5], [5, 46]], .9, .5);
  // mouth
  s += twice([F.mouthL, [-12, 72.5], [0, 73.5], [12, 72.5], F.mouthR], 1.4, .9) + P(smooth(jit([F.mouthL, [-12, 67], [-3, 68], [0, 69], [3, 68], [12, 67], F.mouthR], .3)), .9, .6) + P(smooth(jit([[-14, 77], [0, 79.5], [14, 77]], .3)), .8, .45);
  // shading on the shadow side and under the features
  s += P(hatch([[44, -20], [64, -26], [64, 40], [52, 70], [36, 84]], 62, 2.6, .8), .7, .38);
  s += P(hatch([[6, 14], [14, 18], [17, 46], [8, 50]], 58, 2, .5), .6, .4);
  s += P(hatch([[-16, 56.5], [16, 56.5], [12, 60], [-12, 60]], 20, 1.6, .4), .6, .4);
  s += P(hatch([[-12, 82], [12, 82], [8, 86], [-8, 86]], 20, 1.8, .4), .6, .38);
  s += P(hatch([[-30, 100], [30, 100], [36, 116], [-36, 116]], 50, 2.4, .6), .65, .4);
  for (const sd of [-1, 1]) s += P(hatch([[sd * 20, -9], [sd * 44, -10], [sd * 46, -5], [sd * 18, -4]], 60, 2.2, .4), .6, .3);
  s += `</g>`;
  return s;
}
