# Proportions, phase 3: body, hands, outline (design and technical spec)

Extends `../SPEC.md` and `../DECISIONS.md` (phase 1, approved). Where this document is silent, phase 1 holds: one check layer (key `K`), report column on desktop / bottom sheet on phones, vermilion = major, sinopia = minor and reference, graphite = drawing, arrows from the drawing point to where the reference puts it, brackets only for the selected item, tolerance presets Strict / Usual / Relaxed without a single % number, left and right are the person's own, whole-sentence templates in en, zh-Hans, zh-Hant, es, fr.

## Snapshots

| File | Shows |
| --- | --- |
| `p1-desktop-figure-overlay.png` | Desktop 1280x800, Overlay (Blend 40%). Full-figure gesture drawing over a reference figure. Pose points and skeleton (reference dashed, drawing solid), a heads ruler (7.1 vs 7.5), the size-by measure (head height), the pin at the pit of the neck, the balance line, a shoulder-tilt angle arc, arrows at the knees, feet and left wrist, a short outline band at the left hip, and the selected item's leg bracket ("0.4 heads too short"). The report column shows Checking / Pin / Size by, section tabs (All, Body, Hands, Outline, Face greyed), the ranked top list mixing sections, "Heads tall", the close-enough line and the foreshortening and small-face notes. |
| `p2-desktop-hand-side.png` | Desktop, Side layout, hand study. Drawing pane: 21 points, finger axes, knuckle line (reference dashed, drawing solid), thumb and little-finger arrows, and the selected item's index-finger bracket ("8% too short"). Reference pane: shaded stand-in hand, points, the selected finger highlighted, palm-length measure, pin at the wrist. Report: Hand study (auto), Pin: Wrist, Size by: Palm length, five items, a finger-lengths mini chart. |
| `p3-phone-outline-sheet.png` | Phone 375x812, Overlay, half figure with the outline band: reference outline as a thin sinopia line, "drawing outside" band (sinopia, hatched) at the left shoulder with a distance tick and "6% out" chip, "drawing inside" bands (slate, hatched) at the right waist and the top of the head. Bottom sheet: mode chip "Half figure", segmented section filter (All 4, Body 1, Outline 3), three outline items, legend and unit note. |

The stand-in figure, hand and half figure are drawn as SVG (no dataset images). Generator: `gen/mock3.html?s=1|2|3` (uses `../gen/lib.js` and `gen/common.js`, which is the phase-1 helper code copied from `../gen/mock.html`; `gen/geo.js` holds the figure, hand and contour geometry, `gen/snaps.js` the three layouts and `save()`). Serve `proportion-design/` with `../gen/serve-save.ps1 -root <proportion-design> -port 8953 -out <phase3>` and call `save('1','p1-desktop-figure-overlay.png')`, and so on.

---

## 1. What the check covers now

| Mode (the "Checking" picker) | When chosen automatically | Sections it fills | Models it needs |
| --- | --- | --- | --- |
| **Face close-up** | A face box at least 22% of the image height in both images | Face (phase 1); Outline on request | Face (already shipped) |
| **Half figure** | A pose is found in both images, shoulders and hips visible (visibility at least 0.5), knees or ankles not visible in either image | Body (upper-body items), Hands (when wrists are visible and big enough), Face (only when the head is big enough), Outline | Pose; Hand (later, lazily) |
| **Full figure** | As half figure, plus both ankles visible in both images | Body (all items), Hands, Face (if big enough), Outline | Pose; Hand (later, lazily) |
| **Hand study** | No pose, or a pose without shoulders; the Hand Landmarker finds a hand whose box is at least 25% of the image's shorter side in both images | Hands, Outline | Hand |
| **Other** | None of the above (a still life, an animal, a landscape, a building) | Outline, Free points (phase 1 "Place points myself") | none (segmenter optional) |

* **Auto first, then override.** The picker reads "Full figure (auto)" while auto is in charge. Picking a mode makes it "Full figure" (no "auto") and it is stored per pair (in the view, like the edited points). "Auto" is the first menu entry and puts it back.
* **The two images disagree** (the reference is a full figure, the drawing stops at the knees): use the less inclusive mode (Half figure) and add a note: "The drawing shows less of the figure, so only the upper body is checked."
* **Order of detection, cheapest first** (keeps downloads lazy): 1) the Face Landmarker (loaded for Proportions already); 2) if the face is not large enough in both images, the Pose Landmarker; 3) if no pose with shoulders, the Hand Landmarker on the whole image; 4) otherwise Other. Hands inside figures are found after the body report is on screen (the Hands tab shows "Finding hands…").
* **Several figures:** the largest pose in each image (bounding box area), with the line "Using the largest figure in each picture." (Later: tap a figure to choose.)
* **Face inside a figure:** run on a head crop (from the pose's ears, eyes and nose, padded to 1.6x) only when the head is at least 120 px tall in the source image of both pictures; otherwise the Face tab is greyed with the reason in its bubble ("The face is too small here. Crop to the head to check its features.") and the same as a note in the report.

## 2. Pin and Size by, extended

| Mode | Size by (default first) | Pin (default first) |
| --- | --- | --- |
| Face | Robust auto · Head height · Eye line to chin · Eye spacing · Custom (phase 1) | Auto (best fit) · Between the eyes · Nose · Chin · Mouth · Custom spot |
| Half / Full figure | **Robust auto** (L1 fit over shoulders, hips and the head centre) · Head height · Torso (pit of the neck to hip centre) · Shoulder width · Full height (crown to the lower foot; full figure only) · Custom | **Auto (best fit)** · Pit of the neck · Hip centre · Standing foot · Custom spot |
| Hand study | **Robust auto** (palm: wrist and the four knuckles) · Palm length (wrist to middle knuckle) · Hand length (wrist to middle fingertip) · Custom | **Auto (best fit)** · Wrist · Middle knuckle · Custom spot |
| Other | Robust auto (the existing image alignment) · Custom | Auto · Custom spot |

* **Units do not depend on Size by.** In figure modes every figure-scale length and placement is in **heads** (the reference's head height), segment lengths are **% of the reference segment**, angles in **degrees**. Hands use **% of the reference palm length**. The outline uses **% of the reference subject's height** (its mask or contour bounding box). The head unit is shown as the heads ruler on the reference side (snapshot 1).
* **Locked items:** as in phase 1, what defines the measure cannot be flagged (Size by Head height: the head is never "too big"; the hover note says so).
* **Tilt:** never rotated. The whole-figure lean (pit of the neck to hip centre against vertical) is one item ("Figure leans 4° more to the left than the reference"); everything else is measured in a frame with that lean removed. "Match tilt" (the phase-1 checkbox, renamed per mode: Match head tilt / Match figure lean / Match hand angle) removes it on screen.
* **Undo slip notes (new):** Pinned at the pit of the neck · Pinned at the hip centre · Pinned at the standing foot · Pinned at the wrist · Sized by head height · Sized by torso · Sized by palm length · Checking a full figure · Checking a hand study (and so on).

## 3. Body (A)

### 3.1 Detector

* **MediaPipe Pose Landmarker**, 33 landmarks per pose (image x, y, a relative z and a visibility; plus `worldLandmarks` in metres, used only for the foreshortening test). Same `@mediapipe/tasks-vision 0.10.21` bundle and wasm as the face; `runningMode: 'IMAGE'`, CPU delegate, `numPoses: 3`, `minPoseDetectionConfidence 0.3`, `outputSegmentationMasks: true` (the person mask is reused by the outline, so a figure needs no separate segmenter).
* **Model: `pose_landmarker_full.task` (9,398,198 bytes)** by default. `pose_landmarker_lite.task` (5,777,746 bytes) is the fallback when the full model fails to load or `navigator.deviceMemory` is below 4. `pose_landmarker_heavy.task` (30,664,242 bytes) is **not shipped**: it is three times the download and over GitHub's 25 MB web-upload limit; the bench measures whether it would earn its place (task B1).
* Input: the oriented image downsized to at most 1024 px on its long side (pose works at 256x256 internally; the detector sees the whole image, so a larger image only helps the crop). If no pose is found, retry once on the 1.4x-padded subject box from the existing auto-align (helps small figures in big sheets).
* A landmark is used only when its visibility is at least 0.5 in **both** images; items built on it are dropped and listed in the note "Not checked: left foot (hidden)".

### 3.2 Named points and derived points

Pose indices (MediaPipe): nose 0, eyes 2/5, ears 7/8, mouth 9/10, shoulders 11/12, elbows 13/14, wrists 15/16, pinky 17/18, index 19/20, thumb 21/22, hips 23/24, knees 25/26, ankles 27/28, heels 29/30, foot index 31/32. Odd = the person's left. Derived:

| Point | Definition |
| --- | --- |
| Pit of the neck | Shoulder midpoint, raised by 0.12 x shoulder width toward the head (pose shoulders sit on the joints, the pit is higher). Calibrated on PoPArt (task B4) |
| Hip centre | Hip midpoint |
| Crown (top of head) | Topmost point of the pose segmentation mask inside the head column (between the ears, above the eyes). Fallback without a mask: eye midpoint minus 1.15 x (eye midpoint to mouth midpoint) along the head axis, to be calibrated |
| Chin | Face Landmarker chin on the head crop when the head is at least 60 px; otherwise mouth midpoint plus 0.55 x (eye-to-mouth) along the head axis |
| Head height (the unit) | Crown to chin |
| Standing foot | In the reference: the foot whose ankle is lowest and nearest the balance line; both feet when the ankles are within 0.15 heads in height and both are under the body |
| Gesture line | A quadratic curve fitted (least squares) through the crown, pit of the neck, hip centre and the standing ankle |

### 3.3 Alignment

Robust auto: an L1 (IRLS) similarity without rotation over the shoulders, hips, pit of the neck and crown (the most stable points), so a mis-drawn arm or leg does not move the fit and can be flagged. Pins as in phase 1 (pinned pair coincides; scale refitted about the pin). The lean is measured separately (3.2).

### 3.4 Items

All values are drawing minus reference after alignment, then `(raw - bias) / gain` per item (bias and gain from the planted suite, as for faces). Usual tolerances below are starting points; the sweep in task B4 sets the final ones (the same rule as faces: maximise detection at 6% or more with control false alarms and unplanted false alarms both at most 5%, tuned on one half of the artworks and reported on the other half).

| Item | Measure | Unit | Usual (start) | Templates (en) |
| --- | --- | --- | ---: | --- |
| Height | crown to the lower heel, full figure | heads | 0.2 heads | Figure {h} heads too short · Figure {h} heads too tall (also the info line "Heads tall: 7.1 (reference 7.5)") |
| Legs | hip to ankle, each leg, and both together when they agree | heads | 0.2 heads | Legs {h} heads too short / too long · Left leg {h} heads too short / too long · Right leg … |
| Torso | pit of the neck to hip centre | % | 5% | Torso {n}% too long / too short |
| Shoulder width | shoulder to shoulder | % | 6% | Shoulders {n}% too wide / too narrow |
| Hip width | hip to hip | % | 7% | Hips {n}% too wide / too narrow |
| Segments | upper arm, forearm, thigh, shin, each side | % of that reference segment | 7% | Left forearm {n}% too long / too short (one key per segment, side and direction: 16 keys) |
| Arm reach | wrist height relative to the hip line | heads | 0.2 heads | Left hand hangs {h} heads too low / too high |
| Shoulder tilt | angle of the shoulder line; difference | degrees | 3° | Shoulders tilted {d}° more than the reference · … {d}° less than the reference · Shoulders tilt the other way |
| Hip tilt | as above for the hips | degrees | 3° | Hips tilted {d}° more / less than the reference · Hips tilt the other way |
| Shoulders against hips | the contrapposto: difference of (shoulder angle minus hip angle) | degrees | 4° | Shoulders and hips {d}° less opposed than the reference · {d}° more opposed |
| Limb angles | each segment's direction | degrees | 6° | Left forearm turned {d}° clockwise from the reference · … anticlockwise … |
| Gesture line | lean of the fitted curve's chord, and its bow (sagitta / chord) | degrees, % | 4°, 3% | Gesture line leans {d}° less than the reference · leans {d}° more · Gesture line {n}% straighter than the reference · {n}% more curved |
| Lean | pit of the neck to hip centre against vertical | degrees | 3° | Figure leans {d}° more to the left / to the right than the reference |
| Balance | horizontal offset of the standing foot (centre of heel and toe) from the plumb line through the pit of the neck, drawing minus reference | heads | 0.15 heads | Standing foot {h} heads too far left of the balance line · … too far right … · Warning (not ranked by size, shown first): The balance line falls outside both feet, so the figure looks as if it would tip. |
| Joint placement | residual offset of any joint not explained by an item above | heads | 0.2 heads | Left elbow {h} heads too high / too low / too far left / too far right (per joint) |

* `{h}` is one decimal (0.4); `{n}` and `{d}` are whole numbers, with phase-1 rounding rules ("never under the tolerance").
* **Knock-on grouping (extends phase 1):** knees and ankles moved by a leg-length item are sub-lines ("The knees sit 0.2 heads high with it"); a hand moved by a forearm-length item is a sub-line; an outline region that lies along a flagged segment becomes a sub-line of it ("The outline follows it").
* **Foreshortening caveat.** For each segment, foreshortening = 2D length / 3D length from `worldLandmarks`, in each image. Below 0.8 in either image the item is marked *approx.*, ranks after all exact items, and the report adds one note naming it ("Right thigh is foreshortened in the reference: its length is approximate."). The comparison stays 2D (the artist copies what is seen); the caveat is about detector accuracy and about drawings made from a slightly different viewpoint. If more than half the segments are foreshortened, the note becomes "Much of this pose comes toward you, so lengths are approximate; angles are still reliable."
* **Pose differs too much** (the limbs' angle residuals after alignment have a median over 25°): "The poses are too different to compare joint by joint." Body items are hidden; Outline still runs.
* **Mirrored drawing:** if swapping left and right lowers the L1 residual by more than 40%, the phase-1 card "Your drawing may be mirrored. [Mirror the drawing]".

### 3.5 Canvas marks (body)

* **Points:** pose points as in phase 1 (rings, dots). The 33 are thinned to 21 shown (nose, ears, shoulders, elbows, wrists, hand tips, hips, knees, ankles, heels, toes; eyes and mouth only in Face).
* **Skeleton** (new Show chip, on by default in figure modes): reference bones dashed sinopia 1.1 px at 55%, drawing bones graphite 1 px at 45%.
* **Bracket along a limb** (selected item): the phase-1 bracket rotated to the limb, offset to the outer side, with dotted extension lines from the joints, and the label chip ("0.4 heads too short", "9% too long").
* **Angle mark** (tilt and limb-angle items): both lines extended past the joint, the reference dashed, an arc between them, the tag at the arc.
* **Heads ruler** (when Size by is Head height, and always on hover of "Heads tall"): a sinopia ruler left of the reference figure with head ticks and italic numbers, the drawing's foot level as a graphite tick with its count.
* **Balance line:** a dashed sinopia plumb from the pit of the neck to the ground, labelled "balance line".
* Phone: only the selected item's points (phase-1 rule); skeleton thinner.

## 4. Hands (B)

### 4.1 Detector and crops

* **MediaPipe Hand Landmarker**, `hand_landmarker.task` (7,819,105 bytes; palm detector plus 21-point landmark model), same bundle, IMAGE mode, CPU, `numHands: 2`, `minHandDetectionConfidence 0.3`.
* **Hand study:** whole image (at most 1024 px). **Hands inside figures:** a square crop around each visible wrist, centred 0.4 of the way from the wrist toward the pose's index point, side = max(3.2 x wrist-to-index distance, 0.9 heads), scaled so the crop is 256 to 512 px; skipped when the crop is under 64 source pixels in either image ("Hands too small to check here").
* **Which hand is which:** from the pose (the crop came from the left or right wrist), never from the model's handedness label, which assumes a camera image and flips for mirrored or drawn hands. In a hand study, handedness comes from the model and the thumb side, with a manual swap in the picker ("Right hand · Left hand").
* Drawings of hands are where detection is weakest (task H1 measures it). When detection fails on the drawing only: "No hand found in the drawing. [Place hand points]" (a 7-point coach: wrist, thumb tip, the four knuckles' ends, index and little fingertips; the rest are interpolated and marked).

### 4.2 Frame and alignment

Palm frame per hand: origin the wrist (0), y axis toward the middle knuckle (9), unit = palm length (0 to 9). Robust auto: L1 similarity (no rotation) over the palm points 0, 1, 5, 9, 13, 17. The hand angle difference is one item; fingers are measured in the palm frame with it removed.

### 4.3 Items (units: % of the reference palm length, degrees)

| Item | Measure | Usual (start) | Templates (en) |
| --- | --- | ---: | --- |
| Finger length | knuckle to tip along the joints (5-8, 9-12, 13-16, 17-20; thumb 2-4) | 6% of that reference finger | Index finger {n}% too long / too short · Middle … · Ring … · Little … · Thumb {n}% too long / too short |
| Finger ratios (mini chart only, not items) | each finger as a fraction of palm length | n/a | the "Finger lengths" chart (snapshot 2) |
| Thumb placement | the thumb's base (1) and first joint (2) relative to the palm | 5% | Thumb sits {n}% too low / too high · Thumb sits {n}% too far out / too far in |
| Knuckle line | angle of 5 to 17 against the palm axis | 4° | Knuckle line {d}° flatter than the reference · {d}° steeper than the reference |
| Palm width | 5 to 17 | 5% | Palm {n}% too wide / too narrow |
| Finger spread | angle between neighbouring finger axes | 6° | Index and middle fingers {d}° too far apart · {d}° too close (per pair) |
| Finger bend | angle at the middle joint (6, 10, 14, 18) | 10° | Index finger bent {d}° more / less than the reference |
| Hand angle | palm axis | 4° | Hand turned {d}° clockwise / anticlockwise from the reference |
| Hand size (figure modes) | palm length in heads, vs the reference | 8% | Right hand {n}% too small / too big |
| Hand placement (figure modes) | handled by the body's wrist and reach items | | |

Foreshortened fingers (from the hand's world landmarks, ratio below 0.8) are *approx.* as for limbs. Curled fingers whose tip is hidden (the landmark sits inside the palm hull) are not measured for length.

### 4.4 Canvas marks (hands)

21 points, finger axes (thin), the knuckle line (reference dashed, drawing solid), arrows only on flagged joints, the bracket along a finger for the selected length item (snapshot 2), an angle arc for spread, bend and knuckle items. On the reference pane in Side, the selected finger gets the highlighter wash. In figure modes the hand marks appear only when the Hands tab is chosen or a hand item is selected, so the figure view stays readable.

## 5. Outline (C)

Works for any subject, with or without pose.

### 5.1 Pipeline

1. **Align first.** Use the mode's alignment (face, pose, hand) when there is one, else the existing auto-align similarity. The outline is compared in reference pixels after that alignment.
2. **Reference outline (the "dominant contour").**
   * Figures: the pose segmentation mask (already computed). Faces: the Image Segmenter `selfie_segmenter.tflite` (249,537 bytes; person mask). Other photos: `deeplab_v3.tflite` (2,780,176 bytes; 21 everyday classes) when it finds a confident object covering 5 to 90% of the image; otherwise the line route below.
   * Line-art or painted references, and whenever the mask is poor (the mask's boundary agrees with image edges on less than 50% of its length): the line route.
   * Optional later: **Tap the subject** with the Interactive Segmenter (`magic_touch.tflite`, 6,227,884 bytes), for any subject a class model does not know. Not in the first build.
   * The contour is the outer boundary of the largest mask component, smoothed (Gaussian, sigma 0.4% of subject height) and resampled every 0.5% of subject height. Inner contours (gaps between arm and body, between legs) larger than 3% of the subject's area are kept as separate contours.
3. **Drawing lines (sketch-friendly).** Segmenters are trained on photos and do not see pencil outlines, so the drawing side always uses lines: grey, divide by a large blur (removes paper tone and soft shading), XDoG (difference of Gaussians with a soft threshold) at two scales, keep strokes longer than 1% of the subject height, then a distance transform of the stroke map.
4. **Matching by normal search.** For each reference contour sample, search along its normal up to 12% of subject height each way for drawing strokes (from the distance transform), score candidates by distance from the contour, stroke strength and agreement of the stroke direction with the contour tangent (within 35°), and take the best. Then a robust smoothing pass along the contour (running median over 3% of the perimeter, then a small dynamic-programming step that penalises jumps between neighbours) so one stray hatch line cannot make a bump. Samples with no candidate are "not found".
5. **Regions.** Signed distance d (positive = the drawing is outside the reference). Runs where |d| is over the tolerance for at least 2% of the perimeter become regions, scored by area (integral of |d|) and named:
   * with a pose: the nearest body part of the reference along the contour (head, top of the head, neck, shoulder, upper arm, elbow, forearm, hand, side or waist, back (side views, from shoulder-hip direction), hip, thigh, knee, shin, foot), with side;
   * otherwise by position on the subject's box: top, upper left, left, lower left, bottom, lower right, right, upper right (as seen in the picture, since there is no person to own left and right; the footnote says so in Other mode).
6. **Units:** % of the reference subject's height. Usual tolerance 3% to start (task O3 sets it). Major at twice the tolerance.

### 5.2 Templates (en)

```
{Part} outline {n}% too far out        {Part} outline {n}% too far in          (one key per part and side)
Top of the head {n}% too low            Top of the head {n}% too high
Outline at the top {n}% too far out     Outline at the top {n}% too far in      (8 position keys x 2, Other mode)
The outline could not be followed at the {part/position}.                      (a gap over 10% of the perimeter, a note)
```

Copy option for the user (decision 5): "Left shoulder outline 6% too far out" (consistent, recommended) or "Outline of the left shoulder bulges 6% outward / dips 6% inward" (more painterly).

### 5.3 Canvas marks (outline band)

* Reference outline: thin sinopia line (1.3 px, paper halo).
* Where the drawing strays beyond the tolerance, the space between the reference outline and the matched drawing line is filled: **outside** = sinopia wash 30% plus 45° sinopia hatching; **inside** = slate wash 30% plus -45° slate hatching (hatching keeps it readable in grayscale and forced colours).
* Not found: the reference outline drawn dotted grey there.
* Selected region: a distance tick across the band at its peak, with a chip ("6% out"); tags at each region's peak.
* Show chip **Outline band** (off by default in Face and figure modes, where the Outline items still appear in the list with their tag and a short band; on by default in Other mode). Legend in the report or sheet: "Drawing outside · Drawing inside" and "% of the figure's height. Bands show only over tolerance."

## 6. Combining the sections (D)

### 6.1 Report layout (desktop column and phone sheet)

1. Title row, intro line (phase 1).
2. **Checking** picker (mode), **Pin**, **Size by** (phone: mode chip on the sheet's top row; Pin and Size in the full-height sheet).
3. Count line: "6 differences", right side "Usual tolerance".
4. **Section tabs:** All · Face · Body · Hands · Outline, each with its count. A section the mode does not cover is greyed with "–" and a bubble giving the reason (too small, not visible, not found). Phone: a segmented control with the sections that have content.
5. **The list.**
   * *All* (default): one ranked list across sections, at most 6 rows, then "Show {n} more". Each row is the phase-1 row (tag, sentence, optional sub-line).
   * *A section:* that section's items only (up to 10, then "Show more"), plus the section's extra: Body: "Heads tall: 7.1 (reference 7.5)"; Hands: the Finger lengths chart; Outline: the legend.
   * The canvas shows the marks of the current tab only. On *All*, only the marks of the rows shown.
6. Close enough (per tab; on All: the three most useful matches across sections).
7. **Notes:** at most two, by priority: mirrored, poses too different, foreshortening, partial figure, small face or hands, fallback detector.
8. Show chips: Arrows, Points, plus per mode Skeleton (figures), Knuckles (hands), Outline band, Grid (face only).
9. Tolerance (Strict / Usual / Relaxed), then "Edit points · Reset points" as text links.
10. Footnote: "Left and right are the person's own." (Other mode: "Left and right as you look at the picture.")

### 6.2 Ranking across sections

score = (|value| / tolerance) x weight x reliability. Weights: Body 1.0, Face 1.0, Hands 0.9, Outline 0.8 (outline regions often restate a body item). Reliability: exact 1, *approx.* 0.5, possible 0.3. Before ranking, knock-on grouping folds explained items into sub-lines (leg length takes the knees; a forearm length takes the hand; an outline region along a flagged segment goes under it). Ties keep section order Body, Face, Hands, Outline. A visible cap keeps the first screen calm: the All list never shows more than two outline rows.

### 6.3 Persistence

As phase 1, plus: the mode override, the section tab, Skeleton / Knuckles / Outline band chips and per-mode pin and size presets (saved with the settings; per pair for custom pins and edited points).

## 7. Engine (files, models, budget)

### 7.1 Files

| File | Role |
| --- | --- |
| `js/vision.js` (new) | One shared, lazy `FilesetResolver` and bundle import for all MediaPipe tasks (refactor `landmarks.js` to use it); per-task lazy creators with the 60 s timeout and status events, like `landmarks.js` |
| `js/pose.js` (new) | `DC.Pose.detect(src, opts)` → `{ poses: [{ points[33], world[33], visibility[33], box, mask? }], model: 'full'|'lite', ms }` |
| `js/hands.js` (new) | `DC.Hands.detect(src, { crops? })` → `{ hands: [{ points[21], world[21], side, box, crop }], ms }` |
| `js/segment.js` (new, later in the plan) | `DC.Segment.mask(src, { kind: 'person'|'object'|'tap', point? })` |
| `js/figure.js` (new, pure) | `features`, `align`, `measure` for body and hands (same contract as `proportions.js`: keys and numbers, no English) |
| `js/outline.js` (new, pure; runs in a worker when available) | `lines(imageData)`, `contour(mask)`, `compare(refContour, drawingLines, opts)` → samples, regions |
| `js/modes.js` (new, pure) | `decide({ face, pose, hands }, opts)` → mode and reasons |
| `js/prop-ui.js`, `js/prop-i18n.js`, `css/proportions.css` | Tabs, mode picker, new marks, templates |

### 7.2 Models and weight budget (sizes read from Google's model store on 2026-11-18)

| File | Bytes | When it is downloaded |
| --- | ---: | --- |
| `vision_bundle.mjs` + one wasm pair | ~9.8 MB | Already: first use of Proportions |
| `face_landmarker.task` (float16) | 3,758,596 | Already: first use of Proportions |
| `pose_landmarker_full.task` (float16) | 9,398,198 | First time a figure is suspected (no large face) or a figure mode is picked |
| `pose_landmarker_lite.task` (float16) | 5,777,746 | Only if the full model fails or the device has under 4 GB memory |
| `pose_landmarker_heavy.task` | 30,664,242 | Never shipped (bench only) |
| `hand_landmarker.task` (float16) | 7,819,105 | First hand study, or first time a figure has visible wrists big enough |
| `selfie_segmenter.tflite` (float16, 256x256) | 249,537 | First outline check of a face |
| `deeplab_v3.tflite` | 2,780,176 | First outline check in Other mode with a photo reference |
| `magic_touch.tflite` (interactive) | 6,227,884 | Later phase, on first "Tap the subject" |
| `selfie_multiclass_256x256.tflite` | 16,371,837 | Not used |

Typical first figure session: about 23 MB (wasm and bundle, face, pose full); with hands about 31 MB. All files are cached by the browser after the first use and every one is under 25 MB. Nothing loads on page open.

**Licences.** The tasks-vision bundle and wasm are Apache-2.0 (licence file already in `vendor/mediapipe/`). The model pages on developers.google.com state no licence; each model links a model card PDF (BlazePose GHUM 3D; Hand Tracking (Lite/Full) with Fairness, Oct 2021; MediaPipe Selfie Segmentation; MagicTouch). From prior knowledge these cards state Apache-2.0, **to be verified by opening the PDFs** (the text could not be extracted here) before vendoring; DeepLab-V3 has no card (Kaggle page) and needs its licence checked the same way. Record source URL, size and SHA256 of each file in `vendor/mediapipe/README.md`, as for the face model.

### 7.3 Timing targets (desktop CPU, median)

Pose full at most 120 ms per image, hand at most 40 ms per crop, outline at most 150 ms per pair at a 512 px working size (in a worker), whole figure report at most 600 ms after models are cached. Phones: at most 3x.

### 7.4 Bias and gain

Same correction as faces: `value = (raw - bias) / gain`, gain floored at 0.5. Bias per item = mean (sketchified minus original) on clean pairs; gain = median measured / planted on single-error cases of at least 6% or 6°. Separate tables for pose full and lite, and for the hand model on whole images and on crops. Items whose gain is under 0.5 are shown only as "possible" (as jaw width is today).

## 8. Data and tests

### 8.1 Body: PoPArt planted suite

* Data: `datasets/poparts/` (2,453 artworks, COCO 17 keypoints, CC BY 4.0, local testing only). Use figures with at least 13 visible keypoints including both shoulders and hips; split by artist into tune and test halves (phase 1 tuned and scored on the same suite; this one must not).
* **Planted errors by limb warps:** moving-least-squares rigid image warp (Schaefer et al. 2006) with control points on the COCO keypoints (plus fixed points on the image border and the other limbs). One planted change per case: segment length ±4/6/8/12%, leg length ±0.2/0.4 heads, segment angle ±3/6/10°, shoulder or hip tilt ±3/6°, standing foot shift ±0.15/0.3 heads, torso length ±5/10%. Ground truth = the planted keypoint movement. Controls: the unwarped image.
* **Drawing domain:** both the warped and the control image also go through a "sketchify" filter (XDoG lines on paper, plus a light hatching texture) so the drawing side looks like pencil; the reference stays the painting. This measures detector bias and failure on line drawings, which is the main risk.
* Report (like `review/proportions-engine.md`): detection by item and magnitude, control false alarms, unplanted false alarms, median magnitude error, pose found rate on original and sketchified figures, keypoint error against COCO ground truth (in heads).

### 8.2 Hands

* **Proposed datasets (to verify: size, licence, download route):**
  1. **FreiHAND** (University of Freiburg): 32,560 unique training hands (130,240 images with green-screen backgrounds swapped) and 3,960 evaluation images, 224x224, 21 3D keypoints and MANO fits. Licence: research-only terms on the project page, not an open licence (to verify). Use: the 3,960 evaluation images (download roughly 1 GB, to verify), local testing only.
  2. **11k Hands** (Afifi, 2017): 11,076 hand photos, 1600x1200, dorsal and palmar views of 190 people on a white background, close to an artist's hand-study reference; no keypoints, but none are needed for planted tests (ground truth is the planted warp; MediaPipe on the clean photo gives the control points). Licence and size to verify (research use; about 600 MB, to verify).
  3. Alternative: **HaGRID** (about 550k gesture images, CC BY-SA 4.0 for v1 as I recall; its landmarks were made with MediaPipe, so they are circular as ground truth; very large, use a published subsample). Not recommended as the first choice.
* **Synthetic fallback (no download):** the procedural hand from the mock-up generator, made parametric (finger lengths, joint angles, palm width, thumb base) and rendered twice per case, shaded "photo" and pencil line, with exact ground truth for every item. Good for engine tests and UI; not for detector accuracy.
* Planted warps for real images: MLS warp with control points on the 21 landmarks: finger length ±4/6/8/12%, thumb base shift ±4/8%, palm width ±4/8%, knuckle line ±3/6°, finger spread ±5/10°. Sketchify as for bodies.

### 8.3 Outline

* **Simple shapes (synthetic, exact):** ellipses, vases, a cube, a pear, animal and figure silhouettes; reference = filled shape with soft shading; drawing = jittered pencil outline with 0 to 15% gaps, overshoots, construction lines and interior hatching; planted bumps (Gaussian normal displacement, ±2/4/6/8% of height, width 5 to 20% of the perimeter) and global changes (scale 3 to 10% along one axis).
* **CUFS (188 photo/sketch pairs) and FS2K (2,104):** head and hair silhouettes; reference mask from the selfie segmenter on the photo, drawing lines from the sketch; natural pairs give the false-alarm rate; planted bumps by local warps give detection.
* **PoPArt:** body-part naming accuracy with planted bumps at known keypoints.

### 8.4 Success targets

| Part | Target |
| --- | --- |
| Pose found | at least 90% of PoPArt originals, at least 70% of sketchified figures (below 50%: the figure modes ship with "Place points myself" first) |
| Body detection, Usual | at least 70% of planted errors of 6% (or 6°, or 0.3 heads) and above, at least 85% at 12%, on the test half |
| Hands detection, Usual | at least 65% at 8% and above, on 11k Hands or FreiHAND, sketchified drawing side |
| Outline | peak distance error at most 1% of height (median); at least 80% of 6% bumps found, at least 50% of 4%; region named correctly at least 85% with a pose |
| False alarms | controls with any flag at most 5%; unplanted flags on planted cases at most 5% (each section) |
| Speed | as 7.3 |
| Downloads | nothing on page load; each model fetched at most once per browser cache |

## 9. Build plan (small, independent tasks; each lands with tests)

| # | Task | Acceptance |
| --- | --- | --- |
| B0 | Verify and vendor models: pose full and lite, hand, selfie segmenter; record URL, bytes, SHA256, licence (open each model card) | README table filled; sizes match section 7.2; licences confirmed in writing |
| B1 | Spike (bench page, no app changes): pose full, lite and heavy on PoPArt originals and sketchified | Found rate and keypoint error per model; go / no-go on section 8.4's first row; pick the default model |
| B2 | `vision.js` shared loader; refactor `landmarks.js` onto it; `pose.js` | Page load makes no model requests (network log test); first `detect` loads once; fallback to lite; timeout; offline stubbed tests |
| B3 | `figure.js` body: features, derived points, alignment, items, knock-on grouping (pure) | Unit tests on synthetic skeletons: every item reads back its planted value within 0.1% / 0.1°; no English in output |
| B4 | Body planted suite + bias, gain, tolerance sweep (tune half), report (test half) | `review/figure-engine.md` with the tables; targets met or the gap stated |
| B5 | `modes.js` + the Checking picker + override persistence | Fixture table (face close-up, half, full, hand, still life) chooses the right mode; override survives reload |
| B6 | UI body: section tabs, ranked All list, skeleton, limb brackets, angle arcs, balance line, heads ruler, notes; i18n for all body templates in five languages | Snapshot 1 reproduced in the app at 1280x800 and phone; screen reader reads each row as one sentence; silent tests |
| H1 | `hands.js` (whole image and crops from pose) + hand features and items in `figure.js` + synthetic hand suite | Synthetic items read back within 0.5%; crops from PoPArt wrists found in at least 60% where the hand is at least 64 px |
| H2 | Hand dataset suite (after the user approves a dataset) + bias, gain, tolerances | Section 8.4 hands row |
| H3 | UI hands: finger brackets, knuckle line, finger-length chart, hand picker; templates | Snapshot 2 reproduced in Side and Overlay |
| O1 | `outline.js` lines + contour + normal search + regions (worker) | Simple-shape suite: peak error at most 1%; 6% bumps found at least 80%; 150 ms |
| O2 | Masks: pose mask, selfie segmenter, deeplab route, line route fallback; naming by pose and by position | CUFS / FS2K and PoPArt suites; naming at least 85% |
| O3 | UI outline band, legend, tags, phone sheet, Other mode; tolerance sweep | Snapshot 3 reproduced; band never drawn under tolerance; forced-colours hatching |
| M1 | Manual fallbacks: figure template points (13), hand points (7), outline "not found" handling | Each failure state in section 10 reachable and recoverable |
| D1 | README, `review/figure-engine.md`, `review/outline-engine.md` | Docs match the shipped behaviour |

B0 to B3 and O1 have no dependencies on each other and can be built in parallel; UI tasks wait for their engine task.

## 10. Empty and error states (new)

| Situation | What the user sees |
| --- | --- |
| Finding the figure | "Finding the figure…" (calm spinner), then the list fills; Hands later with "Finding hands…" |
| No figure in the drawing | "No figure found in the drawing. Light gesture lines are hard to read." [Place points myself] [Compare outlines] |
| Partial figure in one image | Note: "The drawing shows less of the figure, so only the upper body is checked." |
| Poses too different | "The poses are too different to compare joint by joint." Outline still shown |
| Hands too small | Hands tab greyed: "The hands are too small here to check." |
| No hand found in the drawing | "No hand found in the drawing." [Place hand points] |
| Pose or hand model failed | "Figure finding is not available right now." [Place points myself] [Compare outlines] |
| Outline not found over a long stretch | Note: "The outline could not be followed at the left side." The stretch is dotted grey |

## 11. Decisions for the user

1. **Figure defaults:** Size by **Robust auto** with **Auto** pin (recommended; a mis-drawn head cannot rescale the whole figure), or the artist's convention **Head height** with the pin at the **Pit of the neck** (shown in snapshot 1). Either way, lengths read in heads.
2. **Units in figure mode:** heads for figure-scale lengths and placements, % for single segments (recommended), or % everywhere.
3. **Pose model:** full (9.4 MB, recommended) as default with lite as fallback, or lite only (5.8 MB, less accurate on drawings). Heavy (30.7 MB) is not proposed.
4. **Hand test data:** approve downloading FreiHAND evaluation (research-only terms) and/or 11k Hands for local testing, or synthetic only for now.
5. **Outline wording:** "Left shoulder outline 6% too far out" (recommended) or "Outline of the left shoulder bulges 6% outward".
6. **Outline band default:** off in face and figure modes (items still listed), on in Other mode (recommended), or always on.
