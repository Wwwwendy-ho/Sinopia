// Experiment 1: measure definitions
const X = window.X = {};
const mkItem = (key, terms, o = {}) => Object.assign({ key, feature: 'x', kind: 'proportion', side: 'both', rel: 'high', terms, movable: [...new Set(terms.map(t => t[0]))], dir: ['a', 'b'], sentence: ['a', 'b'], tol: 99 }, o);
const IDX = [33, 133, 362, 263, 468, 473, 129, 358, 98, 327, 48, 278, 64, 294, 219, 439, 49, 279, 240, 460, 209, 429, 61, 291, 78, 308, 62, 292, 76, 306, 13, 14, 0, 17, 1, 2, 94, 159, 145, 386, 374, 168, 152, 136, 365];
X.addRaw = (D, R, dF, rF) => { for (const [fs, f] of [[D, dF], [R, rF]]) for (const i of IDX) fs.points['i' + i] = AN.rawPt(f, i); };
const widthTerms = (r, l) => [['i' + l, 'x', 1], ['i' + r, 'x', -1]];
const avgTerms = (list, ax, sign) => list.map(n => ['i' + n, ax, sign / list.length]);
X.candidates = () => {
  const c = [];
  const W = (fam, name, pairs) => c.push(mkItem(fam + ':' + name, pairs.flatMap(([r, l]) => widthTerms(r, l).map(t => [t[0], t[1], t[2] / pairs.length])), { fam }));
  W('eye_spacing', 'iris', [[468, 473]]); W('eye_spacing', 'inner', [[133, 362]]); W('eye_spacing', 'outer', [[33, 263]]);
  W('eye_spacing', 'iris+inner', [[468, 473], [133, 362]]); W('eye_spacing', 'inner+outer', [[133, 362], [33, 263]]); W('eye_spacing', 'all3', [[468, 473], [133, 362], [33, 263]]);
  for (const [r, l] of [[129, 358], [98, 327], [48, 278], [64, 294], [219, 439], [49, 279], [240, 460], [209, 429]]) W('nose_width', r + '/' + l, [[r, l]]);
  W('nose_width', '129+98', [[129, 358], [98, 327]]);
  W('mouth_width', '61/291', [[61, 291]]); W('mouth_width', '78/308', [[78, 308]]); W('mouth_width', '62/292', [[62, 292]]); W('mouth_width', '76/306', [[76, 306]]); W('mouth_width', '61+78', [[61, 291], [78, 308]]);
  // eye tilt (L y minus R y, + = clockwise) and heights
  const tilt = (name, R_, L_) => c.push(mkItem('eye_tilt:' + name, [...avgTerms(L_, 'y', 1), ...avgTerms(R_, 'y', -1)], { fam: 'eye_tilt', kind: 'tilt' }));
  tilt('iris', [468], [473]); tilt('cornerMid', [33, 133], [362, 263]); tilt('lidMid', [159, 145], [386, 374]); tilt('iris+corner', [468, 33, 133], [473, 362, 263]); tilt('inner', [133], [362]);
  const hR = (name, R_) => c.push(mkItem('eye_height_R:' + name, avgTerms(R_, 'y', -1), { fam: 'eye_height_R', kind: 'placement' }));
  hR('iris', [468]); hR('cornerMid', [33, 133]); hR('lidMid', [159, 145]); hR('iris+corner', [468, 33, 133]);
  const hL = (name, L_) => c.push(mkItem('eye_height_L:' + name, avgTerms(L_, 'y', -1), { fam: 'eye_height_L', kind: 'placement' }));
  hL('iris', [473]); hL('cornerMid', [362, 263]); hL('lidMid', [386, 374]); hL('iris+corner', [473, 362, 263]);
  const nl = (name, l) => c.push(mkItem('nose_length:' + name, avgTerms(l, 'y', 1), { fam: 'nose_length', kind: 'proportion' }));
  nl('base2', [2]); nl('tip1', [1]); nl('94', [94]); nl('base+tip', [2, 1]);
  const mh = (name, l) => c.push(mkItem('mouth_height:' + name, avgTerms(l, 'y', 1), { fam: 'mouth_height', kind: 'placement' }));
  mh('corners', [61, 291]); mh('centre13/14', [13, 14]); mh('lips0/17', [0, 17]); mh('corners+centre', [61, 291, 13, 14]);
  return c;
};
const FAMMAP = { nose_width: [], eye_spacing: ['eye_spacing'], nose_length: ['nose_len'], mouth_width: ['mouth_width'], mouth_height: ['mouth_height'], eye_tilt: ['eye_tilt'], eye_height_R: ['eye_tilt'], eye_height_L: ['eye_tilt'] };
/** raw values of every candidate for a pair (default alignment) */
X.rawAll = (dF, rF, items, mod) => {
  const r = AN.run(dF, rF, { items, tolerance: 99, bias: 'none', gain: 'none' }, (D, R, a, b) => { X.addRaw(D, R, a, b); if (mod) mod(D, R, a, b); });
  if (!r) return null; const o = {}; for (const it of r.rep.items) o[it.key] = it.raw; return o;
};
X.exp1 = (opt = {}) => {
  const items = X.candidates().filter(i => !opt.keys || opt.keys.includes(i.key)), fams = [...new Set(items.map(i => i.fam))], out = {};
  const sets = {
    fs2k: AN.data['fs2k-natural'].filter(r => AN.half(r.id) === 0 && r.S.n && r.P.n).map(r => ({ raw: X.rawAll(r.S.faces[0], r.P.faces[0], items, opt.frameMod), style: r.style })),
    cufs: AN.data['cufs-natural'].filter(r => AN.half(r.id) === 0 && r.S.n && r.P.n).map(r => ({ raw: X.rawAll(r.S.faces[0], r.P.faces[0], items, opt.frameMod), style: 'c' })),
  };
  const planted = {
    fs2k: AN.data['fs2k-planted'].filter(r => r.kind === 'single' && AN.half(r.sk) === 0 && r.D.n).map(r => ({ r, raw: X.rawAll(r.D.faces[0], r.P.faces[0], items, opt.frameMod) })),
    cufs: AN.data['cufs-planted'].filter(r => r.kind === 'single' && AN.half('cufs' + r.item) === 0 && r.D.n).map(r => ({ r, raw: null })),
  };
  // cufs planted needs the photo faces: item -> photo record
  const phot = {}; for (const r of AN.data['cufs-natural']) phot[r.i] = r.P;
  planted.cufs = planted.cufs.map(o => ({ r: o.r, raw: phot[o.r.item] && phot[o.r.item].n ? X.rawAll(o.r.D.faces[0], phot[o.r.item].faces[0], items, opt.frameMod) : null }));
  for (const it of items) {
    const k = it.key; out[k] = { fam: it.fam };
    for (const ds of ['fs2k', 'cufs']) {
      const v = sets[ds].filter(s => s.raw).map(s => s.raw[k]), mu = med(v), dev = v.map(x => Math.abs(x - mu));
      const gains = planted[ds].filter(o => o.raw && o.r.errors.length === 1 && FAMMAP[it.fam].includes(o.r.errors[0].feature) && Math.abs(o.r.errors[0].truth) >= 4 && (it.fam.startsWith('eye') ? true : true))
        .map(o => (o.raw[k] - mu) / o.r.errors[0].truth);
      const g = med(gains);
      out[k][ds] = { n: v.length, bias: r2(mu), p90: r2(q(dev, .9)), p95: r2(q(dev, .95)), gain: r2(g), eff90: r2(q(dev, .9) / Math.abs(g)), nGain: gains.length };
    }
    if (it.fam === 'eye_spacing' || it.fam === 'nose_width' || it.fam === 'mouth_width') { // style dependence of the bias
      out[k].byStyle = [0, 1, 2].map(s => r2(med(sets.fs2k.filter(x => x.style === s && x.raw).map(x => x.raw[k]))));
    }
  }
  X.exp1out = out; return out;
};
X.table = (out) => Object.entries(out).map(([k, v]) => `${k.padEnd(26)} fs2k b${v.fs2k.bias} p90 ${v.fs2k.p90} g${v.fs2k.gain} eff ${v.fs2k.eff90} | cufs b${v.cufs.bias} p90 ${v.cufs.p90} g${v.cufs.gain} eff ${v.cufs.eff90}${v.byStyle ? ' | styles ' + v.byStyle.join('/') : ''}`).join('\n');
X.frameMods = {
  none: null,
  corner: (D, R, a, b) => { for (const [fs, f] of [[D, a], [R, b]]) { const m = (i, j) => ({ x: (f.p[2*i] + f.p[2*j]) / 2, y: (f.p[2*i+1] + f.p[2*j+1]) / 2 }); fs.points.eyeR = m(33, 133); fs.points.eyeL = m(362, 263); } },
  mixed: (D, R, a, b) => { for (const [fs, f] of [[D, a], [R, b]]) { const m = (i, j, k) => ({ x: (f.p[2*i] + f.p[2*j] + f.p[2*k]) / 3, y: (f.p[2*i+1] + f.p[2*j+1] + f.p[2*k+1]) / 3 }); fs.points.eyeR = m(468, 33, 133); fs.points.eyeL = m(473, 362, 263); } },
  inner: (D, R, a, b) => { for (const [fs, f] of [[D, a], [R, b]]) { const m = (i, j) => ({ x: (f.p[2*i] + f.p[2*j]) / 2, y: (f.p[2*i+1] + f.p[2*j+1]) / 2 }); fs.points.eyeR = m(468, 133); fs.points.eyeL = m(473, 362); } },
};
X.KEYS = ['eye_spacing:iris', 'eye_spacing:iris+inner', 'nose_width:209/429', 'nose_width:129/358', 'mouth_width:61/291', 'eye_tilt:iris', 'nose_length:base2', 'mouth_height:corners', 'eye_height_R:iris'];
X.frames = () => { const o = {}; for (const k of Object.keys(X.frameMods)) o[k] = X.exp1({ keys: X.KEYS, frameMod: X.frameMods[k] }); return o; };

// ---- Experiment 1b: flip-averaging (test-time augmentation) of landmarks
const MIR = [[33,263],[133,362],[159,386],[145,374],[70,300],[63,293],[105,334],[66,296],[107,336],[129,358],[98,327],[61,291],[37,267],[84,314],[205,425],[50,280],[116,345],[132,361],[172,397],[234,454],[58,288],[93,323],[136,365],[150,379],[127,356],[162,389],[21,251],[54,284],[103,332],[67,297],[468,473],[209,429],[48,278],[64,294],[219,439],[49,279],[240,460],[78,308],[62,292],[76,306],[469,474],[470,475],[471,476],[472,477]];
const MIRMAP = {}; for (const [a, b] of MIR) { MIRMAP[a] = b; MIRMAP[b] = a; }
X.MIRMAP = MIRMAP;
/** average the sketch landmarks with the un-mirrored landmarks of the flipped sketch. W = sketch width (source px). Returns a face-like {p} */
X.tta = (face, fface, W, w = 0.5) => {
  const p = face.p.slice(), n = p.length / 2;
  for (let i = 0; i < n; i++) {
    const j = i in MIRMAP ? MIRMAP[i] : (X.SELF.has(i) ? i : -1); if (j < 0) continue;
    p[2 * i] = (1 - w) * face.p[2 * i] + w * (W - fface.p[2 * j]); p[2 * i + 1] = (1 - w) * face.p[2 * i + 1] + w * fface.p[2 * j + 1];
  }
  return { p, box: face.box };
};
X.SELF = new Set([1, 2, 168, 0, 17, 152, 13, 14, 10, 94, 6, 4, 164, 18, 200, 199, 175]);
X.exp1b = (keys) => {
  const items = X.candidates().filter(i => keys.includes(i.key)), out = {};
  for (const ds of ['fs2k', 'cufs']) {
    const rows = (ds === 'fs2k' ? AN.data['fs2k-natural'].filter(r => AN.half(r.id) === 0) : AN.data['cufs-natural'].filter(r => AN.half(r.id) === 0)).filter(r => r.S.n && r.P.n && r.F.n);
    for (const mode of ['single', 'tta', 'flipOnly']) {
      const vals = rows.map(r => { const W = ds === 'fs2k' ? r.sw : 414; const d = mode === 'single' ? r.S.faces[0] : mode === 'tta' ? X.tta(r.S.faces[0], r.F.faces[0], r.sw || 414) : X.tta(r.S.faces[0], r.F.faces[0], r.sw || 414, 1); return X.rawAll(d, r.P.faces[0], items); }).filter(Boolean);
      for (const it of items) { const v = vals.map(x => x[it.key]), mu = med(v), dev = v.map(x => Math.abs(x - mu)); (out[it.key] = out[it.key] || {})[ds + ':' + mode] = `b${r2(mu)} p90 ${r2(q(dev, .9))} sd ${r2(Math.sqrt(mean(v.map(x => (x - mu) ** 2))))}`; }
    }
  }
  return out;
};
// ---- Experiment 2: noise / style predictors
X.CORE = ['eye_spacing:iris+inner', 'nose_width:209/429', 'mouth_width:61/291', 'eye_tilt:iris', 'eye_height_R:iris', 'eye_height_L:iris', 'nose_length:base2', 'mouth_height:corners'];
X.pairInfo = (rec, items, dFace, rFace) => {
  const r = AN.run(dFace, rFace, { items, tolerance: 99, bias: 'none', gain: 'none' }, X.addRaw); if (!r) return null;
  const raw = {}; for (const it of r.rep.items) raw[it.key] = it.raw;
  const reg = rec.S ? rec.S.reg && rec.S.reg[0] : null, ink = rec.S && rec.S.ink;
  const res = r.al.fit.residual;
  return { raw, res: res.median, resMean: res.mean, resMax: res.max, eyesInk: reg && reg.eyes[0], eyesEdge: reg && reg.eyes[1], eyesStrong: reg && reg.eyes[2], noseEdge: reg && reg.nose[1], mouthEdge: reg && reg.mouth[1], chinEdge: reg && reg.chin[1], mouthInk: reg && reg.mouth[0],
    noiseRel: ink && ink.noiseRel, range: ink && ink.range, ecPx: reg && reg.ec, style: rec.style, id: rec.id };
};
X.corr = (a, b) => { const ma = mean(a), mb = mean(b); let s = 0, sa = 0, sb = 0; for (let i = 0; i < a.length; i++) { s += (a[i] - ma) * (b[i] - mb); sa += (a[i] - ma) ** 2; sb += (b[i] - mb) ** 2; } return s / Math.sqrt(sa * sb); };
X.rank = a => { const idx = a.map((v, i) => [v, i]).sort((x, y) => x[0] - y[0]), r = new Array(a.length); idx.forEach(([, i], k) => { r[i] = k; }); return r; };
X.exp2 = () => {
  const items = X.candidates().filter(i => X.CORE.includes(i.key));
  const sets = { fs2k: AN.data['fs2k-natural'].filter(r => AN.half(r.id) === 0 && r.S.n && r.P.n).map(r => X.pairInfo(r, items, r.S.faces[0], r.P.faces[0])),
    cufs: AN.data['cufs-natural'].filter(r => AN.half(r.id) === 0 && r.S.n && r.P.n).map(r => X.pairInfo(r, items, r.S.faces[0], r.P.faces[0])) };
  X.sets2 = sets;
  const out = {};
  for (const ds of ['fs2k', 'cufs']) {
    const S = sets[ds].filter(Boolean), mu = {}, sd = {};
    for (const k of X.CORE) { const v = S.map(s => s.raw[k]); mu[k] = med(v); sd[k] = 1.4826 * med(v.map(x => Math.abs(x - mu[k]))); }
    for (const s of S) s.T = Math.sqrt(mean(X.CORE.map(k => ((s.raw[k] - mu[k]) / 3) ** 2)));  // RMS deviation from the (set) bias, in units of 3% EC
    out[ds] = { n: S.length };
    for (const p of ['res', 'resMean', 'resMax', 'eyesInk', 'eyesEdge', 'eyesStrong', 'noseEdge', 'mouthEdge', 'chinEdge', 'mouthInk', 'noiseRel', 'range', 'ecPx']) {
      const ok = S.filter(s => s[p] != null && isFinite(s[p])); out[ds][p] = r2(X.corr(X.rank(ok.map(s => s[p])), X.rank(ok.map(s => s.T))));
    }
    out[ds].meanT = r2(mean(S.map(s => s.T)));
    if (ds === 'fs2k') out[ds].byStyleT = [0, 1, 2].map(st => r2(mean(S.filter(s => s.style === st).map(s => s.T))));
  }
  return out;
};
// ---- Collection with the app's engine (current definitions), raw values + predictors
X.OPT0 = { tolerance: 99, bias: 'none', gain: 'none' };
X.info = (dFace, rFace, extra = {}) => {
  const r = AN.run(dFace, rFace, X.OPT0); if (!r) return null;
  const raw = {}; for (const it of r.rep.items) raw[it.key] = it.raw;
  const rs = P.residuals(r.D, r.R, r.al), rm = rs.length ? q(rs, .5) : 0;
  return Object.assign({ raw, res: r.al.fit.residual.median, resW: rm, resWm: mean(rs), resW75: q(rs, .75), yD: r.rep.pose.drawingYaw, yR: r.rep.pose.referenceYaw, tilt: r.rep.tilt ? r.rep.tilt.value : 0 }, extra);
};
X.collect = () => {
  const out = { fs2kN: [], cufsN: [], fs2kP: [], cufsP: [] };
  for (const r of AN.data['fs2k-natural']) if (r.S.n && r.P.n) { const i = X.info(r.S.faces[0], r.P.faces[0], { id: r.id, style: r.style, half: AN.half(r.id), reg: r.S.reg && r.S.reg[0], ink: r.S.ink, nFaces: r.S.n }); if (i) out.fs2kN.push(i); }
  const phot = {}; for (const r of AN.data['cufs-natural']) { phot[r.i] = r.P; if (r.S.n && r.P.n) { const i = X.info(r.S.faces[0], r.P.faces[0], { id: r.id, style: 'c', half: AN.half('cufs' + r.i), reg: r.S.reg && r.S.reg[0], ink: r.S.ink }); if (i) out.cufsN.push(i); } }
  for (const r of AN.data['fs2k-planted']) if (r.D.n && r.P.n) { const i = X.info(r.D.faces[0], r.P.faces[0], { id: r.id, kind: r.kind, errors: r.errors, tilt: r.tilt, style: r.style, half: AN.half(r.sk), sk: r.sk, reg: r.D.reg && r.D.reg[0], ink: r.D.ink }); if (i) out.fs2kP.push(i); }
  for (const r of AN.data['cufs-planted']) { const P_ = phot[r.item]; if (r.D.n && P_ && P_.n) { const i = X.info(r.D.faces[0], P_.faces[0], { id: 'c' + r.ci, kind: r.kind, errors: r.errors, tilt: r.tilt, style: 'c', half: AN.half('cufs' + r.item), sk: 'cufs' + r.item, reg: r.D.reg && r.D.reg[0], ink: r.D.ink }); if (i) out.cufsP.push(i); } }
  X.C = out; return Object.fromEntries(Object.entries(out).map(([k, v]) => [k, v.length]));
};
X.KEYS8 = ['eye_spacing', 'eye_height_R', 'eye_height_L', 'eye_tilt', 'nose_length', 'nose_width', 'mouth_height', 'mouth_width', 'chin_length', 'brow_height_R', 'brow_height_L'];
// residual bins: per key, bias and p90 of |raw - set median| per predictor quartile, pooled fs2k + cufs (cal halves)
X.byRes = (pred = 'resW', nb = 4) => {
  const pool = [...X.C.fs2kN, ...X.C.cufsN].filter(r => r.half === 0), v = pool.map(r => r[pred]).sort((a, b) => a - b), cuts = Array.from({ length: nb - 1 }, (_, i) => v[Math.floor(v.length * (i + 1) / nb)]);
  const bin = x => cuts.filter(c => x > c).length, out = { cuts: cuts.map(r2) };
  for (const k of ['eye_spacing', 'eye_tilt', 'nose_length', 'nose_width', 'mouth_height', 'mouth_width', 'chin_length']) {
    const all = pool.map(r => r.raw[k]), mu0 = med(all); out[k] = [];
    for (let b = 0; b < nb; b++) { const g = pool.filter(r => bin(r[pred]) === b).map(r => r.raw[k]); out[k].push(`n${g.length} b${r2(med(g))} p90|${r2(q(g.map(x => Math.abs(x - mu0)), .9))}`); }
  }
  return out;
};
// ---- Decision simulation on raw values
const TOL0 = { eye_spacing: 3.5, eye_height_R: 3.5, eye_height_L: 3.5, eye_tilt: 3.5, nose_length: 3.5, mouth_height: 3.5, mouth_width: 6.5, chin_length: 7, nose_width: 4, brow_height_R: 4, brow_height_L: 4 };
X.TOL0 = TOL0; X.SKEYS = Object.keys(TOL0);
const BENCHK2 = { eye_spacing: ['eye_spacing'], nose_len: ['nose_length'], mouth_width: ['mouth_width'], mouth_height: ['mouth_height'], chin_len: ['chin_length'], jaw_width: ['jaw_width', 'jaw_width_high'] };
X.hit = (err, fl) => {
  const sg = Math.sign(err.truth);
  if (err.feature === 'eye_tilt') { const key = err.side === 'L' ? 'eye_height_R' : 'eye_height_L', es = err.type === 'eye_high' ? 1 : -1; return fl.some(f => (f.k === key && Math.sign(f.v) === es) || (f.k === 'eye_tilt' && Math.sign(f.v) === sg) || f.k === 'eye_height_R' || f.k === 'eye_height_L'); }
  return fl.some(f => (BENCHK2[err.feature] || []).includes(f.k) && Math.sign(f.v) === sg);
};
/** fit a linear-in-clamped-residual bias model per key by trimmed least squares on natural calibration pairs */
X.fitBias = (recs, pred, r0, rmax, keys) => {
  const out = {};
  for (const k of keys || X.SKEYS) {
    const pts = recs.map(r => [Math.min(rmax, Math.max(0, r[pred] - r0)), r.raw[k]]);
    let a = med(pts.map(p => p[1])), b = 0;
    for (let it = 0; it < 8; it++) { // iteratively trimmed LS
      const res = pts.map(p => Math.abs(p[1] - a - b * p[0])), cut = q(res, .9), use = pts.filter((p, i) => res[i] <= cut);
      const mx = mean(use.map(p => p[0])), my = mean(use.map(p => p[1])); let sxx = 0, sxy = 0; for (const p of use) { sxx += (p[0] - mx) ** 2; sxy += (p[0] - mx) * (p[1] - my); }
      b = sxx > 1e-9 ? sxy / sxx : 0; a = my - b * mx;
    }
    out[k] = { a, b };
  }
  return out;
};
X.flagsOf = (rec, par) => {
  const rc = Math.min(par.rmax, Math.max(0, rec[par.pred] - par.r0)), res = rec[par.pred], m = par.M > 1 ? Math.min(par.M, Math.max(1, Math.pow(res / par.R0, par.p || 1))) : 1, fl = [];
  for (const k of X.SKEYS) {
    if (par.skip && par.skip.has(k)) continue;
    const lvl = par.gLo ? Math.min(1, Math.max(0, (res - par.R0) / (par.M > 1 ? par.R0 * (par.M - 1) : 1))) : 0, gA = par.gLo && (par.gLo[k] !== undefined) ? par.gLo[k] + (par.gHi[k] - par.gLo[k]) * lvl : null;
    const bm = par.bias && par.bias[k], bias = bm ? bm.a + ((par.useSlope === false || (par.slopeKeys && !par.slopeKeys.has(k))) ? 0 : bm.b * rc) : 0, g = gA || (par.gain && par.gain[k]) || 1;
    const v = (rec.raw[k] - bias) / g, tol = (par.tol && par.tol[k] || TOL0[k]) * (par.s || 1) * m;
    if (Math.abs(v) > tol * (1 + (par.margin || 0))) fl.push({ k, v, x: Math.abs(v) / tol });
  }
  if (par.gate && fl.length >= par.gate.n) return fl.filter(f => f.x >= par.gate.mult * (1 + (par.margin || 0)) || f.x >= par.gate.mult);
  return fl;
};
X.evalPar = (par, half) => {
  const C = X.C, f = a => a.filter(r => r.half === half);
  const out = {};
  const nat = (arr) => { const n = arr.map(r => X.flagsOf(r, par).length); return { n: n.length, any: pct(n.filter(x => x > 0).length, n.length), ge2: pct(n.filter(x => x >= 2).length, n.length), ge3: pct(n.filter(x => x >= 3).length, n.length) }; };
  out.fs2kN = nat(f(C.fs2kN)); out.cufsN = nat(f(C.cufsN));
  for (const [nm, arr] of [['fs2kP', f(C.fs2kP)], ['cufsP', f(C.cufsP)]]) {
    const ctrl = arr.filter(r => r.kind === 'control'), sing = arr.filter(r => r.kind === 'single'), ge4 = sing.filter(r => r.errors[0].mag >= 4), ge6 = sing.filter(r => r.errors[0].mag >= 6);
    const h4 = ge4.filter(r => X.hit(r.errors[0], X.flagsOf(r, par))).length, h6 = ge6.filter(r => X.hit(r.errors[0], X.flagsOf(r, par))).length;
    const c = ctrl.map(r => X.flagsOf(r, par).length);
    out[nm] = { det4: pct(h4, ge4.length), det6: pct(h6, ge6.length), ctrlAny: pct(c.filter(x => x > 0).length, c.length), ctrl3: pct(c.filter(x => x >= 3).length, c.length), nCtrl: c.length, nS4: ge4.length };
  }
  return out;
};
X.calibrate = (pred = 'resW', r0 = 2, rmax = 3) => {
  const C = X.C, cal = a => a.filter(r => r.half === 0), nat = [...cal(C.fs2kN), ...cal(C.cufsN)];
  const bias = X.fitBias(nat, pred, r0, rmax);
  const par0 = { pred, r0, rmax, bias, M: 1, R0: 2, s: 1 };
  // gains from planted cal singles >= 4, bias model removed
  const gain = {}, plant = [...cal(C.fs2kP), ...cal(C.cufsP)].filter(r => r.kind === 'single' && r.errors.length === 1 && Math.abs(r.errors[0].truth) >= 4);
  const F = { eye_spacing: ['eye_spacing'], nose_len: ['nose_length'], mouth_width: ['mouth_width'], mouth_height: ['mouth_height'], chin_len: ['chin_length'] };
  for (const [feat, keys] of Object.entries(F)) { const gs = plant.filter(r => r.errors[0].feature === feat).map(r => { const rc = Math.min(rmax, Math.max(0, r[pred] - r0)), b = bias[keys[0]]; return (r.raw[keys[0]] - b.a - b.b * rc) / r.errors[0].truth; }); gain[keys[0]] = Math.max(.5, Math.min(1, med(gs))); }
  par0.gain = gain; return par0;
};
X.predCorr = () => {
  const S = X.C.fs2kN.filter(r => r.half === 0), out = {};
  const preds = { res: r => r.res, resW: r => r.resW, resW75: r => r.resW75, resWm: r => r.resWm, ecPx: r => r.reg && r.reg.ec, eyesInk: r => r.reg && r.reg.eyes[0], eyesEdge: r => r.reg && r.reg.eyes[1], noiseRel: r => r.ink && r.ink.noiseRel, absYaw: r => Math.abs(r.yD - r.yR), tilt: r => Math.abs(r.tilt) };
  for (const k of ['eye_spacing', 'eye_tilt', 'nose_length', 'nose_width', 'mouth_height', 'mouth_width', 'chin_length']) {
    const mu = med(S.map(r => r.raw[k])); out[k] = {};
    for (const [pn, fn] of Object.entries(preds)) { const ok = S.filter(r => fn(r) != null && isFinite(fn(r))); out[k][pn] = r2(X.corr(X.rank(ok.map(fn)), X.rank(ok.map(r => Math.abs(r.raw[k] - mu))))); }
  }
  return out;
};
X.resDist = () => { const o = {}; for (const k of ['fs2kN', 'cufsN']) for (const h of [0, 1]) { const v = X.C[k].filter(r => r.half === h).map(r => r.resW); o[k + h] = [.1, .25, .5, .75, .9].map(p => r2(q(v, p))); } return o; };
// scoring on calibration
X.score = (par, half = 0) => {
  const e = X.evalPar(par, half), nF = e.fs2kN.n, nC = e.fs2kP.nCtrl;
  const fsAny = (e.fs2kN.any * nF + e.fs2kP.ctrlAny * nC) / (nF + nC), fs3 = (e.fs2kN.ge3 * nF + e.fs2kP.ctrl3 * nC) / (nF + nC);
  const cuAny = (e.cufsN.any * e.cufsN.n + e.cufsP.ctrlAny * 45) / (e.cufsN.n + 45);
  return { fsAny, fs3, cuAny, det6: (e.fs2kP.det6 + e.cufsP.det6) / 2, det4: (e.fs2kP.det4 + e.cufsP.det4) / 2, fsDet6: e.fs2kP.det6, cuDet6: e.cufsP.det6, raw: e };
};
X.search = (base, n = 1500, seed = 1) => {
  const rnd = Planted.rng('search' + seed), pick = a => a[Math.floor(rnd() * a.length)], res = [];
  for (let i = 0; i < n; i++) {
    const par = Object.assign({}, base, { s: pick([.8, .9, 1, 1.1, 1.25, 1.4]), M: pick([1, 1.5, 2, 2.5, 3]), R0: pick([1.8, 2.2, 2.6, 3.0, 3.5]), p: pick([1, 1.5, 2, 3]), margin: pick([0, 0.1, 0.2, 0.35]), useSlope: pick([true, false]),
      tol: Object.assign({}, TOL0, { eye_spacing: TOL0.eye_spacing * pick([1, 1.15, 1.3, 1.5]), mouth_width: TOL0.mouth_width * pick([.8, 1, 1.2]), nose_width: TOL0.nose_width * pick([.8, 1, 1.2, 1.4]) }) });
    const s = X.score(par, 0); res.push({ par, s });
  }
  return res;
};
X.front = (res, targets = [15, 20, 25, 30, 40]) => targets.map(T => { const ok = res.filter(r => r.s.fsAny <= T && r.s.cuAny <= 6).sort((a, b) => b.s.det6 - a.s.det6)[0]; return ok ? { T, ok } : { T, ok: null }; });
// flip disagreement: how far the landmarks of the mirrored drawing (mirrored back) are from the drawing's own, % of EC
X.flipDis = (face, fface, W) => {
  if (!face || !fface) return null; const p = face.p, ec = Math.hypot(p[2 * 152] - (p[2 * 468] + p[2 * 473]) / 2, p[2 * 152 + 1] - (p[2 * 468 + 1] + p[2 * 473 + 1]) / 2), d = [];
  for (const i of [468, 473, 33, 263, 133, 362, 61, 291, 129, 358, 209, 429, 136, 365, 70, 300, 105, 334]) { const j = MIRMAP[i]; d.push(Math.hypot(p[2 * i] - (W - fface.p[2 * j]), p[2 * i + 1] - fface.p[2 * j + 1]) / ec * 100); }
  for (const i of [1, 2, 152, 0, 17]) d.push(Math.hypot(p[2 * i] - (W - fface.p[2 * i]), p[2 * i + 1] - fface.p[2 * i + 1]) / ec * 100);
  d.sort((a, b) => a - b); return { med: d[d.length >> 1], mean: mean(d), p75: q(d, .75) };
};
X.flipCorr = () => {
  const rows = AN.data['fs2k-natural'].filter(r => AN.half(r.id) === 0 && r.S.n && r.P.n && r.F.n), items = rows.map(r => ({ r, i: X.info(r.S.faces[0], r.P.faces[0]), fd: X.flipDis(r.S.faces[0], r.F.faces[0], r.sw) })).filter(o => o.i && o.fd);
  const out = {};
  for (const k of ['eye_spacing', 'eye_tilt', 'nose_length', 'nose_width', 'mouth_height', 'mouth_width']) { const mu = med(items.map(o => o.i.raw[k])); out[k] = { flipMed: r2(X.corr(X.rank(items.map(o => o.fd.med)), X.rank(items.map(o => Math.abs(o.i.raw[k] - mu))))), flipMean: r2(X.corr(X.rank(items.map(o => o.fd.mean)), X.rank(items.map(o => Math.abs(o.i.raw[k] - mu))))), resW: r2(X.corr(X.rank(items.map(o => o.i.resW)), X.rank(items.map(o => Math.abs(o.i.raw[k] - mu))))) }; }
  out.flipVsRes = r2(X.corr(X.rank(items.map(o => o.fd.med)), X.rank(items.map(o => o.i.resW)))); out.fdMed = [.25, .5, .75, .9].map(p => r2(q(items.map(o => o.fd.med), p)));
  return out;
};
X.search2 = (base, n = 1500, seed = 1) => {
  const rnd = Planted.rng('search2-' + seed), pick = a => a[Math.floor(rnd() * a.length)], res = [];
  for (let i = 0; i < n; i++) {
    const sk = pick([null, new Set(['eye_spacing']), new Set(['eye_spacing', 'nose_width']), new Set(['eye_spacing', 'nose_width', 'mouth_height'])]);
    const par = Object.assign({}, base, { s: pick([.8, .9, 1, 1.1, 1.25, 1.4]), M: pick([1, 1.5, 2, 2.5, 3]), R0: pick([1.4, 1.8, 2.2, 2.6, 3.0]), p: pick([1, 1.5, 2, 3]), margin: pick([0, 0.1, 0.2]), useSlope: !!sk, slopeKeys: sk,
      gate: pick([null, null, { n: 3, mult: 1.3 }, { n: 3, mult: 1.6 }, { n: 2, mult: 1.3 }, { n: 2, mult: 1.6 }]),
      tol: Object.assign({}, TOL0, { eye_spacing: TOL0.eye_spacing * pick([1, 1.15, 1.3, 1.5]), mouth_width: TOL0.mouth_width * pick([.8, 1, 1.2]), nose_width: TOL0.nose_width * pick([.8, 1, 1.2, 1.4]), eye_height_R: 3.5 * pick([.9, 1, 1.2]), eye_height_L: 3.5 * pick([.9, 1, 1.2]) }) });
    const s = X.score(par, 0); res.push({ par, s });
  }
  return res;
};
X.fmt = f => f.ok ? { T: f.T, s: Object.fromEntries(Object.entries(f.ok.s).filter(([k]) => k !== 'raw').map(([k, v]) => [k, r2(v)])), par: { s: f.ok.par.s, M: f.ok.par.M, R0: f.ok.par.R0, p: f.ok.par.p, mg: f.ok.par.margin, sk: f.ok.par.slopeKeys && [...f.ok.par.slopeKeys].join('+'), g: f.ok.par.gate && f.ok.par.gate.n + 'x' + f.ok.par.gate.mult, es: r2(f.ok.par.tol.eye_spacing), mw: f.ok.par.tol.mouth_width, nw: r2(f.ok.par.tol.nose_width), eh: f.ok.par.tol.eye_height_R } } : { T: f.T };
X.gainsFor = (pred, r0, rmax, bias, sets) => {
  const gain = {}, plant = sets.flatMap(a => a.filter(r => r.half === 0 && r.kind === 'single' && r.errors.length === 1 && Math.abs(r.errors[0].truth) >= 4));
  const F = { eye_spacing: ['eye_spacing'], nose_len: ['nose_length'], mouth_width: ['mouth_width'], mouth_height: ['mouth_height'], chin_len: ['chin_length'] };
  for (const [feat, keys] of Object.entries(F)) { const gs = plant.filter(r => r.errors[0].feature === feat).map(r => { const rc = Math.min(rmax, Math.max(0, r[pred] - r0)), b = bias[keys[0]]; return (r.raw[keys[0]] - b.a - b.b * rc) / r.errors[0].truth; }); gain[keys[0]] = Math.max(.5, Math.min(1, med(gs))); gain[keys[0] + '_n'] = gs.length; }
  return gain;
};
// ---- Pose (synthetic yaw, CUFS) 
X.collectYaw = (comp) => {
  const rows = AN.data['yaw'], out = [];
  for (const r of rows) { if (!r.D.n || !r.P.n) continue; const rr = AN.run(r.D.faces[0], r.P.faces[0], { tolerance: 99, bias: 'none', gain: 'none', yawComp: comp }); if (!rr) continue;
    const raw = {}; for (const it of rr.rep.items) raw[it.key] = it.raw; const rs = P.residuals(rr.D, rr.R, rr.al);
    out.push({ i: r.i, cond: r.cond, half: AN.half('cufs' + r.i), yawD: r.yawMP, yawR: r.yawMPref, yD: rr.rep.pose.drawingYaw, yR: rr.rep.pose.referenceYaw, raw, resW: q(rs, .5), kind: 'yaw' }); }
  return out;
};
X.poseRoc = () => {
  const Y = X.collectYaw(false), res = {};
  const cal = Y.filter(r => r.half === 0 && r.yawD != null && r.yawR != null);
  for (const dg of [8, 10, 12]) {
    const pos = cal.filter(r => Math.abs(r.yawD - r.yawR) >= dg), neg = cal.filter(r => Math.abs(r.yawD - r.yawR) < dg); res['diff>=' + dg] = { nPos: pos.length, nNeg: neg.length };
    for (const th of [.05, .06, .07, .08, .09, .1, .12, .15]) res['diff>=' + dg][th] = `${pct(pos.filter(r => Math.abs(r.yD - r.yR) > th).length, pos.length)}/${pct(neg.filter(r => Math.abs(r.yD - r.yR) > th).length, neg.length)}`;
  }
  // abs yaw
  for (const dg of [20, 25, 30]) { const pos = cal.filter(r => Math.abs(r.yawD) >= dg), neg = cal.filter(r => Math.abs(r.yawD) < dg); res['abs>=' + dg] = { nPos: pos.length, nNeg: neg.length }; for (const th of [.15, .2, .25, .3, .35]) res['abs>=' + dg][th] = `${pct(pos.filter(r => Math.abs(r.yD) > th).length, pos.length)}/${pct(neg.filter(r => Math.abs(r.yD) > th).length, neg.length)}`; }
  // slope proxy vs yaw (deg)
  const xs = cal.map(r => r.yawD), ys = cal.map(r => r.yD), mx = mean(xs), my = mean(ys); let sxx = 0, sxy = 0; for (let i = 0; i < xs.length; i++) { sxx += (xs[i] - mx) ** 2; sxy += (xs[i] - mx) * (ys[i] - my); } res.slope = { perDeg: r2(sxy / sxx * 100) / 100, intercept: r2(my - sxy / sxx * mx), n: xs.length };
  // by cond: median |yD - yR|, yD
  res.byCond = {}; for (const c of ['y0', 'y5', 'y10', 'y15', 'y20', 'y30', 'sq10', 'sq20', 'sq30']) { const R = cal.filter(r => r.cond === c); res.byCond[c] = { n: R.length, absDiff: r2(med(R.map(r => Math.abs(r.yD - r.yR)))), mpDiffDeg: r1(med(R.map(r => Math.abs(r.yawD - r.yawR)))), absY: r2(med(R.map(r => Math.abs(r.yD)))) }; }
  // natural FS2K warning rates by threshold (all halves = calibration only)
  const nat = X.C.fs2kN.filter(r => r.half === 0); res.fs2kWarn = {}; for (const th of [.05, .07, .09, .1, .12, .15]) res.fs2kWarn[th] = pct(nat.filter(r => Math.abs(r.yD - r.yR) > th).length, nat.length);
  res.fs2kLarge = {}; for (const th of [.2, .25, .3]) res.fs2kLarge[th] = pct(nat.filter(r => Math.max(Math.abs(r.yD), Math.abs(r.yR)) > th).length, nat.length);
  return res;
};