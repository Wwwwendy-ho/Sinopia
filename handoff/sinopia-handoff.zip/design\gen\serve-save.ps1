param($root,$port,$out)
# Same HttpListener static server as ..\..\serve.ps1, plus POST /__save/<name> that writes the body into $out (file name only, no paths).
$l=New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$port/")
$l.Start()
$mime=@{'.html'='text/html';'.css'='text/css';'.js'='application/javascript';'.png'='image/png';'.jpg'='image/jpeg';'.svg'='image/svg+xml'}
while($l.IsListening){
 $c=$l.GetContext()
 $p=$c.Request.Url.LocalPath; if($p -eq '/'){$p='/index.html'}
 if($c.Request.HttpMethod -eq 'POST' -and $p.StartsWith('/__save/')){
  $n=[IO.Path]::GetFileName($p.Substring(8))
  if($n -match '^[A-Za-z0-9._-]+\.(png|svg)$'){
   $ms=New-Object IO.MemoryStream; $c.Request.InputStream.CopyTo($ms)
   [IO.File]::WriteAllBytes((Join-Path $out $n),$ms.ToArray())
   $c.Response.StatusCode=200
  } else {$c.Response.StatusCode=400}
  $c.Response.Close(); continue
 }
 if($p -eq '/__stop'){ $c.Response.Close(); $l.Stop(); break }
 $f=Join-Path $root ($p.TrimStart('/').Replace('/','\'))
 if(Test-Path $f -PathType Leaf){
  $b=[IO.File]::ReadAllBytes($f); $e=[IO.Path]::GetExtension($f).ToLower()
  $c.Response.ContentType=$(if($mime[$e]){$mime[$e]}else{'application/octet-stream'})
  $c.Response.Headers.Add('Cache-Control','no-store')
  $c.Response.OutputStream.Write($b,0,$b.Length)
 } else {$c.Response.StatusCode=404}
 $c.Response.Close()
}
