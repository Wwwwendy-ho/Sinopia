param([string]$Root)
# Reads dataset dirs (as data only) and writes manifest.json files. Does not execute anything from them.
Add-Type -AssemblyName System.Drawing
function Get-Size($p){ $i=[Drawing.Image]::FromFile($p); $r=@{w=$i.Width;h=$i.Height}; $i.Dispose(); $r }
function Rel($base,$p){ $p.Substring($base.Length+1).Replace('\','/') }
function Read-Pts($p){ $o=@(); foreach($l in Get-Content $p){ $t=$l.Trim() -split '\s+'; if($t.Count -ge 2){ $o+=,@([double]$t[0],[double]$t[1]) } }; ,$o }
function Save($obj,$path){ $obj | ConvertTo-Json -Depth 8 -Compress | Set-Content -Encoding UTF8 $path }

# ---------- CUFSF ----------
$d="$Root\cufsf"; $items=@()
$map=@{}; foreach($l in Get-Content "$d\feret_filenames.txt"){ if($l.Trim()){ $map[$l.Trim().Substring(0,5)]=$l.Trim() } }
foreach($f in Get-ChildItem "$d\original_sketch\original_sketch" -Filter *.jpg | Sort Name){
  $id=$f.BaseName; $sz=Get-Size $f.FullName
  $sp=Read-Pts "$d\sketch_points\sketch_points\$id.3pts"
  $ph=Get-ChildItem "$d\photo_points\photo_points" -Filter "$id*.3pts" | select -First 1
  $pp=Read-Pts $ph.FullName
  $named=@{ left_eye_center=$sp[0]; right_eye_center=$sp[1]; mouth_center=$sp[2] }
  $pnamed=@{ left_eye_center=$pp[0]; right_eye_center=$pp[1]; mouth_center=$pp[2] }
  $items+=[ordered]@{ id=$id
    sketch=(Rel $d $f.FullName); sketch_width=$sz.w; sketch_height=$sz.h
    sketch_cropped=(Rel $d "$d\cropped_sketch\cropped_sketch\$id.jpg")
    sketch_points=$sp; sketch_named=$named
    photo=$null; photo_missing_reason='FERET photo requires NIST request'; feret_photo_filename=$map[$id]
    photo_frame_width=768; photo_frame_height=712
    photo_points_in_768x712_frame=$pp; photo_named_in_768x712_frame=$pnamed }
}
Save ([ordered]@{dataset='CUFSF';count=$items.Count;
 point_order='3 points per file (.3pts), "x y" per line: [0]=left eye centre (image left), [1]=right eye centre, [2]=mouth centre. Order inferred from coordinates (verified visually). No nose tip, mouth corners or chin points are provided. Coordinates are pixels in the sketch image file (sketch_points) or in the 768x712 FERET frame (photo points; FERET resized to 768x512 and padded 100 px left/right).';
 items=$items}) "$d\manifest.json"
"CUFSF items: $($items.Count)"

# ---------- CUFS ----------
$d="$Root\cufs"; $items=@(); $x="$d\x"; $miss=0
foreach($set in 'training','testing'){
  $ph=@{}; Get-ChildItem "$x\CUHK_${set}_photo\photo" -File | %{ $ph[$_.BaseName.ToLower()]=$_ }
  foreach($sk in Get-ChildItem "$x\CUHK_${set}_sketch\sketch" -File | Sort Name){
    $key=($sk.BaseName.ToLower() -replace '-sz\d+$','')
    $pf=$ph[$key]; if(-not $pf){ # drop the digit after sex letter (e.g. f2-005-01)
      $key2=$key -replace '^([fm])\d-','$1-'; $pf=$ph[$key2]; if($pf){$key=$key2} }
    if(-not $pf){ $miss++; continue }
    $psz=Get-Size $pf.FullName; $ssz=Get-Size $sk.FullName
    $pp="$x\CUHK_${set}_faducial_points_photo\photo\$($pf.BaseName).dat"
    $sp=Get-ChildItem "$x\CUHK_${set}_faducial_points_sketch\sketch" -File | ?{ $_.BaseName -ieq $sk.BaseName } | select -First 1
    $cp=Get-ChildItem "$x\CUHK_${set}_cropped_photos\photos" -File | ?{ $_.BaseName -ieq $pf.BaseName } | select -First 1
    $cs=Get-ChildItem "$x\CUHK_${set}_cropped_sketches\sketches" -File | ?{ $_.BaseName -ieq $sk.BaseName } | select -First 1
    $items+=[ordered]@{ id=$key; split=$set
      photo=(Rel $d $pf.FullName); photo_width=$psz.w; photo_height=$psz.h
      sketch=(Rel $d $sk.FullName); sketch_width=$ssz.w; sketch_height=$ssz.h
      photo_points=(Read-Pts $pp); sketch_points=(Read-Pts $sp.FullName)
      photo_cropped=(Rel $d $cp.FullName); sketch_cropped=(Rel $d $cs.FullName) }
  }
}
Save ([ordered]@{dataset='CUFS-CUHK-student';count=$items.Count;unpaired=$miss;
 point_order='35 points per .dat file, "x y" per line, pixels in the ORIGINAL (non-cropped) photo/sketch image of the same item. Point semantic order is not documented on the site; see README for what was verified. Cropped images (200x250) have no point files.';
 items=$items}) "$d\manifest.json"
"CUFS items: $($items.Count) unpaired $miss"

# ---------- FS2K ----------
$d="$Root\fs2k"; $b="$d\x\FS2K"; $items=@()
$an=@(); foreach($n in 'anno_train','anno_test'){ $j=Get-Content "$b\$n.json" -Raw | ConvertFrom-Json; foreach($e in $j){ $an+=[pscustomobject]@{split=$n.Substring(5);e=$e} } }
foreach($a in $an){
  $e=$a.e; $pn=$e.image_name; $num=($pn -split 'image')[1]; $pd=($pn -split '/')[0]; $sd=$pd -replace 'photo','sketch'
  $pf=Get-ChildItem "$b\photo\$pd" -Filter "image$num.*" | select -First 1
  $sk=Get-ChildItem "$b\sketch\$sd" -Filter "sketch$num.*" | select -First 1
  if(-not $pf -or -not $sk){ continue }
  $ps=Get-Size $pf.FullName; $ss=Get-Size $sk.FullName
  $items+=[ordered]@{ id=$pn; split=$a.split; style=$e.style; photo=(Rel $d $pf.FullName); photo_width=$ps.w; photo_height=$ps.h
    sketch=(Rel $d $sk.FullName); sketch_width=$ss.w; sketch_height=$ss.h; attributes=$e }
}
Save ([ordered]@{dataset='FS2K';count=$items.Count;point_order='No facial landmarks in this dataset. attributes.skin_color is a single [x,y]-ish sample point (see README caveat).';items=$items}) "$d\manifest.json"
"FS2K items: $($items.Count)"
