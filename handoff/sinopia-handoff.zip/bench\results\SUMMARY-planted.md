# Planted-error suite and detector comparison (summary)

Saved from the benchmark agent's final report. Raw data: results\planted-*.json, results\detectors-*.json. Code: lib\planted-core.js, lib\detectors.js, lib\analysis.js, planted.html, detectors.html.

## Suite
720 cases from 188 CUFS sketches (seed planted-v1): 560 single errors (14 types x magnitudes 2/4/6/8/12% of eye-to-chin (EC) x 8), 80 doubles, 80 controls. Global scale 0.70-1.15, translation <=5%, 2-5 deg tilt on every 4th case. Gaussian RBF warp (sigma 0.2 EC), single bilinear resample; exact GT incl. collateral movement (trueDelta).

## Engines (oracle = ground-truth landmarks, reference = same sketch unplanted, tol 2%)
| engine | det >=4% | det 2% | controls FA | planted unplanted FA (collateral excl / strict) |
|---|---|---|---|---|
| robust+midline (L1 scale+translation fit, rotation from nose-mouth-chin axis) | 99.8% | 86% | 0% | 0.9% / 5.8% |
| robust | 98.7% | 72% | 25% (tilted controls) | 20% / 24% |
| spec+midline | 85.7% | 86% | 0% | 23% / 28% |
| spec (anchor mid-eyes, scale eye-to-chin, rot 0) | 85.4% | 84% | 25% | 38% / 43% |
Defects of the planned spec engine: chin length invisible (it defines scale); rotation 0 flags every tilted control.

## Natural sketch-vs-photo discrepancy (oracle, robust+midline, |value| p95 / p99 % EC, bias)
eye_spacing 1.5/2.2 (+0.3); eye_tilt 1.9/2.5 (0); nose_len 2.7/3.6 (+0.7); mouth_height 1.6/2.2 (-0.3); mouth_width 4.5/6.6 (+2.2); chin_len 3.6/5.4 (+0.6); jaw_width 4.7/7.4 (+1.3).

## Detectors (CUFS 188 pairs, CUFSF 400 sketches)
| | tiny (current) | full 68 | MediaPipe 0.25 | MediaPipe 0.5 |
|---|---|---|---|---|
| detection CUFS / CUFSF | 100% / 100% | 100% / 100% | 100% / 100% | 100% / 100% |
| detection, faded drawings (30% ink) | 87% | 87% | 100% | 100% |
| CUFS sketch core6 NME mean / p90 | 0.048 / 0.062 | 0.040 / 0.056 | 0.029 / 0.041 | 0.029 / 0.041 |
| CUFSF NME3 mean | 0.040 | 0.037 | 0.022 | 0.021 |
| ms per image (CPU) | 820 | 891 | 18 | 17 |
| download | ~0.93 MB | ~1.21 MB | ~13.5 MB | same |
| licence | MIT | MIT | Apache-2.0 | Apache-2.0 |

## Decisive metric: planted-error detection from detector landmarks (robust+midline, p95 per-feature tolerance, bias-corrected)
| | oracle | MediaPipe | full 68 | tiny |
|---|---|---|---|---|
| detected >=4% | 85% | 81% | 70% | 62% |
| detected >=6% | 92% | 86% | 78% | 69% |
| controls with any FA | 23.8% | 21.3% | 25% | 22.5% |
| median magnitude error >=4% (% EC) | 1.2 | 2.1 | 4.1 | 4.5 |
p99 tolerance: controls FA oracle 6.3%, MediaPipe 7.5%; detection >=4% oracle 76%, MediaPipe 73%.
face-api models shrink imposed displacements to 15-65%; MediaPipe follows eyes/mouth width at 0.7-0.9; jaw/chin poor for all (gain <=0.45).

Detection by magnitude 2/4/6/8/12 (MediaPipe): eye_spacing 63/100/100/100/100; eye_tilt 44/100/100/100/100; nose_len 50/91/100/100/100; mouth_height 25/100/100/100/100; mouth_width 6/48/89/95/100; chin_len 19/25/35/52/95; jaw_width 6/5/29/35/65.

## Recommendation
1. Detector: MediaPipe Face Landmarker (self-hosted, lazy-loaded and cached; keep face-api tiny as fallback).
2. Engine: robust L1 scale+translation fit + midline rotation instead of single-measure scale with rotation 0.
3. Tolerance: ~3% EC for eye spacing, eye height, nose length, mouth height; 5% for mouth width and chin; jaw only above ~10%; adjustable; subtract per-feature detector bias.
4. Reliable on sketches: eyes and mouth height from 4%; nose length 4-6%; mouth width from 8%. Not reliable: chin length, jaw width (report only as 'possible' above 10-12%).

## Caveats
CUFS only (one artist set, frontal, clean); natural floor includes annotation noise; no real faint sketches, 3/4 views or large roll/yaw; jaw landmark pairing tuned on the evaluation set; CPU timings in the embedded browser; MediaPipe 0.10.21 tested (latest npm 1.2.3); planted warps are synthetic.
