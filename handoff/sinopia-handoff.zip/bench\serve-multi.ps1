﻿param($port=8930)
# Localhost-only multi-root static server + results writer for the Sinopia align benchmark.
$bench = $PSScriptRoot
$scratch = Split-Path $bench -Parent
$roots = [ordered]@{
 '/app-baseline/' = Join-Path $scratch 'repo-now\Sinopia-main'
 '/app-fixed/'    = 'C:\Users\20750\AppData\Local\Claude-Data\claude_pzs8sxrjxfjjc\scratch-workspaces\5602a7af-45d1-4a73-a53d-b1514682a6cf\629065a2-c97c-4fe0-bfe7-eaf73834e2a0\scratch-2026-11-10-e182e2\sinopia'
 '/app-tuned/'    = 'C:\Users\20750\AppData\Local\Claude-Data\claude_pzs8sxrjxfjjc\scratch-workspaces\5602a7af-45d1-4a73-a53d-b1514682a6cf\629065a2-c97c-4fe0-bfe7-eaf73834e2a0\scratch-2026-11-10-e182e2\sinopia'
 '/app-fixed0/'   = Join-Path $scratch 'app-fixed0'
 '/data/'         = Join-Path $scratch 'datasets'
 '/bench/'        = $bench
}
$resultsDir = Join-Path $bench 'results'
New-Item -ItemType Directory -Force $resultsDir | Out-Null
$maxPost = 64MB
$mime=@{'.html'='text/html; charset=utf-8';'.js'='application/javascript; charset=utf-8';'.css'='text/css';'.json'='application/json; charset=utf-8';'.png'='image/png';'.jpg'='image/jpeg';'.jpeg'='image/jpeg';'.webp'='image/webp';'.svg'='image/svg+xml';'.webmanifest'='application/manifest+json';'.ico'='image/x-icon';'.txt'='text/plain';'.mjs'='application/javascript; charset=utf-8';'.wasm'='application/wasm';'.task'='application/octet-stream'}
$l=New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$port/")
$l.Prefixes.Add("http://127.0.0.1:$port/")
$l.Start()
while($l.IsListening){
 $c=$l.GetContext()
 try {
  $req=$c.Request; $res=$c.Response
  $p=$req.Url.LocalPath
  $res.Headers.Add('Cache-Control','no-store')
  if($req.HttpMethod -eq 'POST'){
   $name=$null; if($p -match '^/bench/results/([A-Za-z0-9._-]{1,80})$'){ $name=$Matches[1] }
   if($name -and $name -match '\.(json|html)$' -and $name -notmatch '\.\.'){
    if($req.ContentLength64 -gt $maxPost){ $res.StatusCode=413 }
    else {
     $ms=New-Object IO.MemoryStream; $req.InputStream.CopyTo($ms)
     if($ms.Length -gt $maxPost){ $res.StatusCode=413 }
     else {
      $tmp=Join-Path $resultsDir ($name+'.tmp'); [IO.File]::WriteAllBytes($tmp,$ms.ToArray())
      Move-Item -Force $tmp (Join-Path $resultsDir $name)
      $res.StatusCode=200
      $b=[Text.Encoding]::UTF8.GetBytes('{"ok":true,"bytes":'+$ms.Length+'}'); $res.ContentType='application/json'; $res.OutputStream.Write($b,0,$b.Length)
     }
    }
   } else { $res.StatusCode=400 }
  }
  elseif($req.HttpMethod -eq 'GET' -or $req.HttpMethod -eq 'HEAD'){
   $f=$null
   foreach($k in $roots.Keys){ if($p.StartsWith($k)){ $rel=$p.Substring($k.Length); $base=[IO.Path]::GetFullPath($roots[$k]); if($rel -eq ''){$rel='index.html'}
     $full=[IO.Path]::GetFullPath((Join-Path $base $rel.Replace('/','\')))
     if($full.StartsWith($base + '\') -or $full -eq $base){ $f=$full }; break } }
   if($f -and (Test-Path -LiteralPath $f -PathType Leaf)){
    $b=[IO.File]::ReadAllBytes($f); $e=[IO.Path]::GetExtension($f).ToLower()
    $res.ContentType=$(if($mime[$e]){$mime[$e]}else{'application/octet-stream'})
    $res.ContentLength64=$b.Length
    if($req.HttpMethod -eq 'GET'){ $res.OutputStream.Write($b,0,$b.Length) }
   } else { $res.StatusCode=404 }
  } else { $res.StatusCode=405 }
 } catch { try{ $c.Response.StatusCode=500 }catch{} }
 try{ $c.Response.Close() }catch{}
}



