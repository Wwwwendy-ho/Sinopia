/* Offline calibration / evaluation of the face-fit confidence rule on recorded benchmark evidence.
   Load into any bench page (needs window.Summ for stats): fetch('/bench/calib.js').then(r=>r.text()).then(eval)
   Calib.init() -> loads the app's decide functions (hidden iframe) and result files.
   Evidence comes from runs labelled calib-<suite> (app run with DrawingCompare.Subjects.calibrate = true). */
(() => {
  'use strict';
  const C = (window.Calib = {});
  const D2R = Math.PI / 180, wrap = a => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
  const apply = (T, p) => { const c = Math.cos(T.th), s = Math.sin(T.th); return { x: T.s * (c * p.x - s * p.y) + T.x, y: T.s * (s * p.x + c * p.y) + T.y }; };
  const compose = (A, B) => { const t = apply(A, { x: B.x, y: B.y }); return { s: A.s * B.s, th: wrap(A.th + B.th), x: t.x, y: t.y }; };
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y), mean = a => a.reduce((s, v) => s + v, 0) / a.length;
  const q = (arr, p) => { const a = arr.filter(Number.isFinite).sort((x, y) => x - y); if (!a.length) return null; const i = (a.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i); return a[lo] + (a[hi] - a[lo]) * (i - lo); };
  C.q = q;
  /** Calibration half from the person / photo id (both halves of a case family stay together). FNV-1a parity. */
  C.half = id => { const key = String(id).split('|')[0]; let h = 2166136261; for (let i = 0; i < key.length; i++) { h ^= key.charCodeAt(i); h = Math.imul(h, 16777619); } return ((h >>> 0) >> 3) & 1 ? 'test' : 'cal'; };

  C.init = async () => {
    const f = document.createElement('iframe'); f.style.cssText = 'position:absolute;width:10px;height:10px;left:-99px'; f.src = '/app-tuned/index.html?calib=' + Date.now(); document.body.appendChild(f);
    await new Promise(r => (f.onload = r));
    for (let i = 0; i < 100 && !(f.contentWindow.DrawingCompare && f.contentWindow.DrawingCompare.Subjects); i++) await new Promise(r => setTimeout(r, 50));
    C.S = f.contentWindow.DrawingCompare.Subjects; C.T0 = JSON.parse(JSON.stringify(C.S.thresholds));
    C.data = {};
    for (const lab of ['baseline', 'fixed', 'calib', 'tuned']) for (const s of ['cufs', 'fs2k', 'retake']) {
      try { const r = await fetch(`/bench/results/${lab}-${s}.json`, { cache: 'no-store' }); if (r.ok) C.data[lab + '-' + s] = await r.json(); } catch { /* absent */ }
    }
    return Object.keys(C.data);
  };

  /** What the rule would decide for one recorded match. rec: the single-match fields {method, ev, outcome, M}. */
  C.decide = (rec, T = C.S.thresholds) => {
    const ev = rec.ev, S = C.S;
    if (!ev) return { outcome: rec.outcome === 'approximate' ? 'offered' : rec.outcome, M: rec.M, via: rec.method };
    if (rec.method === 'face-landmarks' && ev.e) {
      const v = S.decideFace(ev, T);
      if (!v.reject) return { outcome: v.confident ? 'confident' : 'offered', M: rec.M, why: v.why, via: 'face' };
      const st = ev.struct; if (!st) return { outcome: 'declined', M: null, why: ['implausible'], via: 'rejected' };
      const d = S.decideStructural({ confident: !!st.c, approximate: !!st.a }, st, true, T);
      return { outcome: d.confident ? 'confident' : d.approximate ? 'offered' : 'declined', M: d.confident || d.approximate ? { s: st.s, th: st.th, x: st.tx, y: st.ty } : null, why: ['face-rejected'], via: 'struct-after-reject' };
    }
    const st = ev.struct; if (!st) return { outcome: rec.outcome === 'approximate' ? 'offered' : rec.outcome, M: rec.M, via: rec.method };
    const d = S.decideStructural({ confident: !!st.c, approximate: !!st.a }, st, !!st.conflict, T);
    return { outcome: d.confident ? 'confident' : d.approximate ? 'offered' : 'declined', M: rec.M, via: 'structural' };
  };

  /** CUFS: recs from a calib run (method/ev/m recorded). Returns counts for a set of cases. */
  C.cufs = (cases, T) => {
    const out = { n: 0, confident: 0, offered: 0, declined: 0, accApplied: 0, wrongApplied: 0, offeredAcc: 0, accTotal: 0, unwanted: 0, applied: 0, nme: [] };
    for (const c of cases) {
      const d = C.decide(c, T); out.n++; out[d.outcome] = (out[d.outcome] || 0) + 1;
      const nme = c.m && c.m.nme35, acc = nme != null && nme <= 0.15 && d.via !== 'struct-after-reject';
      if (acc) out.accTotal++;
      if (d.outcome === 'confident') { out.applied++; out.nme.push(nme); if (acc) out.accApplied++; if (nme > 0.25) out.wrongApplied++; if (c.params.tiltDeg === 0 && Math.abs(c.m.appliedRotDeg) > 2) out.unwanted++; }
      if (d.outcome === 'offered' && acc) out.offeredAcc++;
    }
    return out;
  };

  /** FS2K pair metrics from a calib run with decisions replaced by the rule. */
  C.fs2k = (cases, T) => {
    const out = { n: 0, bothApplied: 0, wrongApplied: 0, consistentApplied: 0, bad: 0, badNotApplied: 0, good: 0, goodApplied: 0, appliedSides: 0, sides: 0, offered: 0, declined: 0 };
    for (const c of cases) {
      out.n++;
      const sk = c.sizes, diag = Math.hypot(sk[2], sk[3]), K = c.params.K;
      const pts = [{ x: 0, y: 0 }, { x: -sk[0] / 2, y: -sk[1] / 2 }, { x: sk[0] / 2, y: -sk[1] / 2 }, { x: -sk[0] / 2, y: sk[1] / 2 }, { x: sk[0] / 2, y: sk[1] / 2 }];
      const r0 = C.decide({ method: c.method0, ev: c.ev0, outcome: c.o0, M: c.m0 }, T), r1 = C.decide({ method: c.method1, ev: c.ev1, outcome: c.o1, M: c.m1 }, T);
      for (const r of [r0, r1]) { out.sides++; if (r.outcome === 'confident') out.appliedSides++; else if (r.outcome === 'offered') out.offered++; else out.declined++; }
      let cons = null;
      if (r0.M && r1.M) { const Cc = compose(r1.M, K); cons = { pos: mean(pts.map(p => dist(apply(Cc, p), apply(r0.M, p)))) / diag * 100, rot: wrap(Cc.th - r0.M.th) / D2R }; }
      const bad = !cons || cons.pos > 2 || Math.abs(cons.rot) > 2, both = r0.outcome === 'confident' && r1.outcome === 'confident';
      if (bad) { out.bad++; if (!both) out.badNotApplied++; } else { out.good++; if (both) out.goodApplied++; }
      if (both) { out.bothApplied++; if (cons && cons.pos <= 2 && Math.abs(cons.rot) <= 2) out.consistentApplied++; if (!cons || cons.pos > 3 || Math.abs(cons.rot) > 2) out.wrongApplied++; }
      c._d = { r0, r1, cons, bad };
    }
    return out;
  };
  C.byHalf = (cases, half) => cases.filter(c => C.half(c.id) === half);
})();
