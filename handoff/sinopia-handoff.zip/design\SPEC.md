# Proportions: design spec

The proportion check is the feature Sinopia is for. You load a drawing and its reference, and Sinopia shows where the drawing's features sit compared with the reference, as numbers, arrows and plain sentences. This document describes one design. Where there was a choice, it has been made.

Snapshots (stand-in imagery drawn as SVG; no dataset images):

| File | Shows |
| --- | --- |
| `a-desktop-overlay.png` | Desktop 1280x800, Overlay (Blend, reference at 40 %), report column, item 1 selected (nose bracket), pin, size-by measure line, arrows and numbered tags, an info bubble on a point |
| `b-desktop-side-grid.png` | Desktop, Side layout, distortion grid on, arrows off, item 2 selected (jaw width bracket) |
| `c-phone-sheet.png` | Phone 375x812, Overlay, the report as a bottom sheet at its middle height, item 1 selected, only that item's points shown |

The generator is in `gen/` (`mock.html`, `face.js`, `lib.js`, `serve-save.ps1`). Open `mock.html?s=a|b|c` on a local server; `save(...)` writes the PNGs.

---

## 0. The model (summary of the engine, as the user sees it)

* **Points.** Facial landmarks on both images: brows (inner end, middle, outer end), eyes (inner corner, centre, outer corner), bridge, nose tip, nostril wings, nose base, mouth corners, top of upper lip, centre, bottom of lower lip, cheekbones, jaw corners, jaw line, chin. Later: ears, hairline, hands, body joints.
* **Pin** (the anchor). The one spot where drawing and reference are pinned together. Default: **between the eyes**. Presets: Between the eyes, Nose tip, Chin, plus any spot the user drags it to (a custom pin snaps to a point when dropped within 12 px of one).
* **Size by** (the scale measure). The distance the two images are made equal on. Default: **Eye line to chin**. Presets: Eye line to chin, Eye spacing, Head height (top of head to chin, later phase when hairline/top is detected), Custom (two spots the user drags).
* **Tilt.** Off. The drawing is never turned to fit. A tilt difference is reported as an issue ("Head tilted 5° clockwise"). The option **Match head tilt** (off by default) removes it, for a photo taken at an angle.
* After pin, size and (no) tilt, every remaining offset is a real difference. All numbers are **% of the size-by measure**.
* The features that define the pin and the measure cannot be wrong by definition (with Eye line to chin, the chin always matches). The report says so in a hover note on the Size by picker ("The chin is used for sizing, so it always matches. Size by eye spacing to check the chin.").

## 1. Entry point and modes

**One action: Proportions** (icon: an egg-shaped head with a dimension bar; key `K`).

* Desktop: a toggle button in the top bar, between **Fit all** and **More**. Pressed state = the dark hatched fill used by **Link**.
* Phone: an icon button in the bottom bar between **Fit** and **More** (44 px target). The bottom bar has room for it (snapshot c).
* Disabled until both a drawing and a reference are loaded; the info bubble says why ("Add a drawing and a reference first").
* When face detection (which already runs for auto-align) finds a face in both images, a small vermilion dot appears on the button (the same dot language as the camera standby dot) until the user opens Proportions once for this pair. The first time ever, a toast says **"Faces found in both images."** with the action **Check proportions**. Nothing opens by itself.

**Proportions is a check layer, not a fifth compare mode.** It sits on top of whichever layout is active.

* On open, the drawing is placed by the pin and the size-by measure (no tilt). This is an alignment: it goes on the **Undo align** history ("Pinned between the eyes"), the Undo bar slip shows it, and closing Proportions keeps the placement (Undo brings back the previous one).
* On open, the view zooms so the face fills the canvas (both images, linked). Pan and zoom work as usual.
* **Overlay:** the compare mode switches to **Blend** with the reference at 40 % under the drawing (the best way to read pencil lines and markers together). The user can still pick Tint, Wipe or Outline; the marks stay. On close, the previous compare mode and slider value return.
* **Side / Stacked:** points on both images; arrows and brackets on the drawing only; pin and measure line on both; hovering a report item highlights its feature on both images.
* **Phone:** always Overlay while Proportions is open (Side panes are too narrow for marks); the previous layout returns on close.
* **Line up with dots** and Proportions are separate: opening Line up closes Proportions (and vice versa) with no loss; a dots alignment is replaced by the pin alignment, on the Undo list.
* **Auto-align / Fit all** while Proportions is open re-pin instead of best-fitting (Fit all = "fit the pair, then re-pin").

**When no face is found** in one or both images, Proportions still opens, with an empty-state card in the report:

> **No face found in the drawing.** Light pencil lines are hard to read. You can place the points yourself.
> [ **Place points myself** ] [ Compare outlines ]

* **Place points myself:** a coach like Line up, on the image without a face, asks for five points in order: Left eye, Right eye, Nose tip, Mouth centre, Chin (each step names and draws the spot; Skip is allowed for any but the eyes). Missing points get no statements. Once five are placed, everything works as with detection; the user can add more points by dragging from the full set later.
* **Compare outlines:** switches Overlay to **Outline** compare and closes the report. In the later phase this becomes the outline-band comparison (see 7).
* **Not a face** (a figure, a still life, a landscape): the same **Place points myself** flow, with free points: tap any matching spots on the reference and then the drawing (pairs coloured and numbered as in Line up, up to 12 pairs). The report then lists offsets by pair number ("Point 3 sits 6% too far right") and the distortion grid works the same. This is how the check stays consistent for all art, not only faces.
* **Heads turned differently** (pose check from the existing yaw measures): a caution line at the top of the list, "The heads are turned differently, so widths are approximate.", and width items (eye spacing, jaw, mouth width) get the mark *approx.* and are never ranked above placement items. When the poses match, the report says "Both heads face the same way, so every measurement counts." (snapshot a).

## 2. On-canvas visual language

Everything is drawn at a constant screen size (it does not grow with zoom) and has a thin warm-paper halo (1–1.6 px, #fbf7ee) so it reads on pencil, on photo skin and on the grey surround.

| Mark | Look | Why |
| --- | --- | --- |
| Reference point | Hollow ring, sinopia #a5502f, r 3.6 px, 1.6 px line | Matches Line up: reference marks are open |
| Drawing point | Solid graphite dot #2a2521, r 2.8 px | Drawing marks are solid |
| Arrow | From the drawing point to where the reference says it should be. Open arrowhead. Major: vermilion #c2492a, 2.4 px. Minor: sinopia, 1.7 px. Points within tolerance get no arrow | Direction to move your line |
| Bracket | For proportion items (length, width, spacing): two parallel dimension lines, the reference's dashed sinopia, the drawing's solid graphite, the excess (or shortfall) as a 4 px vermilion segment, with a label chip ("8% too long") | Lengths are not one point's offset; a bracket shows "this much longer" |
| Number tag | Circle with the item's rank. Major: filled vermilion, white number. Minor: paper fill, sinopia ring and number | Links canvas and list; severity is coded by fill and weight as well as colour (works in grayscale and for colour-blind users) |
| Pin | Vermilion dot with a dashed ring and four crosshair ticks, 32 px across; 44 px hit area | Reads as "pinned here", draggable |
| Size-by measure | A dimension line in sinopia placed beside the face (not across it), with arrow ends, square drag handles at both ends, dashed extension lines to the two features, and a label chip in italic ("eye line to chin") | The convention artists know from measuring with a pencil |
| Distortion grid | See below | |

**Clutter rules.**

1. Only flagged items (over tolerance) have arrows, brackets and tags. Everything within tolerance shows only its points.
2. A **bracket** appears for the selected item only. Unselected items show arrows and tags.
3. When an item is selected (hover on desktop, tap anywhere), all other marks drop to 50 % opacity.
4. **Points** toggle: on = all points; off = only the selected item's points. Default on for desktop, off for phones (snapshot c).
5. Arrows are drawn at true length. A difference just over tolerance can be a few pixels; the tag and the list carry it. Arrows are never exaggerated.
6. Knock-on effects: when one item explains another (the mouth sits low because the nose is long; the distance from nose to mouth is right), the second is listed as a sub-line of the first and its arrows share the first item's tag, drawn lighter.

**Distortion grid** (diagnostic only; never warps the drawing).

* On the reference: a square grid over the face (16 % of the measure per square, from the brows to below the chin), dashed sinopia at 50 %.
* On the drawing: the same squares as the drawing bends them (thin-plate spline from all point pairs), graphite 1 px over a paper halo. The grid lines are true, not exaggerated.
* Shading: where a region of the drawing is larger than the reference's, a sinopia wash (**Stretched**); smaller, a slate-blue wash #2f6f86 (**Squashed**). Wash strength follows the size of the change; changes under 4 % of area are left clear. Smoothed over a neighbourhood so it reads as areas, not speckle.
* In Overlay the grid sits on the drawing layer only. Caption chips name what the grid is: "Reference squares, as your drawing bends them" (drawing) and "Reference squares" (reference). A legend with the two swatches appears in the report while the grid is on.
* Off by default; toggled with the **Grid** chip in the report (and `Shift+G` while Proportions is open). The top-bar Grid (thirds and sixths) is unrelated and keeps working.

## 3. The report

**Desktop:** a taped paper slip in its own column at the right edge of the workspace (266 px wide, full height). The panes shrink to make room: the report never covers the images. A collapse control (the `‹` on the slip edge, not shown in the snapshots) folds it to a 36 px spine that shows "Proportions" vertically and the issue count; images reflow.

**Phone:** a bottom sheet on warm paper over the canvas, with a strip of washi tape as its grab handle. Three heights: *peek* (title row and the top item, 120 px), *half* (default; title, pickers, the list, as in snapshot c), *full* (everything, scrolls). The canvas re-fits the face into the space above the sheet. Swipe down from peek or tap the close cross closes Proportions.

Order of content (both):

1. **Title row:** "Proportions", help `?` (opens the explainer picture), close `×`.
2. Line: *Your drawing, measured against the reference.*
3. **Pin** picker and **Size by** picker (dropdown chips). On phones they sit on one row as "Pin: Between the eyes" and "Size: Eye line to chin".
4. **Count line:** "4 differences" with "over 3%" at the right. When none: see empty states.
5. **The list**, ranked by size (placement and proportion items mixed), at most 6 items; more than 6 adds "Show 3 more". Each row: number tag, sentence (major items semi-bold), optional sub-line for knock-on effects. Hover (desktop) or tap (all) selects it: yellow highlighter wash with a sinopia edge (the app's existing "active" mark), canvas highlight as in 2. A second tap on the selected row centres the canvas on that feature.
6. **Close enough** line: "Close enough: brows, mouth width, cheekbones, chin." (what matches, so the artist knows what to keep).
7. **Show:** toggle chips **Arrows**, **Points**, **Grid**. With Grid on: the Stretched / Squashed legend.
8. **Tolerance:** segmented control **Strict 2%**, **Usual 3%** (default), **Relaxed 6%**. An item is flagged when its difference is over the tolerance; it is **major** (filled tag, vermilion) at twice the tolerance or more.
9. **Edit points**, **Reset points**, **Match head tilt** (checkbox).
10. Pose line ("Both heads face the same way, so every measurement counts.").
11. Footnote: *Left and right as you look at the picture.*

Settings that persist (saved with the other settings): tolerance, Show toggles, Match head tilt, the pin and size-by presets. Per photo (saved in the view like dots): edited points and a custom pin or custom measure.

## 4. Editing

* **Desktop:** any point can be dragged directly. The pointer turns to a move cursor within 8 px of a point; farther away a drag pans as usual. Hovering a point for the usual rest time shows its info bubble: the name, which image, "Drag to correct this point" (snapshot a).
* **Touch:** press and hold a point (the existing ~0.5 s long-press) shows its bubble and picks it up; a magnifier loupe (the one Line up uses) appears while dragging. A quick drag pans, so points are never moved by accident. In **Edit points** mode (button in the report) a plain drag moves the nearest point within 22 px, and a strip under the coach line says "Drag any point to correct it. Done".
* **Keyboard:** Tab from the list into the canvas reaches the selected item's points in order; arrow keys move a focused point by 1 px (Shift: 10 px); Enter or Escape returns to the list.
* Everything updates live while dragging: arrows, brackets, numbers, list order, grid.
* A moved point gets a tiny pencil tick beside it (edited), and its bubble says "Moved by you. Reset points puts it back".
* **Pin:** drag the pin anywhere (snaps to a point within 12 px; the picker then names that point, otherwise "Custom spot"). **Measure:** drag either square end (snaps likewise; the picker shows "Custom"). Choosing a preset puts them back.
* **Reset points** re-runs detection for this pair and drops all edited points (one Undo step). Detection never overwrites an edited point except through Reset.

## 5. Undo / Redo

* While Proportions is open, the Undo bar slip under the images is the one history for this mode: point moves, pin moves, measure changes, preset changes, Reset points, Match head tilt. Each is one step; a drag is one step. The slip note names the last step ("Moved the nose base", "Pinned at the nose tip").
* Pin and measure changes move the drawing, so they are alignment steps and sit on the same 12-step list as other alignments, and they survive closing Proportions. Point edits are discarded from the list (not from the photo) when Proportions closes.
* Keys: `Z` / `Shift+Z` as now.

## 6. Accessibility

* The list is the accessible version of the canvas. Every row is a button whose name is the full sentence; the canvas marks are `aria-hidden`.
* A polite live region announces on open "4 differences over 3%. Biggest: Nose 8% too long." and after any edit the new top item if it changed.
* Severity is never colour alone: filled vs ringed tag, weight of text, arrow thickness.
* Halos keep marks at a contrast of at least 3:1 against any background; text in the report meets 4.5:1.
* All targets 44 px on touch (drag handles have 44 px hit areas even when drawn smaller).
* `prefers-reduced-motion`: no glide when pinning or zooming to the face; jumps instead.
* Forced colours: marks use CanvasText / Highlight; washes become hatching.
* Keyboard: `K` opens and closes; within the report Up / Down move through items; `Shift+G` grid; `Esc` closes Proportions (after closing any bubble).

## 7. Empty and error states

| Situation | What the user sees |
| --- | --- |
| One image missing | Proportions button disabled; bubble: "Add a drawing and a reference first." |
| Detection still running | In the report: "Finding the features…" with the existing calm spinner; button usable |
| No face in one image | Card: "No face found in the drawing." (or "in the reference") "Light pencil lines are hard to read. You can place the points yourself." [Place points myself] [Compare outlines] |
| No face in either | "No faces found. This works best with faces; for any other subject, place matching points yourself." [Place points myself] [Compare outlines] |
| Two or more faces | Uses the largest face in each; a line "Using the largest face in each picture." |
| Poses differ a lot (turned more than about 20°) | "The heads are turned too differently to compare. Try a reference taken from the same angle." The list is hidden; points stay editable |
| Mirrored drawing suspected (the left/right features fit far better mirrored) | "Your drawing may be mirrored." [Mirror the drawing] |
| Nothing over tolerance | "No differences over 3%." with a check mark, the Close enough line listing everything, and "Try Strict to see smaller ones." |
| Detection failed / model did not load | "Feature finding is not available right now." [Place points myself] |

Later phase: **outline band**. With **Compare outlines** (or automatically for non-faces once built), the reference's major outline is drawn as a thin sinopia line and, where the drawing's outline strays from it by more than the tolerance, the gap between the two lines is filled with a sinopia (outside) or slate (inside) band; the list then reads "Outline 6% too far out at the left shoulder". Hands and body joints use the same arrows, tags and list ("Left hand 9% too small", "Right elbow 5% too low").

## 8. Copy (English, final)

### Buttons, labels, pickers

| Key | Text |
| --- | --- |
| Top-bar / bottom-bar button | Proportions |
| Report title | Proportions |
| Report intro | Your drawing, measured against the reference. |
| Pin label | Pin |
| Pin presets | Between the eyes · Nose tip · Chin · Custom spot |
| Size label (desktop) | Size by |
| Size presets | Eye line to chin · Eye spacing · Head height · Custom |
| Phone chips | Pin: {pin} · Size: {measure} (whole templates, see below) |
| Count | {n} differences · 1 difference · No differences over {t}% |
| Count suffix | over {t}% |
| Close enough | Close enough: {list}. |
| Show | Show |
| Toggles | Arrows · Points · Grid |
| Legend | Stretched · Squashed |
| Tolerance | Tolerance · Strict 2% · Usual 3% · Relaxed 6% |
| Buttons | Edit points · Reset points · Match head tilt · Done · Place points myself · Compare outlines · Mirror the drawing · Show {n} more |
| Footnote | Left and right as you look at the picture. |
| Grid captions | Reference squares, as your drawing bends them · Reference squares |
| Measure label on canvas | eye line to chin · eye spacing · head height · custom |
| Undo slip notes | Pinned between the eyes · Pinned at the nose tip · Pinned at the chin · Pinned at a custom spot · Moved the {point} · Points reset · Sized by eye spacing (and so on per preset) |
| First-time toast | Faces found in both images. [Check proportions] |

### Info bubbles (data-tip)

| Control | Bubble |
| --- | --- |
| Proportions button | Check the drawing's proportions against the reference: where each feature sits and how big it is. `K` |
| Proportions (disabled) | Add a drawing and a reference first. |
| Pin picker | Where the two pictures are pinned together. Everything is measured from here. |
| Size by picker | The distance made equal in both pictures. All percentages are of this distance. |
| Size by: hover note | The {feature} is used for sizing, so it always matches. Size by something else to check it. |
| Pin on canvas | Pin. Drag it to pin the pictures at another spot. |
| Measure handle | End of the size measure. Drag it to measure between other spots. |
| A point | {Point name}, drawing / reference. Drag to correct this point. |
| Edited point | {Point name}, moved by you. Reset points puts it back. |
| Arrows | Show where each feature should move to match the reference. |
| Points | Show every feature point. When off, only the selected difference's points show. |
| Grid | Show the reference's squares as your drawing bends them: warm where it is stretched, blue where it is squashed. `Shift G` |
| Tolerance | Differences smaller than this are treated as close enough. |
| Edit points | Drag points to correct them, without panning by accident. |
| Reset points | Find the features again and drop your corrections. |
| Match head tilt | Turn the drawing to the reference's tilt, for a photo taken at an angle. Off: tilt is reported as a difference. |
| Number tag | Difference {n}: {sentence} |

### Report sentence templates

Every statement is a **whole sentence template** with numeric placeholders only. The feature and the direction are part of the key, never a substituted word, because adjectives agree with the noun in Spanish and French and Chinese needs different word order and measure words. `{n}` is a whole-number percentage; `{d}` is degrees.

Placement (one feature's position):

```
Left eye {n}% too high            Left eye {n}% too low
Right eye {n}% too high           Right eye {n}% too low
Left brow {n}% too high           Left brow {n}% too low
Right brow {n}% too high          Right brow {n}% too low
Nose {n}% too far left            Nose {n}% too far right
Mouth {n}% too high               Mouth {n}% too low
Mouth {n}% too far left           Mouth {n}% too far right
Chin {n}% too high                Chin {n}% too low
Chin {n}% too far left            Chin {n}% too far right
Left ear {n}% too high            Left ear {n}% too low          (later)
Right ear {n}% too high           Right ear {n}% too low         (later)
Hairline {n}% too high            Hairline {n}% too low          (later)
```

Proportion (a length, width or spacing):

```
Nose {n}% too long                Nose {n}% too short
Nose {n}% too wide                Nose {n}% too narrow
Eyes {n}% too close together      Eyes {n}% too far apart
Left eye {n}% too big             Left eye {n}% too small
Right eye {n}% too big            Right eye {n}% too small
Mouth {n}% too wide               Mouth {n}% too narrow
Lips {n}% too full                Lips {n}% too thin
Jaw {n}% too wide                 Jaw {n}% too narrow
Cheekbones {n}% too wide          Cheekbones {n}% too narrow
Face {n}% too long                Face {n}% too short          (head height measure only)
Forehead {n}% too tall            Forehead {n}% too short      (later)
```

Tilt and pose:

```
Head tilted {d}° clockwise        Head tilted {d}° anticlockwise
Eye line tilted {d}° clockwise    Eye line tilted {d}° anticlockwise
```

Knock-on sub-lines (shown under their cause):

```
The mouth sits {n}% low with it          The mouth sits {n}% high with it
The chin sits {n}% low with it           The chin sits {n}% high with it
Both eyes move with it
```

Free points (non-face):

```
Point {k} {n}% too high      Point {k} {n}% too low
Point {k} {n}% too far left  Point {k} {n}% too far right
```

Lists ("Close enough: …") are built by a list formatter (`Intl.ListFormat`) from translated feature nouns (Brows, Mouth width, Cheekbones, Chin, Eye spacing, Nose length, Jaw width…), which is safe because nouns in a list do not agree with anything.

Rounding and wording rules: percentages are rounded to whole numbers; a difference that rounds to the tolerance but is over it shows as one more than the tolerance (never "3% too high" under "over 3%"). Direction words are from the drawing toward the reference fix: "too high" means the drawing's feature is higher than the reference says.

**Translation mechanism.** The existing `i18n.js` already supports `{name}` placeholders by matching the rendered English back to a key. For this feature, call a new `t(key, params)` that looks up the key first and substitutes afterwards (no reverse matching, which is ambiguous for sentences that differ only in a number). Add every template above to the `zh-Hans`, `zh-Hant`, `es` and `fr` catalogues in the same shape as `alignStrings` (one array per key). Examples:

| en | zh-Hans | es | fr |
| --- | --- | --- | --- |
| Nose {n}% too long | 鼻子长了 {n}% | Nariz un {n} % demasiado larga | Nez trop long de {n} % |
| Eyes {n}% too close together | 两眼间距窄了 {n}% | Ojos un {n} % demasiado juntos | Yeux trop rapprochés de {n} % |
| Left eye {n}% too high | 左眼高了 {n}% | Ojo izquierdo un {n} % demasiado alto | Œil gauche trop haut de {n} % |
| Jaw {n}% too narrow | 下颌窄了 {n}% | Mandíbula un {n} % demasiado estrecha | Mâchoire trop étroite de {n} % |

(The translations are a starting point for a native reviewer, like the existing catalogue.) Spanish and French use a space before `%` (`{n} %`), Chinese does not; the number is formatted with `Intl.NumberFormat` for the language. "Left" and "right" are always as seen in the picture; translations must keep that (zh: 画面左侧的眼睛 would be clearer than 左眼 if reviewers find 左眼 ambiguous).

## 9. Visual tokens (new)

| Token | Value | Use |
| --- | --- | --- |
| `--prop-ref` | #a5502f (sinopia) | reference rings, measure line, minor arrows and tags |
| `--prop-major` | #c2492a (the accent) | major arrows, tags, bracket excess |
| `--prop-drawing` | #2a2521 (ink) | drawing dots, drawing brackets, warped grid |
| `--prop-halo` | #fbf7ee | 1–1.6 px halo under every mark |
| `--prop-squash` | #2f6f86 | squashed wash |
| report slip | #f4efe5 with the paper grain, 1 px ink edge at 55 %, washi tape on top | report |
| selected row | the existing yellow highlighter #f1dc7a at 72 % plus a 3 px sinopia edge | |

No new fonts. Serif for titles and canvas labels, sans for list sentences and controls, as in the rest of the app.

## 10. Build order

1. Points, pin (Between the eyes), size by (Eye line to chin), arrows, tags, list with the sentence templates, tolerance, Overlay and Side. Editable points by drag. Undo integration.
2. Pin and measure presets and dragging, Match head tilt and tilt items, knock-on grouping, phone bottom sheet.
3. Distortion grid.
4. Place points myself (face and free points), all empty states.
5. Later: ears, hairline, head height; hands and body joints; outline band.
