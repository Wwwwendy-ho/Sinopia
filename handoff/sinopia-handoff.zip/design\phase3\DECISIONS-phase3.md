# Phase 3 (body, hands, outline): decisions

Approved by the user on 2026-11-18 (overrides SPEC-phase3.md where they differ):
1. Figure studies: default Size by = Robust auto, Pin = Auto (best fit); Head height and Pit of the neck stay in the menus.
2. Units: figure-scale lengths in heads ("Legs 0.4 heads too short"), single segments in % ("Left forearm 9% too long").
3. Hand test data: download 11k Hands only (about 600 MB, research use, verify terms first; local testing only, never in the repo). Not FreiHAND. Synthetic hands may supplement.
4. Outline band: ALWAYS ON by default in every mode (user choice, not the recommendation); keep it visually calm.
Decided by the lead (technical defaults, user not asked):
5. Pose model: Pose Landmarker full by default, lite as fallback; heavy not shipped.
6. Outline wording: "Left shoulder outline 6% too far out" / "...too far in".
7. All model licences must be confirmed (task B0) before any model file goes into the repo.
8. Left/right = the subject's own (as phase 1). Every new string in en, zh-Hans, zh-Hant, es, fr.

## MANUAL-FIRST (user approved 2026-11-22, after the go/no-go results)
Evidence (bench\results\b1-pose-*.json, hands-*.json, outline-pilot-results.json): Pose Landmarker finds 13% of pencil-look figures (30% of painted originals); Hand Landmarker finds 0% of grey pencil hands (99% of colour hand photos); finger-length gain about 0.66; outline line-route vs selfie mask after face alignment: median 0.61% of height on CUFS; painted scenes not usable automatically; pose segmentation mask aborts on the CPU wasm build.
9. DRAWINGS: guided manual point coach is the primary path for figures and hands. Body coach: head top, chin, pit of the neck, both shoulders, elbows, wrists, hips, knees, ankles (Skip allowed for hidden joints; foreshortened limbs can be marked). Hand coach: the 7-point hand coach from SPEC-phase3 section 4.1 (wrist, thumb tip, index/middle/ring/little fingertips, knuckle line points as specified there), Skip allowed.
10. REFERENCES: auto-detect on the reference (photo) with Pose Landmarker full (lite fallback; crop retry on the subject box) and Hand Landmarker; the user can always correct or place points by hand. Auto-detect on the drawing is only OFFERED ('Try finding the pose automatically'), never assumed.
11. OUTLINE: reference outline from selfie_segmenter (photos) or the line route; drawing outline from the line route; always after face or body alignment; ignore outline points on the image frame; for painted/cluttered scenes ask the user to tap the subject region (or skip outline). No pose segmentation mask on CPU. deeplab_v3 is NOT vendored (licence not confirmed).
12. Vendor only Apache-2.0-confirmed models (pose_landmarker_full, pose_landmarker_lite, hand_landmarker, selfie_segmenter) with the Apache licence text and the model-card references; load each lazily only when its mode is first used.
13. Hands: apply bias/gain correction (finger-length gain about 0.66 on detector points; manual points: gain 1) and tune tolerances on a held-out half.
