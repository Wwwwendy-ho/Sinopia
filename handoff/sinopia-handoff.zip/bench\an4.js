// Validation with the real engines (P0 = original snapshot, P = app). Default options, i.e. exactly what the app does.
const V = window.V = {};
V.fsCache = new Map();
V.flags = (Pe, dFace, rFace, opts, pre) => {
  const key = (Pe === P0 ? 'o' : 'n');
  const f = (face, m) => Pe.features(unflat(face.p), 'mediapipe');
  let D = f(dFace), R = f(rFace); if (pre) { const r = pre(D, R); D = r.D; R = r.R; }
  const al = Pe.align(D, R, opts || {}); if (!al.ok) return null;
  const rep = Pe.measure(D, R, al, opts || {});
  return { fl: rep.flagged.filter(i => i.severity !== 'possible' && i.key !== 'head_tilt').map(i => ({ k: i.key, v: i.value })), rep, al };
};
V.sets = () => {
  const phot = {}; for (const r of AN.data['cufs-natural']) phot[r.i] = r.P;
  return {
    fs2kN: AN.data['fs2k-natural'].filter(r => r.S.n && r.P.n).map(r => ({ half: AN.half(r.id), d: r.S.faces[0], r: r.P.faces[0], rec: r })),
    cufsN: AN.data['cufs-natural'].filter(r => r.S.n && r.P.n).map(r => ({ half: AN.half('cufs' + r.i), d: r.S.faces[0], r: r.P.faces[0], rec: r })),
    fs2kP: AN.data['fs2k-planted'].filter(r => r.D.n && r.P.n).map(r => ({ half: AN.half(r.sk), d: r.D.faces[0], r: r.P.faces[0], kind: r.kind, errors: r.errors, rec: r })),
    cufsP: AN.data['cufs-planted'].filter(r => r.D.n && phot[r.item] && phot[r.item].n).map(r => ({ half: AN.half('cufs' + r.item), d: r.D.faces[0], r: phot[r.item].faces[0], kind: r.kind, errors: r.errors, rec: r })),
  };
};
V.report = (Pe, opts, half) => {
  const S = V.S || (V.S = V.sets()), out = {};
  const nat = arr => { const n = arr.filter(x => x.half === half).map(x => { const e = V.flags(Pe, x.d, x.r, opts); return e ? e.fl.length : null; }).filter(x => x !== null); return { n: n.length, any: pct(n.filter(x => x > 0).length, n.length), ge3: pct(n.filter(x => x >= 3).length, n.length) }; };
  out.fs2kN = nat(S.fs2kN); out.cufsN = nat(S.cufsN);
  for (const nm of ['fs2kP', 'cufsP']) {
    const arr = S[nm].filter(x => x.half === half), ctrl = arr.filter(x => x.kind === 'control'), sing = arr.filter(x => x.kind === 'single');
    const c = ctrl.map(x => { const e = V.flags(Pe, x.d, x.r, opts); return e ? e.fl.length : null; }).filter(x => x !== null);
    const det = mn => { const s = sing.filter(x => x.errors[0].mag >= mn); let h = 0, n = 0; for (const x of s) { const e = V.flags(Pe, x.d, x.r, opts); n++; if (e && X.hit(x.errors[0], e.fl.map(f => ({ k: f.k, v: f.v })))) h++; } return pct(h, n); };
    out[nm] = { ctrlN: c.length, ctrlAny: pct(c.filter(x => x > 0).length, c.length), ctrl3: pct(c.filter(x => x >= 3).length, c.length), det4: det(4), det6: det(6) };
  }
  return out;
};